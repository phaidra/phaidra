--
-- PostgreSQL database dump
--

-- Dumped from database version 15.5 (Debian 15.5-1.pgdg120+1)
-- Dumped by pg_dump version 15.5 (Debian 15.5-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_event_entity; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.admin_event_entity (
    id character varying(36) NOT NULL,
    admin_event_time bigint,
    realm_id character varying(255),
    operation_type character varying(255),
    auth_realm_id character varying(255),
    auth_client_id character varying(255),
    auth_user_id character varying(255),
    ip_address character varying(255),
    resource_path character varying(2550),
    representation text,
    error character varying(255),
    resource_type character varying(64)
);


ALTER TABLE public.admin_event_entity OWNER TO keycloak;

--
-- Name: associated_policy; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.associated_policy (
    policy_id character varying(36) NOT NULL,
    associated_policy_id character varying(36) NOT NULL
);


ALTER TABLE public.associated_policy OWNER TO keycloak;

--
-- Name: authentication_execution; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.authentication_execution (
    id character varying(36) NOT NULL,
    alias character varying(255),
    authenticator character varying(36),
    realm_id character varying(36),
    flow_id character varying(36),
    requirement integer,
    priority integer,
    authenticator_flow boolean DEFAULT false NOT NULL,
    auth_flow_id character varying(36),
    auth_config character varying(36)
);


ALTER TABLE public.authentication_execution OWNER TO keycloak;

--
-- Name: authentication_flow; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.authentication_flow (
    id character varying(36) NOT NULL,
    alias character varying(255),
    description character varying(255),
    realm_id character varying(36),
    provider_id character varying(36) DEFAULT 'basic-flow'::character varying NOT NULL,
    top_level boolean DEFAULT false NOT NULL,
    built_in boolean DEFAULT false NOT NULL
);


ALTER TABLE public.authentication_flow OWNER TO keycloak;

--
-- Name: authenticator_config; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.authenticator_config (
    id character varying(36) NOT NULL,
    alias character varying(255),
    realm_id character varying(36)
);


ALTER TABLE public.authenticator_config OWNER TO keycloak;

--
-- Name: authenticator_config_entry; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.authenticator_config_entry (
    authenticator_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.authenticator_config_entry OWNER TO keycloak;

--
-- Name: broker_link; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.broker_link (
    identity_provider character varying(255) NOT NULL,
    storage_provider_id character varying(255),
    realm_id character varying(36) NOT NULL,
    broker_user_id character varying(255),
    broker_username character varying(255),
    token text,
    user_id character varying(255) NOT NULL
);


ALTER TABLE public.broker_link OWNER TO keycloak;

--
-- Name: client; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client (
    id character varying(36) NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    full_scope_allowed boolean DEFAULT false NOT NULL,
    client_id character varying(255),
    not_before integer,
    public_client boolean DEFAULT false NOT NULL,
    secret character varying(255),
    base_url character varying(255),
    bearer_only boolean DEFAULT false NOT NULL,
    management_url character varying(255),
    surrogate_auth_required boolean DEFAULT false NOT NULL,
    realm_id character varying(36),
    protocol character varying(255),
    node_rereg_timeout integer DEFAULT 0,
    frontchannel_logout boolean DEFAULT false NOT NULL,
    consent_required boolean DEFAULT false NOT NULL,
    name character varying(255),
    service_accounts_enabled boolean DEFAULT false NOT NULL,
    client_authenticator_type character varying(255),
    root_url character varying(255),
    description character varying(255),
    registration_token character varying(255),
    standard_flow_enabled boolean DEFAULT true NOT NULL,
    implicit_flow_enabled boolean DEFAULT false NOT NULL,
    direct_access_grants_enabled boolean DEFAULT false NOT NULL,
    always_display_in_console boolean DEFAULT false NOT NULL
);


ALTER TABLE public.client OWNER TO keycloak;

--
-- Name: client_attributes; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_attributes (
    client_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value text
);


ALTER TABLE public.client_attributes OWNER TO keycloak;

--
-- Name: client_auth_flow_bindings; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_auth_flow_bindings (
    client_id character varying(36) NOT NULL,
    flow_id character varying(36),
    binding_name character varying(255) NOT NULL
);


ALTER TABLE public.client_auth_flow_bindings OWNER TO keycloak;

--
-- Name: client_initial_access; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_initial_access (
    id character varying(36) NOT NULL,
    realm_id character varying(36) NOT NULL,
    "timestamp" integer,
    expiration integer,
    count integer,
    remaining_count integer
);


ALTER TABLE public.client_initial_access OWNER TO keycloak;

--
-- Name: client_node_registrations; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_node_registrations (
    client_id character varying(36) NOT NULL,
    value integer,
    name character varying(255) NOT NULL
);


ALTER TABLE public.client_node_registrations OWNER TO keycloak;

--
-- Name: client_scope; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_scope (
    id character varying(36) NOT NULL,
    name character varying(255),
    realm_id character varying(36),
    description character varying(255),
    protocol character varying(255)
);


ALTER TABLE public.client_scope OWNER TO keycloak;

--
-- Name: client_scope_attributes; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_scope_attributes (
    scope_id character varying(36) NOT NULL,
    value character varying(2048),
    name character varying(255) NOT NULL
);


ALTER TABLE public.client_scope_attributes OWNER TO keycloak;

--
-- Name: client_scope_client; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_scope_client (
    client_id character varying(255) NOT NULL,
    scope_id character varying(255) NOT NULL,
    default_scope boolean DEFAULT false NOT NULL
);


ALTER TABLE public.client_scope_client OWNER TO keycloak;

--
-- Name: client_scope_role_mapping; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_scope_role_mapping (
    scope_id character varying(36) NOT NULL,
    role_id character varying(36) NOT NULL
);


ALTER TABLE public.client_scope_role_mapping OWNER TO keycloak;

--
-- Name: client_session; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_session (
    id character varying(36) NOT NULL,
    client_id character varying(36),
    redirect_uri character varying(255),
    state character varying(255),
    "timestamp" integer,
    session_id character varying(36),
    auth_method character varying(255),
    realm_id character varying(255),
    auth_user_id character varying(36),
    current_action character varying(36)
);


ALTER TABLE public.client_session OWNER TO keycloak;

--
-- Name: client_session_auth_status; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_session_auth_status (
    authenticator character varying(36) NOT NULL,
    status integer,
    client_session character varying(36) NOT NULL
);


ALTER TABLE public.client_session_auth_status OWNER TO keycloak;

--
-- Name: client_session_note; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_session_note (
    name character varying(255) NOT NULL,
    value character varying(255),
    client_session character varying(36) NOT NULL
);


ALTER TABLE public.client_session_note OWNER TO keycloak;

--
-- Name: client_session_prot_mapper; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_session_prot_mapper (
    protocol_mapper_id character varying(36) NOT NULL,
    client_session character varying(36) NOT NULL
);


ALTER TABLE public.client_session_prot_mapper OWNER TO keycloak;

--
-- Name: client_session_role; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_session_role (
    role_id character varying(255) NOT NULL,
    client_session character varying(36) NOT NULL
);


ALTER TABLE public.client_session_role OWNER TO keycloak;

--
-- Name: client_user_session_note; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.client_user_session_note (
    name character varying(255) NOT NULL,
    value character varying(2048),
    client_session character varying(36) NOT NULL
);


ALTER TABLE public.client_user_session_note OWNER TO keycloak;

--
-- Name: component; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.component (
    id character varying(36) NOT NULL,
    name character varying(255),
    parent_id character varying(36),
    provider_id character varying(36),
    provider_type character varying(255),
    realm_id character varying(36),
    sub_type character varying(255)
);


ALTER TABLE public.component OWNER TO keycloak;

--
-- Name: component_config; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.component_config (
    id character varying(36) NOT NULL,
    component_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value text
);


ALTER TABLE public.component_config OWNER TO keycloak;

--
-- Name: composite_role; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.composite_role (
    composite character varying(36) NOT NULL,
    child_role character varying(36) NOT NULL
);


ALTER TABLE public.composite_role OWNER TO keycloak;

--
-- Name: credential; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.credential (
    id character varying(36) NOT NULL,
    salt bytea,
    type character varying(255),
    user_id character varying(36),
    created_date bigint,
    user_label character varying(255),
    secret_data text,
    credential_data text,
    priority integer
);


ALTER TABLE public.credential OWNER TO keycloak;

--
-- Name: databasechangelog; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.databasechangelog (
    id character varying(255) NOT NULL,
    author character varying(255) NOT NULL,
    filename character varying(255) NOT NULL,
    dateexecuted timestamp without time zone NOT NULL,
    orderexecuted integer NOT NULL,
    exectype character varying(10) NOT NULL,
    md5sum character varying(35),
    description character varying(255),
    comments character varying(255),
    tag character varying(255),
    liquibase character varying(20),
    contexts character varying(255),
    labels character varying(255),
    deployment_id character varying(10)
);


ALTER TABLE public.databasechangelog OWNER TO keycloak;

--
-- Name: databasechangeloglock; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.databasechangeloglock (
    id integer NOT NULL,
    locked boolean NOT NULL,
    lockgranted timestamp without time zone,
    lockedby character varying(255)
);


ALTER TABLE public.databasechangeloglock OWNER TO keycloak;

--
-- Name: default_client_scope; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.default_client_scope (
    realm_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL,
    default_scope boolean DEFAULT false NOT NULL
);


ALTER TABLE public.default_client_scope OWNER TO keycloak;

--
-- Name: event_entity; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.event_entity (
    id character varying(36) NOT NULL,
    client_id character varying(255),
    details_json character varying(2550),
    error character varying(255),
    ip_address character varying(255),
    realm_id character varying(255),
    session_id character varying(255),
    event_time bigint,
    type character varying(255),
    user_id character varying(255),
    details_json_long_value text
);


ALTER TABLE public.event_entity OWNER TO keycloak;

--
-- Name: fed_user_attribute; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.fed_user_attribute (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36),
    value character varying(2024)
);


ALTER TABLE public.fed_user_attribute OWNER TO keycloak;

--
-- Name: fed_user_consent; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.fed_user_consent (
    id character varying(36) NOT NULL,
    client_id character varying(255),
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36),
    created_date bigint,
    last_updated_date bigint,
    client_storage_provider character varying(36),
    external_client_id character varying(255)
);


ALTER TABLE public.fed_user_consent OWNER TO keycloak;

--
-- Name: fed_user_consent_cl_scope; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.fed_user_consent_cl_scope (
    user_consent_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL
);


ALTER TABLE public.fed_user_consent_cl_scope OWNER TO keycloak;

--
-- Name: fed_user_credential; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.fed_user_credential (
    id character varying(36) NOT NULL,
    salt bytea,
    type character varying(255),
    created_date bigint,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36),
    user_label character varying(255),
    secret_data text,
    credential_data text,
    priority integer
);


ALTER TABLE public.fed_user_credential OWNER TO keycloak;

--
-- Name: fed_user_group_membership; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.fed_user_group_membership (
    group_id character varying(36) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36)
);


ALTER TABLE public.fed_user_group_membership OWNER TO keycloak;

--
-- Name: fed_user_required_action; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.fed_user_required_action (
    required_action character varying(255) DEFAULT ' '::character varying NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36)
);


ALTER TABLE public.fed_user_required_action OWNER TO keycloak;

--
-- Name: fed_user_role_mapping; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.fed_user_role_mapping (
    role_id character varying(36) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36)
);


ALTER TABLE public.fed_user_role_mapping OWNER TO keycloak;

--
-- Name: federated_identity; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.federated_identity (
    identity_provider character varying(255) NOT NULL,
    realm_id character varying(36),
    federated_user_id character varying(255),
    federated_username character varying(255),
    token text,
    user_id character varying(36) NOT NULL
);


ALTER TABLE public.federated_identity OWNER TO keycloak;

--
-- Name: federated_user; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.federated_user (
    id character varying(255) NOT NULL,
    storage_provider_id character varying(255),
    realm_id character varying(36) NOT NULL
);


ALTER TABLE public.federated_user OWNER TO keycloak;

--
-- Name: group_attribute; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.group_attribute (
    id character varying(36) DEFAULT 'sybase-needs-something-here'::character varying NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(255),
    group_id character varying(36) NOT NULL
);


ALTER TABLE public.group_attribute OWNER TO keycloak;

--
-- Name: group_role_mapping; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.group_role_mapping (
    role_id character varying(36) NOT NULL,
    group_id character varying(36) NOT NULL
);


ALTER TABLE public.group_role_mapping OWNER TO keycloak;

--
-- Name: identity_provider; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.identity_provider (
    internal_id character varying(36) NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    provider_alias character varying(255),
    provider_id character varying(255),
    store_token boolean DEFAULT false NOT NULL,
    authenticate_by_default boolean DEFAULT false NOT NULL,
    realm_id character varying(36),
    add_token_role boolean DEFAULT true NOT NULL,
    trust_email boolean DEFAULT false NOT NULL,
    first_broker_login_flow_id character varying(36),
    post_broker_login_flow_id character varying(36),
    provider_display_name character varying(255),
    link_only boolean DEFAULT false NOT NULL
);


ALTER TABLE public.identity_provider OWNER TO keycloak;

--
-- Name: identity_provider_config; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.identity_provider_config (
    identity_provider_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.identity_provider_config OWNER TO keycloak;

--
-- Name: identity_provider_mapper; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.identity_provider_mapper (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    idp_alias character varying(255) NOT NULL,
    idp_mapper_name character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL
);


ALTER TABLE public.identity_provider_mapper OWNER TO keycloak;

--
-- Name: idp_mapper_config; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.idp_mapper_config (
    idp_mapper_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.idp_mapper_config OWNER TO keycloak;

--
-- Name: keycloak_group; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.keycloak_group (
    id character varying(36) NOT NULL,
    name character varying(255),
    parent_group character varying(36) NOT NULL,
    realm_id character varying(36)
);


ALTER TABLE public.keycloak_group OWNER TO keycloak;

--
-- Name: keycloak_role; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.keycloak_role (
    id character varying(36) NOT NULL,
    client_realm_constraint character varying(255),
    client_role boolean DEFAULT false NOT NULL,
    description character varying(255),
    name character varying(255),
    realm_id character varying(255),
    client character varying(36),
    realm character varying(36)
);


ALTER TABLE public.keycloak_role OWNER TO keycloak;

--
-- Name: migration_model; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.migration_model (
    id character varying(36) NOT NULL,
    version character varying(36),
    update_time bigint DEFAULT 0 NOT NULL
);


ALTER TABLE public.migration_model OWNER TO keycloak;

--
-- Name: offline_client_session; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.offline_client_session (
    user_session_id character varying(36) NOT NULL,
    client_id character varying(255) NOT NULL,
    offline_flag character varying(4) NOT NULL,
    "timestamp" integer,
    data text,
    client_storage_provider character varying(36) DEFAULT 'local'::character varying NOT NULL,
    external_client_id character varying(255) DEFAULT 'local'::character varying NOT NULL
);


ALTER TABLE public.offline_client_session OWNER TO keycloak;

--
-- Name: offline_user_session; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.offline_user_session (
    user_session_id character varying(36) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    created_on integer NOT NULL,
    offline_flag character varying(4) NOT NULL,
    data text,
    last_session_refresh integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.offline_user_session OWNER TO keycloak;

--
-- Name: policy_config; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.policy_config (
    policy_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value text
);


ALTER TABLE public.policy_config OWNER TO keycloak;

--
-- Name: protocol_mapper; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.protocol_mapper (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    protocol character varying(255) NOT NULL,
    protocol_mapper_name character varying(255) NOT NULL,
    client_id character varying(36),
    client_scope_id character varying(36)
);


ALTER TABLE public.protocol_mapper OWNER TO keycloak;

--
-- Name: protocol_mapper_config; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.protocol_mapper_config (
    protocol_mapper_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.protocol_mapper_config OWNER TO keycloak;

--
-- Name: realm; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.realm (
    id character varying(36) NOT NULL,
    access_code_lifespan integer,
    user_action_lifespan integer,
    access_token_lifespan integer,
    account_theme character varying(255),
    admin_theme character varying(255),
    email_theme character varying(255),
    enabled boolean DEFAULT false NOT NULL,
    events_enabled boolean DEFAULT false NOT NULL,
    events_expiration bigint,
    login_theme character varying(255),
    name character varying(255),
    not_before integer,
    password_policy character varying(2550),
    registration_allowed boolean DEFAULT false NOT NULL,
    remember_me boolean DEFAULT false NOT NULL,
    reset_password_allowed boolean DEFAULT false NOT NULL,
    social boolean DEFAULT false NOT NULL,
    ssl_required character varying(255),
    sso_idle_timeout integer,
    sso_max_lifespan integer,
    update_profile_on_soc_login boolean DEFAULT false NOT NULL,
    verify_email boolean DEFAULT false NOT NULL,
    master_admin_client character varying(36),
    login_lifespan integer,
    internationalization_enabled boolean DEFAULT false NOT NULL,
    default_locale character varying(255),
    reg_email_as_username boolean DEFAULT false NOT NULL,
    admin_events_enabled boolean DEFAULT false NOT NULL,
    admin_events_details_enabled boolean DEFAULT false NOT NULL,
    edit_username_allowed boolean DEFAULT false NOT NULL,
    otp_policy_counter integer DEFAULT 0,
    otp_policy_window integer DEFAULT 1,
    otp_policy_period integer DEFAULT 30,
    otp_policy_digits integer DEFAULT 6,
    otp_policy_alg character varying(36) DEFAULT 'HmacSHA1'::character varying,
    otp_policy_type character varying(36) DEFAULT 'totp'::character varying,
    browser_flow character varying(36),
    registration_flow character varying(36),
    direct_grant_flow character varying(36),
    reset_credentials_flow character varying(36),
    client_auth_flow character varying(36),
    offline_session_idle_timeout integer DEFAULT 0,
    revoke_refresh_token boolean DEFAULT false NOT NULL,
    access_token_life_implicit integer DEFAULT 0,
    login_with_email_allowed boolean DEFAULT true NOT NULL,
    duplicate_emails_allowed boolean DEFAULT false NOT NULL,
    docker_auth_flow character varying(36),
    refresh_token_max_reuse integer DEFAULT 0,
    allow_user_managed_access boolean DEFAULT false NOT NULL,
    sso_max_lifespan_remember_me integer DEFAULT 0 NOT NULL,
    sso_idle_timeout_remember_me integer DEFAULT 0 NOT NULL,
    default_role character varying(255)
);


ALTER TABLE public.realm OWNER TO keycloak;

--
-- Name: realm_attribute; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.realm_attribute (
    name character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    value text
);


ALTER TABLE public.realm_attribute OWNER TO keycloak;

--
-- Name: realm_default_groups; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.realm_default_groups (
    realm_id character varying(36) NOT NULL,
    group_id character varying(36) NOT NULL
);


ALTER TABLE public.realm_default_groups OWNER TO keycloak;

--
-- Name: realm_enabled_event_types; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.realm_enabled_event_types (
    realm_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.realm_enabled_event_types OWNER TO keycloak;

--
-- Name: realm_events_listeners; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.realm_events_listeners (
    realm_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.realm_events_listeners OWNER TO keycloak;

--
-- Name: realm_localizations; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.realm_localizations (
    realm_id character varying(255) NOT NULL,
    locale character varying(255) NOT NULL,
    texts text NOT NULL
);


ALTER TABLE public.realm_localizations OWNER TO keycloak;

--
-- Name: realm_required_credential; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.realm_required_credential (
    type character varying(255) NOT NULL,
    form_label character varying(255),
    input boolean DEFAULT false NOT NULL,
    secret boolean DEFAULT false NOT NULL,
    realm_id character varying(36) NOT NULL
);


ALTER TABLE public.realm_required_credential OWNER TO keycloak;

--
-- Name: realm_smtp_config; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.realm_smtp_config (
    realm_id character varying(36) NOT NULL,
    value character varying(255),
    name character varying(255) NOT NULL
);


ALTER TABLE public.realm_smtp_config OWNER TO keycloak;

--
-- Name: realm_supported_locales; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.realm_supported_locales (
    realm_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.realm_supported_locales OWNER TO keycloak;

--
-- Name: redirect_uris; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.redirect_uris (
    client_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.redirect_uris OWNER TO keycloak;

--
-- Name: required_action_config; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.required_action_config (
    required_action_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.required_action_config OWNER TO keycloak;

--
-- Name: required_action_provider; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.required_action_provider (
    id character varying(36) NOT NULL,
    alias character varying(255),
    name character varying(255),
    realm_id character varying(36),
    enabled boolean DEFAULT false NOT NULL,
    default_action boolean DEFAULT false NOT NULL,
    provider_id character varying(255),
    priority integer
);


ALTER TABLE public.required_action_provider OWNER TO keycloak;

--
-- Name: resource_attribute; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.resource_attribute (
    id character varying(36) DEFAULT 'sybase-needs-something-here'::character varying NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(255),
    resource_id character varying(36) NOT NULL
);


ALTER TABLE public.resource_attribute OWNER TO keycloak;

--
-- Name: resource_policy; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.resource_policy (
    resource_id character varying(36) NOT NULL,
    policy_id character varying(36) NOT NULL
);


ALTER TABLE public.resource_policy OWNER TO keycloak;

--
-- Name: resource_scope; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.resource_scope (
    resource_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL
);


ALTER TABLE public.resource_scope OWNER TO keycloak;

--
-- Name: resource_server; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.resource_server (
    id character varying(36) NOT NULL,
    allow_rs_remote_mgmt boolean DEFAULT false NOT NULL,
    policy_enforce_mode smallint NOT NULL,
    decision_strategy smallint DEFAULT 1 NOT NULL
);


ALTER TABLE public.resource_server OWNER TO keycloak;

--
-- Name: resource_server_perm_ticket; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.resource_server_perm_ticket (
    id character varying(36) NOT NULL,
    owner character varying(255) NOT NULL,
    requester character varying(255) NOT NULL,
    created_timestamp bigint NOT NULL,
    granted_timestamp bigint,
    resource_id character varying(36) NOT NULL,
    scope_id character varying(36),
    resource_server_id character varying(36) NOT NULL,
    policy_id character varying(36)
);


ALTER TABLE public.resource_server_perm_ticket OWNER TO keycloak;

--
-- Name: resource_server_policy; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.resource_server_policy (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255),
    type character varying(255) NOT NULL,
    decision_strategy smallint,
    logic smallint,
    resource_server_id character varying(36) NOT NULL,
    owner character varying(255)
);


ALTER TABLE public.resource_server_policy OWNER TO keycloak;

--
-- Name: resource_server_resource; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.resource_server_resource (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(255),
    icon_uri character varying(255),
    owner character varying(255) NOT NULL,
    resource_server_id character varying(36) NOT NULL,
    owner_managed_access boolean DEFAULT false NOT NULL,
    display_name character varying(255)
);


ALTER TABLE public.resource_server_resource OWNER TO keycloak;

--
-- Name: resource_server_scope; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.resource_server_scope (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    icon_uri character varying(255),
    resource_server_id character varying(36) NOT NULL,
    display_name character varying(255)
);


ALTER TABLE public.resource_server_scope OWNER TO keycloak;

--
-- Name: resource_uris; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.resource_uris (
    resource_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.resource_uris OWNER TO keycloak;

--
-- Name: role_attribute; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.role_attribute (
    id character varying(36) NOT NULL,
    role_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(255)
);


ALTER TABLE public.role_attribute OWNER TO keycloak;

--
-- Name: scope_mapping; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.scope_mapping (
    client_id character varying(36) NOT NULL,
    role_id character varying(36) NOT NULL
);


ALTER TABLE public.scope_mapping OWNER TO keycloak;

--
-- Name: scope_policy; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.scope_policy (
    scope_id character varying(36) NOT NULL,
    policy_id character varying(36) NOT NULL
);


ALTER TABLE public.scope_policy OWNER TO keycloak;

--
-- Name: user_attribute; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_attribute (
    name character varying(255) NOT NULL,
    value character varying(255),
    user_id character varying(36) NOT NULL,
    id character varying(36) DEFAULT 'sybase-needs-something-here'::character varying NOT NULL
);


ALTER TABLE public.user_attribute OWNER TO keycloak;

--
-- Name: user_consent; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_consent (
    id character varying(36) NOT NULL,
    client_id character varying(255),
    user_id character varying(36) NOT NULL,
    created_date bigint,
    last_updated_date bigint,
    client_storage_provider character varying(36),
    external_client_id character varying(255)
);


ALTER TABLE public.user_consent OWNER TO keycloak;

--
-- Name: user_consent_client_scope; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_consent_client_scope (
    user_consent_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL
);


ALTER TABLE public.user_consent_client_scope OWNER TO keycloak;

--
-- Name: user_entity; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_entity (
    id character varying(36) NOT NULL,
    email character varying(255),
    email_constraint character varying(255),
    email_verified boolean DEFAULT false NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    federation_link character varying(255),
    first_name character varying(255),
    last_name character varying(255),
    realm_id character varying(255),
    username character varying(255),
    created_timestamp bigint,
    service_account_client_link character varying(255),
    not_before integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.user_entity OWNER TO keycloak;

--
-- Name: user_federation_config; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_federation_config (
    user_federation_provider_id character varying(36) NOT NULL,
    value character varying(255),
    name character varying(255) NOT NULL
);


ALTER TABLE public.user_federation_config OWNER TO keycloak;

--
-- Name: user_federation_mapper; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_federation_mapper (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    federation_provider_id character varying(36) NOT NULL,
    federation_mapper_type character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL
);


ALTER TABLE public.user_federation_mapper OWNER TO keycloak;

--
-- Name: user_federation_mapper_config; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_federation_mapper_config (
    user_federation_mapper_id character varying(36) NOT NULL,
    value character varying(255),
    name character varying(255) NOT NULL
);


ALTER TABLE public.user_federation_mapper_config OWNER TO keycloak;

--
-- Name: user_federation_provider; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_federation_provider (
    id character varying(36) NOT NULL,
    changed_sync_period integer,
    display_name character varying(255),
    full_sync_period integer,
    last_sync integer,
    priority integer,
    provider_name character varying(255),
    realm_id character varying(36)
);


ALTER TABLE public.user_federation_provider OWNER TO keycloak;

--
-- Name: user_group_membership; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_group_membership (
    group_id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL
);


ALTER TABLE public.user_group_membership OWNER TO keycloak;

--
-- Name: user_required_action; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_required_action (
    user_id character varying(36) NOT NULL,
    required_action character varying(255) DEFAULT ' '::character varying NOT NULL
);


ALTER TABLE public.user_required_action OWNER TO keycloak;

--
-- Name: user_role_mapping; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_role_mapping (
    role_id character varying(255) NOT NULL,
    user_id character varying(36) NOT NULL
);


ALTER TABLE public.user_role_mapping OWNER TO keycloak;

--
-- Name: user_session; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_session (
    id character varying(36) NOT NULL,
    auth_method character varying(255),
    ip_address character varying(255),
    last_session_refresh integer,
    login_username character varying(255),
    realm_id character varying(255),
    remember_me boolean DEFAULT false NOT NULL,
    started integer,
    user_id character varying(255),
    user_session_state integer,
    broker_session_id character varying(255),
    broker_user_id character varying(255)
);


ALTER TABLE public.user_session OWNER TO keycloak;

--
-- Name: user_session_note; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.user_session_note (
    user_session character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(2048)
);


ALTER TABLE public.user_session_note OWNER TO keycloak;

--
-- Name: username_login_failure; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.username_login_failure (
    realm_id character varying(36) NOT NULL,
    username character varying(255) NOT NULL,
    failed_login_not_before integer,
    last_failure bigint,
    last_ip_failure character varying(255),
    num_failures integer
);


ALTER TABLE public.username_login_failure OWNER TO keycloak;

--
-- Name: web_origins; Type: TABLE; Schema: public; Owner: keycloak
--

CREATE TABLE public.web_origins (
    client_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.web_origins OWNER TO keycloak;

--
-- Data for Name: admin_event_entity; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.admin_event_entity (id, admin_event_time, realm_id, operation_type, auth_realm_id, auth_client_id, auth_user_id, ip_address, resource_path, representation, error, resource_type) FROM stdin;
\.


--
-- Data for Name: associated_policy; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.associated_policy (policy_id, associated_policy_id) FROM stdin;
\.


--
-- Data for Name: authentication_execution; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.authentication_execution (id, alias, authenticator, realm_id, flow_id, requirement, priority, authenticator_flow, auth_flow_id, auth_config) FROM stdin;
2d30ff18-7e9b-466c-86f7-7f06ae7fd62c	\N	auth-cookie	e18440d9-9a37-4182-b5a6-d24a52fbe8de	9bf036b3-6edd-4367-af91-7a034a212dfc	2	10	f	\N	\N
8ebf561c-6742-4436-88fc-cb36c9524d2c	\N	auth-spnego	e18440d9-9a37-4182-b5a6-d24a52fbe8de	9bf036b3-6edd-4367-af91-7a034a212dfc	3	20	f	\N	\N
183d103f-0565-4c5a-9c8e-232d1afed14f	\N	identity-provider-redirector	e18440d9-9a37-4182-b5a6-d24a52fbe8de	9bf036b3-6edd-4367-af91-7a034a212dfc	2	25	f	\N	\N
e9c611ca-3465-44da-a064-6e423d69a57c	\N	\N	e18440d9-9a37-4182-b5a6-d24a52fbe8de	9bf036b3-6edd-4367-af91-7a034a212dfc	2	30	t	3a3e2a78-1955-45c0-87ed-66949b62348f	\N
cc1e1c3a-a6db-40fa-89b1-c0626cf25cc0	\N	auth-username-password-form	e18440d9-9a37-4182-b5a6-d24a52fbe8de	3a3e2a78-1955-45c0-87ed-66949b62348f	0	10	f	\N	\N
cb961aaa-568f-4e5e-b6de-8948ca6bc97c	\N	\N	e18440d9-9a37-4182-b5a6-d24a52fbe8de	3a3e2a78-1955-45c0-87ed-66949b62348f	1	20	t	7e097cc8-8ae2-4aa8-a2b6-38a248c2c751	\N
5d121d30-b243-49fb-9df9-89ba85c7a09b	\N	conditional-user-configured	e18440d9-9a37-4182-b5a6-d24a52fbe8de	7e097cc8-8ae2-4aa8-a2b6-38a248c2c751	0	10	f	\N	\N
2203bca7-f5ba-4549-b656-08b24e046ab4	\N	auth-otp-form	e18440d9-9a37-4182-b5a6-d24a52fbe8de	7e097cc8-8ae2-4aa8-a2b6-38a248c2c751	0	20	f	\N	\N
ca3fbe31-2de7-404b-a22a-d480637ad52e	\N	direct-grant-validate-username	e18440d9-9a37-4182-b5a6-d24a52fbe8de	05b1cce1-de38-4770-bf81-1f1fe75b4094	0	10	f	\N	\N
bcbc467a-7377-4faf-a7fa-2103b599c464	\N	direct-grant-validate-password	e18440d9-9a37-4182-b5a6-d24a52fbe8de	05b1cce1-de38-4770-bf81-1f1fe75b4094	0	20	f	\N	\N
64b1b712-9588-4eaf-8da6-a86d219efad3	\N	\N	e18440d9-9a37-4182-b5a6-d24a52fbe8de	05b1cce1-de38-4770-bf81-1f1fe75b4094	1	30	t	a7e9b7ad-aa09-4ff0-b50f-b410abb6c7cf	\N
9f7758e6-9d14-4b1d-9b6c-ac18934d1ee0	\N	conditional-user-configured	e18440d9-9a37-4182-b5a6-d24a52fbe8de	a7e9b7ad-aa09-4ff0-b50f-b410abb6c7cf	0	10	f	\N	\N
dd92b93f-3fbc-4521-bc0a-c26c461e88be	\N	direct-grant-validate-otp	e18440d9-9a37-4182-b5a6-d24a52fbe8de	a7e9b7ad-aa09-4ff0-b50f-b410abb6c7cf	0	20	f	\N	\N
0a029954-2b59-4113-832b-94576469c2c0	\N	registration-page-form	e18440d9-9a37-4182-b5a6-d24a52fbe8de	7aa76e0a-f608-4abc-b44b-faa8377353eb	0	10	t	96ce17f4-eef7-443b-a9be-b82289e5c1b5	\N
3fd4ba02-da30-4b22-b59c-c62d9a298454	\N	registration-user-creation	e18440d9-9a37-4182-b5a6-d24a52fbe8de	96ce17f4-eef7-443b-a9be-b82289e5c1b5	0	20	f	\N	\N
e2f663c2-a6e0-4454-b031-0c4277ebb699	\N	registration-password-action	e18440d9-9a37-4182-b5a6-d24a52fbe8de	96ce17f4-eef7-443b-a9be-b82289e5c1b5	0	50	f	\N	\N
e0be4731-4668-411e-a489-f8c040da2332	\N	registration-recaptcha-action	e18440d9-9a37-4182-b5a6-d24a52fbe8de	96ce17f4-eef7-443b-a9be-b82289e5c1b5	3	60	f	\N	\N
a43c72ea-0aa2-4a16-9f59-b9cce043dfde	\N	registration-terms-and-conditions	e18440d9-9a37-4182-b5a6-d24a52fbe8de	96ce17f4-eef7-443b-a9be-b82289e5c1b5	3	70	f	\N	\N
25a6f633-d2f7-4fb4-946c-e95331c62408	\N	reset-credentials-choose-user	e18440d9-9a37-4182-b5a6-d24a52fbe8de	ed82d486-fb35-4568-b46c-411bb9337d09	0	10	f	\N	\N
c7f4aac4-6b90-454f-90bc-541374feb247	\N	reset-credential-email	e18440d9-9a37-4182-b5a6-d24a52fbe8de	ed82d486-fb35-4568-b46c-411bb9337d09	0	20	f	\N	\N
464407b2-0c0a-4448-a216-15c46dd34df7	\N	reset-password	e18440d9-9a37-4182-b5a6-d24a52fbe8de	ed82d486-fb35-4568-b46c-411bb9337d09	0	30	f	\N	\N
1fae9381-f3ed-4d7d-8098-f476ae19e4be	\N	\N	e18440d9-9a37-4182-b5a6-d24a52fbe8de	ed82d486-fb35-4568-b46c-411bb9337d09	1	40	t	c770c022-9d5d-44c8-849f-83ecef994648	\N
9e69fe12-cfbd-4e6b-a2a7-574d570b8940	\N	conditional-user-configured	e18440d9-9a37-4182-b5a6-d24a52fbe8de	c770c022-9d5d-44c8-849f-83ecef994648	0	10	f	\N	\N
8ce97b20-ff03-4511-a68f-861d0815e75a	\N	reset-otp	e18440d9-9a37-4182-b5a6-d24a52fbe8de	c770c022-9d5d-44c8-849f-83ecef994648	0	20	f	\N	\N
85a322dd-2802-4774-8835-b6be0f86af70	\N	client-secret	e18440d9-9a37-4182-b5a6-d24a52fbe8de	f214df70-bf55-4add-aaf7-646b9939aec9	2	10	f	\N	\N
378b6472-c138-4305-b950-71ce57426741	\N	client-jwt	e18440d9-9a37-4182-b5a6-d24a52fbe8de	f214df70-bf55-4add-aaf7-646b9939aec9	2	20	f	\N	\N
fcce117c-d256-4f59-b4cf-eb7344560e8f	\N	client-secret-jwt	e18440d9-9a37-4182-b5a6-d24a52fbe8de	f214df70-bf55-4add-aaf7-646b9939aec9	2	30	f	\N	\N
d61c5c0c-b037-4ae6-812e-122ba41e3315	\N	client-x509	e18440d9-9a37-4182-b5a6-d24a52fbe8de	f214df70-bf55-4add-aaf7-646b9939aec9	2	40	f	\N	\N
0f66d012-9c76-416b-81d8-898c00b7d9c4	\N	idp-review-profile	e18440d9-9a37-4182-b5a6-d24a52fbe8de	3e317944-5bf7-430c-957f-28a0362acd58	0	10	f	\N	07fecfb8-2cc2-4ed2-88c4-da4523d00b6a
5fae2cc5-ff07-47d5-a19e-5628a59eec8a	\N	\N	e18440d9-9a37-4182-b5a6-d24a52fbe8de	3e317944-5bf7-430c-957f-28a0362acd58	0	20	t	803bc540-f5cb-45f2-a934-8536c5f5efc7	\N
9e3d2e71-142d-4eca-9e3d-e234becc197a	\N	idp-create-user-if-unique	e18440d9-9a37-4182-b5a6-d24a52fbe8de	803bc540-f5cb-45f2-a934-8536c5f5efc7	2	10	f	\N	d7996f80-c0a7-4a3e-a055-1b8a6e253d3b
d495242c-1ec8-4a50-bb73-b81cadf60489	\N	\N	e18440d9-9a37-4182-b5a6-d24a52fbe8de	803bc540-f5cb-45f2-a934-8536c5f5efc7	2	20	t	ffe5aabe-321f-4a0a-a04a-1e834c69c0b8	\N
fd2f6b64-6e9e-4833-8e00-4f215a0f943c	\N	idp-confirm-link	e18440d9-9a37-4182-b5a6-d24a52fbe8de	ffe5aabe-321f-4a0a-a04a-1e834c69c0b8	0	10	f	\N	\N
985af4df-8fb2-431d-9750-568422ebcbc9	\N	\N	e18440d9-9a37-4182-b5a6-d24a52fbe8de	ffe5aabe-321f-4a0a-a04a-1e834c69c0b8	0	20	t	41e6fc20-1a9a-4368-973e-c1cc4c0c8285	\N
a0e3d3ee-879c-4175-a3b7-c4262ba3dfcf	\N	idp-email-verification	e18440d9-9a37-4182-b5a6-d24a52fbe8de	41e6fc20-1a9a-4368-973e-c1cc4c0c8285	2	10	f	\N	\N
0124f6ed-3c5e-48a6-856e-43283d4439bd	\N	\N	e18440d9-9a37-4182-b5a6-d24a52fbe8de	41e6fc20-1a9a-4368-973e-c1cc4c0c8285	2	20	t	90d8f974-d73e-49c4-b838-183751740c23	\N
e6176de2-a4fd-4ecb-99ad-190c5d584314	\N	idp-username-password-form	e18440d9-9a37-4182-b5a6-d24a52fbe8de	90d8f974-d73e-49c4-b838-183751740c23	0	10	f	\N	\N
70e5cd91-c93d-4d61-b4f6-a17f40237b9f	\N	\N	e18440d9-9a37-4182-b5a6-d24a52fbe8de	90d8f974-d73e-49c4-b838-183751740c23	1	20	t	9dd28cb0-0b9c-4623-995c-f7a4537c1886	\N
8e28b9a4-0899-42a5-ae45-b1419f6ed68f	\N	conditional-user-configured	e18440d9-9a37-4182-b5a6-d24a52fbe8de	9dd28cb0-0b9c-4623-995c-f7a4537c1886	0	10	f	\N	\N
e037f13b-3c16-42d9-857c-ff59ccbf0fb7	\N	auth-otp-form	e18440d9-9a37-4182-b5a6-d24a52fbe8de	9dd28cb0-0b9c-4623-995c-f7a4537c1886	0	20	f	\N	\N
38c35c3c-bbfc-4fdb-8116-dd625bec8735	\N	http-basic-authenticator	e18440d9-9a37-4182-b5a6-d24a52fbe8de	1b5bdfe6-9a14-48ba-8fa8-641c5ac8f1e7	0	10	f	\N	\N
52fcacb9-357d-422f-adca-e216525beff6	\N	docker-http-basic-authenticator	e18440d9-9a37-4182-b5a6-d24a52fbe8de	7328656d-c1de-4ff8-99df-7d73be1aa463	0	10	f	\N	\N
b414d417-580b-4b6b-956f-6903303af447	\N	auth-cookie	deffec2e-91ce-4521-869a-fabb8944dc44	d28e53b3-5ce0-4353-b4ca-9a8320b90da6	2	10	f	\N	\N
53b77631-70ad-4dda-a24d-767c8dee91c1	\N	auth-spnego	deffec2e-91ce-4521-869a-fabb8944dc44	d28e53b3-5ce0-4353-b4ca-9a8320b90da6	3	20	f	\N	\N
3657dbd1-e75c-4673-8b21-6abcffa13587	\N	identity-provider-redirector	deffec2e-91ce-4521-869a-fabb8944dc44	d28e53b3-5ce0-4353-b4ca-9a8320b90da6	2	25	f	\N	\N
be0991d8-177d-4ff7-b119-e9ba15042231	\N	\N	deffec2e-91ce-4521-869a-fabb8944dc44	d28e53b3-5ce0-4353-b4ca-9a8320b90da6	2	30	t	d6b80bd0-5a29-4c4d-8ef0-3e002f94f781	\N
064a6ea7-1e93-41b4-8cd9-841c44d245d6	\N	auth-username-password-form	deffec2e-91ce-4521-869a-fabb8944dc44	d6b80bd0-5a29-4c4d-8ef0-3e002f94f781	0	10	f	\N	\N
4c3daf24-7fe2-48b0-bbda-90c8fa4cb599	\N	\N	deffec2e-91ce-4521-869a-fabb8944dc44	d6b80bd0-5a29-4c4d-8ef0-3e002f94f781	1	20	t	fbf2eec5-4515-4a6d-a339-b6c7c23bd8c4	\N
2d80c352-4a0c-4a9e-9e09-af9bce4d6bfa	\N	conditional-user-configured	deffec2e-91ce-4521-869a-fabb8944dc44	fbf2eec5-4515-4a6d-a339-b6c7c23bd8c4	0	10	f	\N	\N
bc706abc-9dbf-4878-8208-d67d03d24953	\N	auth-otp-form	deffec2e-91ce-4521-869a-fabb8944dc44	fbf2eec5-4515-4a6d-a339-b6c7c23bd8c4	0	20	f	\N	\N
dcac6634-75f9-4a72-85d1-322898fcbbf0	\N	direct-grant-validate-username	deffec2e-91ce-4521-869a-fabb8944dc44	47fcc61e-1b30-455c-90e7-eba2c612f5ee	0	10	f	\N	\N
895a7a79-c6aa-41cb-93dd-7f3f338ac8f0	\N	direct-grant-validate-password	deffec2e-91ce-4521-869a-fabb8944dc44	47fcc61e-1b30-455c-90e7-eba2c612f5ee	0	20	f	\N	\N
e6d578e2-00ef-41a0-9e01-1c98f32ab621	\N	\N	deffec2e-91ce-4521-869a-fabb8944dc44	47fcc61e-1b30-455c-90e7-eba2c612f5ee	1	30	t	a8327282-45be-4a0a-88e7-44839081a3e2	\N
7d72985d-5790-440a-a887-a1dddb71ddc5	\N	conditional-user-configured	deffec2e-91ce-4521-869a-fabb8944dc44	a8327282-45be-4a0a-88e7-44839081a3e2	0	10	f	\N	\N
b924127f-56fb-44e3-9766-f4cf1b3d2ab7	\N	direct-grant-validate-otp	deffec2e-91ce-4521-869a-fabb8944dc44	a8327282-45be-4a0a-88e7-44839081a3e2	0	20	f	\N	\N
15af9c00-0f92-472c-be0e-37353de26589	\N	registration-page-form	deffec2e-91ce-4521-869a-fabb8944dc44	9efa3170-4d5c-492b-b7ba-3a123290610d	0	10	t	d8f33a15-cb7c-4d16-9f1d-8c03f22384f5	\N
c453b5d1-6f62-4b5c-bcdd-616d43b98833	\N	registration-user-creation	deffec2e-91ce-4521-869a-fabb8944dc44	d8f33a15-cb7c-4d16-9f1d-8c03f22384f5	0	20	f	\N	\N
494b29d6-e272-4e04-a676-a6e56200ff6c	\N	registration-password-action	deffec2e-91ce-4521-869a-fabb8944dc44	d8f33a15-cb7c-4d16-9f1d-8c03f22384f5	0	50	f	\N	\N
134b5cba-49fa-4d79-b93b-47eeb7710584	\N	registration-recaptcha-action	deffec2e-91ce-4521-869a-fabb8944dc44	d8f33a15-cb7c-4d16-9f1d-8c03f22384f5	3	60	f	\N	\N
6f0d96c5-3627-4cc2-9d2a-7de95a163b91	\N	reset-credentials-choose-user	deffec2e-91ce-4521-869a-fabb8944dc44	2d446316-15bc-49b4-a455-848a3b44992a	0	10	f	\N	\N
c18ea237-cb93-47ef-8595-455e71fea067	\N	reset-credential-email	deffec2e-91ce-4521-869a-fabb8944dc44	2d446316-15bc-49b4-a455-848a3b44992a	0	20	f	\N	\N
fd372c5f-65a2-4d2b-8796-745b83193d69	\N	reset-password	deffec2e-91ce-4521-869a-fabb8944dc44	2d446316-15bc-49b4-a455-848a3b44992a	0	30	f	\N	\N
484066df-178b-4be8-bc45-1effa88bf7e7	\N	\N	deffec2e-91ce-4521-869a-fabb8944dc44	2d446316-15bc-49b4-a455-848a3b44992a	1	40	t	35948e13-4d51-4bb8-bfa3-7e722feb42c6	\N
04c0e72c-bce3-450f-8146-a8b267a87493	\N	conditional-user-configured	deffec2e-91ce-4521-869a-fabb8944dc44	35948e13-4d51-4bb8-bfa3-7e722feb42c6	0	10	f	\N	\N
7f1a1675-0d88-4ccd-9e6d-b935720d834e	\N	reset-otp	deffec2e-91ce-4521-869a-fabb8944dc44	35948e13-4d51-4bb8-bfa3-7e722feb42c6	0	20	f	\N	\N
bb6df839-37df-4285-867d-d0c2389b3fc5	\N	client-secret	deffec2e-91ce-4521-869a-fabb8944dc44	42db0288-44d9-40bb-a5a6-c0ea17737485	2	10	f	\N	\N
a77c2063-2a65-4f9b-b3e4-d766f81e2e56	\N	client-jwt	deffec2e-91ce-4521-869a-fabb8944dc44	42db0288-44d9-40bb-a5a6-c0ea17737485	2	20	f	\N	\N
0474f89f-da85-4712-82fa-86bb8ef63989	\N	client-secret-jwt	deffec2e-91ce-4521-869a-fabb8944dc44	42db0288-44d9-40bb-a5a6-c0ea17737485	2	30	f	\N	\N
ccf0a4f1-8f61-4a2f-a338-da2f31be1142	\N	client-x509	deffec2e-91ce-4521-869a-fabb8944dc44	42db0288-44d9-40bb-a5a6-c0ea17737485	2	40	f	\N	\N
c583b12a-942f-4b62-9cac-bdff1c048e48	\N	idp-review-profile	deffec2e-91ce-4521-869a-fabb8944dc44	0107862d-c2dc-49eb-8862-4a5623f35df3	0	10	f	\N	1c9c4b23-0dab-4e82-877d-e2384ce95ba9
9ddbe429-e115-45e6-b722-7b40ee398247	\N	\N	deffec2e-91ce-4521-869a-fabb8944dc44	0107862d-c2dc-49eb-8862-4a5623f35df3	0	20	t	ebe24b27-b7dc-4aee-8a9f-a1e4da496073	\N
6353ff99-0ef5-42b7-9879-856302c43cee	\N	idp-create-user-if-unique	deffec2e-91ce-4521-869a-fabb8944dc44	ebe24b27-b7dc-4aee-8a9f-a1e4da496073	2	10	f	\N	94e40bac-e148-4260-8360-0cc50952bb83
674b2a61-d478-470a-a767-6e69a98421ba	\N	\N	deffec2e-91ce-4521-869a-fabb8944dc44	ebe24b27-b7dc-4aee-8a9f-a1e4da496073	2	20	t	18799472-2402-4333-9d5e-a39a228e4a3d	\N
b26561ba-71ac-4c8c-ace6-d8443e31dd99	\N	idp-confirm-link	deffec2e-91ce-4521-869a-fabb8944dc44	18799472-2402-4333-9d5e-a39a228e4a3d	0	10	f	\N	\N
d24f7e02-6b74-4617-9ab4-7fb09b46802b	\N	\N	deffec2e-91ce-4521-869a-fabb8944dc44	18799472-2402-4333-9d5e-a39a228e4a3d	0	20	t	ff2a6679-2f16-4064-96d5-d05823ee1be5	\N
491a7fa2-aa32-48d1-b842-3cd530725e36	\N	idp-email-verification	deffec2e-91ce-4521-869a-fabb8944dc44	ff2a6679-2f16-4064-96d5-d05823ee1be5	2	10	f	\N	\N
83bccec8-2469-4666-a582-ca6950f21452	\N	\N	deffec2e-91ce-4521-869a-fabb8944dc44	ff2a6679-2f16-4064-96d5-d05823ee1be5	2	20	t	a22c1440-1bb2-4cc6-8ce0-271ae82d6ed7	\N
a461eb59-5930-4e07-9606-781dac741625	\N	idp-username-password-form	deffec2e-91ce-4521-869a-fabb8944dc44	a22c1440-1bb2-4cc6-8ce0-271ae82d6ed7	0	10	f	\N	\N
94ad8f16-0132-4f75-8a2f-bca2dc75a29a	\N	\N	deffec2e-91ce-4521-869a-fabb8944dc44	a22c1440-1bb2-4cc6-8ce0-271ae82d6ed7	1	20	t	cedab2ae-3c36-4cfb-80d0-da3577b72670	\N
e0c8ed27-b4b2-4f4e-87ad-cee36ebb0f63	\N	conditional-user-configured	deffec2e-91ce-4521-869a-fabb8944dc44	cedab2ae-3c36-4cfb-80d0-da3577b72670	0	10	f	\N	\N
03aea9a4-0439-4a93-8138-1545e8180c0c	\N	auth-otp-form	deffec2e-91ce-4521-869a-fabb8944dc44	cedab2ae-3c36-4cfb-80d0-da3577b72670	0	20	f	\N	\N
2a23c01b-6b33-43e5-a1e8-53aed7cb9c40	\N	http-basic-authenticator	deffec2e-91ce-4521-869a-fabb8944dc44	abee82ab-591b-417a-baec-e77c7e6ce1cf	0	10	f	\N	\N
8377f116-a8cb-4bde-9bc3-403f954e15eb	\N	docker-http-basic-authenticator	deffec2e-91ce-4521-869a-fabb8944dc44	424f9338-b1eb-4618-9c38-c717a832c535	0	10	f	\N	\N
\.


--
-- Data for Name: authentication_flow; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.authentication_flow (id, alias, description, realm_id, provider_id, top_level, built_in) FROM stdin;
9bf036b3-6edd-4367-af91-7a034a212dfc	browser	browser based authentication	e18440d9-9a37-4182-b5a6-d24a52fbe8de	basic-flow	t	t
3a3e2a78-1955-45c0-87ed-66949b62348f	forms	Username, password, otp and other auth forms.	e18440d9-9a37-4182-b5a6-d24a52fbe8de	basic-flow	f	t
7e097cc8-8ae2-4aa8-a2b6-38a248c2c751	Browser - Conditional OTP	Flow to determine if the OTP is required for the authentication	e18440d9-9a37-4182-b5a6-d24a52fbe8de	basic-flow	f	t
05b1cce1-de38-4770-bf81-1f1fe75b4094	direct grant	OpenID Connect Resource Owner Grant	e18440d9-9a37-4182-b5a6-d24a52fbe8de	basic-flow	t	t
a7e9b7ad-aa09-4ff0-b50f-b410abb6c7cf	Direct Grant - Conditional OTP	Flow to determine if the OTP is required for the authentication	e18440d9-9a37-4182-b5a6-d24a52fbe8de	basic-flow	f	t
7aa76e0a-f608-4abc-b44b-faa8377353eb	registration	registration flow	e18440d9-9a37-4182-b5a6-d24a52fbe8de	basic-flow	t	t
96ce17f4-eef7-443b-a9be-b82289e5c1b5	registration form	registration form	e18440d9-9a37-4182-b5a6-d24a52fbe8de	form-flow	f	t
ed82d486-fb35-4568-b46c-411bb9337d09	reset credentials	Reset credentials for a user if they forgot their password or something	e18440d9-9a37-4182-b5a6-d24a52fbe8de	basic-flow	t	t
c770c022-9d5d-44c8-849f-83ecef994648	Reset - Conditional OTP	Flow to determine if the OTP should be reset or not. Set to REQUIRED to force.	e18440d9-9a37-4182-b5a6-d24a52fbe8de	basic-flow	f	t
f214df70-bf55-4add-aaf7-646b9939aec9	clients	Base authentication for clients	e18440d9-9a37-4182-b5a6-d24a52fbe8de	client-flow	t	t
3e317944-5bf7-430c-957f-28a0362acd58	first broker login	Actions taken after first broker login with identity provider account, which is not yet linked to any Keycloak account	e18440d9-9a37-4182-b5a6-d24a52fbe8de	basic-flow	t	t
803bc540-f5cb-45f2-a934-8536c5f5efc7	User creation or linking	Flow for the existing/non-existing user alternatives	e18440d9-9a37-4182-b5a6-d24a52fbe8de	basic-flow	f	t
ffe5aabe-321f-4a0a-a04a-1e834c69c0b8	Handle Existing Account	Handle what to do if there is existing account with same email/username like authenticated identity provider	e18440d9-9a37-4182-b5a6-d24a52fbe8de	basic-flow	f	t
41e6fc20-1a9a-4368-973e-c1cc4c0c8285	Account verification options	Method with which to verity the existing account	e18440d9-9a37-4182-b5a6-d24a52fbe8de	basic-flow	f	t
90d8f974-d73e-49c4-b838-183751740c23	Verify Existing Account by Re-authentication	Reauthentication of existing account	e18440d9-9a37-4182-b5a6-d24a52fbe8de	basic-flow	f	t
9dd28cb0-0b9c-4623-995c-f7a4537c1886	First broker login - Conditional OTP	Flow to determine if the OTP is required for the authentication	e18440d9-9a37-4182-b5a6-d24a52fbe8de	basic-flow	f	t
1b5bdfe6-9a14-48ba-8fa8-641c5ac8f1e7	saml ecp	SAML ECP Profile Authentication Flow	e18440d9-9a37-4182-b5a6-d24a52fbe8de	basic-flow	t	t
7328656d-c1de-4ff8-99df-7d73be1aa463	docker auth	Used by Docker clients to authenticate against the IDP	e18440d9-9a37-4182-b5a6-d24a52fbe8de	basic-flow	t	t
d28e53b3-5ce0-4353-b4ca-9a8320b90da6	browser	browser based authentication	deffec2e-91ce-4521-869a-fabb8944dc44	basic-flow	t	t
d6b80bd0-5a29-4c4d-8ef0-3e002f94f781	forms	Username, password, otp and other auth forms.	deffec2e-91ce-4521-869a-fabb8944dc44	basic-flow	f	t
fbf2eec5-4515-4a6d-a339-b6c7c23bd8c4	Browser - Conditional OTP	Flow to determine if the OTP is required for the authentication	deffec2e-91ce-4521-869a-fabb8944dc44	basic-flow	f	t
47fcc61e-1b30-455c-90e7-eba2c612f5ee	direct grant	OpenID Connect Resource Owner Grant	deffec2e-91ce-4521-869a-fabb8944dc44	basic-flow	t	t
a8327282-45be-4a0a-88e7-44839081a3e2	Direct Grant - Conditional OTP	Flow to determine if the OTP is required for the authentication	deffec2e-91ce-4521-869a-fabb8944dc44	basic-flow	f	t
9efa3170-4d5c-492b-b7ba-3a123290610d	registration	registration flow	deffec2e-91ce-4521-869a-fabb8944dc44	basic-flow	t	t
d8f33a15-cb7c-4d16-9f1d-8c03f22384f5	registration form	registration form	deffec2e-91ce-4521-869a-fabb8944dc44	form-flow	f	t
2d446316-15bc-49b4-a455-848a3b44992a	reset credentials	Reset credentials for a user if they forgot their password or something	deffec2e-91ce-4521-869a-fabb8944dc44	basic-flow	t	t
35948e13-4d51-4bb8-bfa3-7e722feb42c6	Reset - Conditional OTP	Flow to determine if the OTP should be reset or not. Set to REQUIRED to force.	deffec2e-91ce-4521-869a-fabb8944dc44	basic-flow	f	t
42db0288-44d9-40bb-a5a6-c0ea17737485	clients	Base authentication for clients	deffec2e-91ce-4521-869a-fabb8944dc44	client-flow	t	t
0107862d-c2dc-49eb-8862-4a5623f35df3	first broker login	Actions taken after first broker login with identity provider account, which is not yet linked to any Keycloak account	deffec2e-91ce-4521-869a-fabb8944dc44	basic-flow	t	t
ebe24b27-b7dc-4aee-8a9f-a1e4da496073	User creation or linking	Flow for the existing/non-existing user alternatives	deffec2e-91ce-4521-869a-fabb8944dc44	basic-flow	f	t
18799472-2402-4333-9d5e-a39a228e4a3d	Handle Existing Account	Handle what to do if there is existing account with same email/username like authenticated identity provider	deffec2e-91ce-4521-869a-fabb8944dc44	basic-flow	f	t
ff2a6679-2f16-4064-96d5-d05823ee1be5	Account verification options	Method with which to verity the existing account	deffec2e-91ce-4521-869a-fabb8944dc44	basic-flow	f	t
a22c1440-1bb2-4cc6-8ce0-271ae82d6ed7	Verify Existing Account by Re-authentication	Reauthentication of existing account	deffec2e-91ce-4521-869a-fabb8944dc44	basic-flow	f	t
cedab2ae-3c36-4cfb-80d0-da3577b72670	First broker login - Conditional OTP	Flow to determine if the OTP is required for the authentication	deffec2e-91ce-4521-869a-fabb8944dc44	basic-flow	f	t
abee82ab-591b-417a-baec-e77c7e6ce1cf	saml ecp	SAML ECP Profile Authentication Flow	deffec2e-91ce-4521-869a-fabb8944dc44	basic-flow	t	t
424f9338-b1eb-4618-9c38-c717a832c535	docker auth	Used by Docker clients to authenticate against the IDP	deffec2e-91ce-4521-869a-fabb8944dc44	basic-flow	t	t
\.


--
-- Data for Name: authenticator_config; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.authenticator_config (id, alias, realm_id) FROM stdin;
07fecfb8-2cc2-4ed2-88c4-da4523d00b6a	review profile config	e18440d9-9a37-4182-b5a6-d24a52fbe8de
d7996f80-c0a7-4a3e-a055-1b8a6e253d3b	create unique user config	e18440d9-9a37-4182-b5a6-d24a52fbe8de
1c9c4b23-0dab-4e82-877d-e2384ce95ba9	review profile config	deffec2e-91ce-4521-869a-fabb8944dc44
94e40bac-e148-4260-8360-0cc50952bb83	create unique user config	deffec2e-91ce-4521-869a-fabb8944dc44
\.


--
-- Data for Name: authenticator_config_entry; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.authenticator_config_entry (authenticator_id, value, name) FROM stdin;
07fecfb8-2cc2-4ed2-88c4-da4523d00b6a	missing	update.profile.on.first.login
d7996f80-c0a7-4a3e-a055-1b8a6e253d3b	false	require.password.update.after.registration
1c9c4b23-0dab-4e82-877d-e2384ce95ba9	missing	update.profile.on.first.login
94e40bac-e148-4260-8360-0cc50952bb83	false	require.password.update.after.registration
\.


--
-- Data for Name: broker_link; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.broker_link (identity_provider, storage_provider_id, realm_id, broker_user_id, broker_username, token, user_id) FROM stdin;
\.


--
-- Data for Name: client; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client (id, enabled, full_scope_allowed, client_id, not_before, public_client, secret, base_url, bearer_only, management_url, surrogate_auth_required, realm_id, protocol, node_rereg_timeout, frontchannel_logout, consent_required, name, service_accounts_enabled, client_authenticator_type, root_url, description, registration_token, standard_flow_enabled, implicit_flow_enabled, direct_access_grants_enabled, always_display_in_console) FROM stdin;
9b952648-c8ca-47c1-bd66-8101ca3cf78a	t	f	master-realm	0	f	\N	\N	t	\N	f	e18440d9-9a37-4182-b5a6-d24a52fbe8de	\N	0	f	f	master Realm	f	client-secret	\N	\N	\N	t	f	f	f
4cbb8291-d081-41ed-9cf2-cf6039ecdda1	t	f	account	0	t	\N	/realms/master/account/	f	\N	f	e18440d9-9a37-4182-b5a6-d24a52fbe8de	openid-connect	0	f	f	${client_account}	f	client-secret	${authBaseUrl}	\N	\N	t	f	f	f
34f1651f-bcea-4cba-bb21-25ed92ce4940	t	f	account-console	0	t	\N	/realms/master/account/	f	\N	f	e18440d9-9a37-4182-b5a6-d24a52fbe8de	openid-connect	0	f	f	${client_account-console}	f	client-secret	${authBaseUrl}	\N	\N	t	f	f	f
95b70658-1788-4b4a-8415-07f5ba81d747	t	f	broker	0	f	\N	\N	t	\N	f	e18440d9-9a37-4182-b5a6-d24a52fbe8de	openid-connect	0	f	f	${client_broker}	f	client-secret	\N	\N	\N	t	f	f	f
a36d7658-791f-4656-ae44-f61719937235	t	f	security-admin-console	0	t	\N	/admin/master/console/	f	\N	f	e18440d9-9a37-4182-b5a6-d24a52fbe8de	openid-connect	0	f	f	${client_security-admin-console}	f	client-secret	${authAdminUrl}	\N	\N	t	f	f	f
f272aa50-2bfc-450d-b55e-9d3bb6a21a72	t	f	admin-cli	0	t	\N	\N	f	\N	f	e18440d9-9a37-4182-b5a6-d24a52fbe8de	openid-connect	0	f	f	${client_admin-cli}	f	client-secret	\N	\N	\N	f	f	t	f
cbfd8c2d-001c-47d5-b7fa-c06d60c9348a	t	f	default-realm	0	f	\N	\N	t	\N	f	e18440d9-9a37-4182-b5a6-d24a52fbe8de	\N	0	f	f	default Realm	f	client-secret	\N	\N	\N	t	f	f	f
61e0950a-44e4-45c6-a261-52e2af025aae	t	f	realm-management	0	f	\N	\N	t	\N	f	deffec2e-91ce-4521-869a-fabb8944dc44	openid-connect	0	f	f	${client_realm-management}	f	client-secret	\N	\N	\N	t	f	f	f
54a72e08-63fb-43e3-8687-158d85067249	t	f	account	0	t	\N	/realms/default/account/	f	\N	f	deffec2e-91ce-4521-869a-fabb8944dc44	openid-connect	0	f	f	${client_account}	f	client-secret	${authBaseUrl}	\N	\N	t	f	f	f
c2ddf74e-6ed3-4b56-8625-0c42a31dc8c2	t	f	account-console	0	t	\N	/realms/default/account/	f	\N	f	deffec2e-91ce-4521-869a-fabb8944dc44	openid-connect	0	f	f	${client_account-console}	f	client-secret	${authBaseUrl}	\N	\N	t	f	f	f
f1a552dd-e198-4258-9bc5-21fe86b57963	t	f	broker	0	f	\N	\N	t	\N	f	deffec2e-91ce-4521-869a-fabb8944dc44	openid-connect	0	f	f	${client_broker}	f	client-secret	\N	\N	\N	t	f	f	f
c8dbae89-1dda-433d-9df7-c6d284177f13	t	f	security-admin-console	0	t	\N	/admin/default/console/	f	\N	f	deffec2e-91ce-4521-869a-fabb8944dc44	openid-connect	0	f	f	${client_security-admin-console}	f	client-secret	${authAdminUrl}	\N	\N	t	f	f	f
539cd5d5-da80-4c24-90c9-8376dca2d6b1	t	f	admin-cli	0	t	\N	\N	f	\N	f	deffec2e-91ce-4521-869a-fabb8944dc44	openid-connect	0	f	f	${client_admin-cli}	f	client-secret	\N	\N	\N	f	f	t	f
\.


--
-- Data for Name: client_attributes; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_attributes (client_id, name, value) FROM stdin;
4cbb8291-d081-41ed-9cf2-cf6039ecdda1	post.logout.redirect.uris	+
34f1651f-bcea-4cba-bb21-25ed92ce4940	post.logout.redirect.uris	+
34f1651f-bcea-4cba-bb21-25ed92ce4940	pkce.code.challenge.method	S256
a36d7658-791f-4656-ae44-f61719937235	post.logout.redirect.uris	+
a36d7658-791f-4656-ae44-f61719937235	pkce.code.challenge.method	S256
54a72e08-63fb-43e3-8687-158d85067249	post.logout.redirect.uris	+
c2ddf74e-6ed3-4b56-8625-0c42a31dc8c2	post.logout.redirect.uris	+
c2ddf74e-6ed3-4b56-8625-0c42a31dc8c2	pkce.code.challenge.method	S256
c8dbae89-1dda-433d-9df7-c6d284177f13	post.logout.redirect.uris	+
c8dbae89-1dda-433d-9df7-c6d284177f13	pkce.code.challenge.method	S256
\.


--
-- Data for Name: client_auth_flow_bindings; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_auth_flow_bindings (client_id, flow_id, binding_name) FROM stdin;
\.


--
-- Data for Name: client_initial_access; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_initial_access (id, realm_id, "timestamp", expiration, count, remaining_count) FROM stdin;
\.


--
-- Data for Name: client_node_registrations; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_node_registrations (client_id, value, name) FROM stdin;
\.


--
-- Data for Name: client_scope; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_scope (id, name, realm_id, description, protocol) FROM stdin;
d1bf1487-0883-46c2-b525-5fb6f8c09b2c	offline_access	e18440d9-9a37-4182-b5a6-d24a52fbe8de	OpenID Connect built-in scope: offline_access	openid-connect
71d44657-6446-4dc7-9a28-1dd930a8ed5a	role_list	e18440d9-9a37-4182-b5a6-d24a52fbe8de	SAML role list	saml
47a25d9c-5ded-44a3-8d25-60e9ca92325b	profile	e18440d9-9a37-4182-b5a6-d24a52fbe8de	OpenID Connect built-in scope: profile	openid-connect
9fdd8be0-7266-4fb4-828d-0a639292c403	email	e18440d9-9a37-4182-b5a6-d24a52fbe8de	OpenID Connect built-in scope: email	openid-connect
40db3c80-198c-444e-ad8f-c5ed9c07aff7	address	e18440d9-9a37-4182-b5a6-d24a52fbe8de	OpenID Connect built-in scope: address	openid-connect
0a916db0-add9-427f-a7be-79bb8be6fc87	phone	e18440d9-9a37-4182-b5a6-d24a52fbe8de	OpenID Connect built-in scope: phone	openid-connect
fd471174-9087-4bb0-af05-dda19608232e	roles	e18440d9-9a37-4182-b5a6-d24a52fbe8de	OpenID Connect scope for add user roles to the access token	openid-connect
56574f43-072f-41ef-af53-f6dc414644d0	web-origins	e18440d9-9a37-4182-b5a6-d24a52fbe8de	OpenID Connect scope for add allowed web origins to the access token	openid-connect
97bcf6ee-efc2-4db0-a062-ebbc00a84639	microprofile-jwt	e18440d9-9a37-4182-b5a6-d24a52fbe8de	Microprofile - JWT built-in scope	openid-connect
f0941ea3-b402-49de-a53d-a37ea153fbf0	acr	e18440d9-9a37-4182-b5a6-d24a52fbe8de	OpenID Connect scope for add acr (authentication context class reference) to the token	openid-connect
177a0779-60cf-4253-a402-17d6d6abf8b7	offline_access	deffec2e-91ce-4521-869a-fabb8944dc44	OpenID Connect built-in scope: offline_access	openid-connect
ff2083f6-54cc-48d7-96c1-79b8e86c54e7	role_list	deffec2e-91ce-4521-869a-fabb8944dc44	SAML role list	saml
856e1f9c-046c-4f82-936a-514aa9c205c6	profile	deffec2e-91ce-4521-869a-fabb8944dc44	OpenID Connect built-in scope: profile	openid-connect
6965b2ef-3ddb-45d1-99bd-470fc201bde6	email	deffec2e-91ce-4521-869a-fabb8944dc44	OpenID Connect built-in scope: email	openid-connect
7707dede-2ef2-4421-896f-920b23f757c7	address	deffec2e-91ce-4521-869a-fabb8944dc44	OpenID Connect built-in scope: address	openid-connect
a3526425-639e-4eb0-aa30-46439410db15	phone	deffec2e-91ce-4521-869a-fabb8944dc44	OpenID Connect built-in scope: phone	openid-connect
5de90e63-fe15-47d3-b122-812c6cea10d5	roles	deffec2e-91ce-4521-869a-fabb8944dc44	OpenID Connect scope for add user roles to the access token	openid-connect
f3468c92-6959-46bc-870b-be2a3bc0c1f7	web-origins	deffec2e-91ce-4521-869a-fabb8944dc44	OpenID Connect scope for add allowed web origins to the access token	openid-connect
77dc30a2-9f75-4e68-8d68-5e492d60c2f5	microprofile-jwt	deffec2e-91ce-4521-869a-fabb8944dc44	Microprofile - JWT built-in scope	openid-connect
b5745f6e-73d5-413f-88b1-cede3858e9cd	acr	deffec2e-91ce-4521-869a-fabb8944dc44	OpenID Connect scope for add acr (authentication context class reference) to the token	openid-connect
\.


--
-- Data for Name: client_scope_attributes; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_scope_attributes (scope_id, value, name) FROM stdin;
d1bf1487-0883-46c2-b525-5fb6f8c09b2c	true	display.on.consent.screen
d1bf1487-0883-46c2-b525-5fb6f8c09b2c	${offlineAccessScopeConsentText}	consent.screen.text
71d44657-6446-4dc7-9a28-1dd930a8ed5a	true	display.on.consent.screen
71d44657-6446-4dc7-9a28-1dd930a8ed5a	${samlRoleListScopeConsentText}	consent.screen.text
47a25d9c-5ded-44a3-8d25-60e9ca92325b	true	display.on.consent.screen
47a25d9c-5ded-44a3-8d25-60e9ca92325b	${profileScopeConsentText}	consent.screen.text
47a25d9c-5ded-44a3-8d25-60e9ca92325b	true	include.in.token.scope
9fdd8be0-7266-4fb4-828d-0a639292c403	true	display.on.consent.screen
9fdd8be0-7266-4fb4-828d-0a639292c403	${emailScopeConsentText}	consent.screen.text
9fdd8be0-7266-4fb4-828d-0a639292c403	true	include.in.token.scope
40db3c80-198c-444e-ad8f-c5ed9c07aff7	true	display.on.consent.screen
40db3c80-198c-444e-ad8f-c5ed9c07aff7	${addressScopeConsentText}	consent.screen.text
40db3c80-198c-444e-ad8f-c5ed9c07aff7	true	include.in.token.scope
0a916db0-add9-427f-a7be-79bb8be6fc87	true	display.on.consent.screen
0a916db0-add9-427f-a7be-79bb8be6fc87	${phoneScopeConsentText}	consent.screen.text
0a916db0-add9-427f-a7be-79bb8be6fc87	true	include.in.token.scope
fd471174-9087-4bb0-af05-dda19608232e	true	display.on.consent.screen
fd471174-9087-4bb0-af05-dda19608232e	${rolesScopeConsentText}	consent.screen.text
fd471174-9087-4bb0-af05-dda19608232e	false	include.in.token.scope
56574f43-072f-41ef-af53-f6dc414644d0	false	display.on.consent.screen
56574f43-072f-41ef-af53-f6dc414644d0		consent.screen.text
56574f43-072f-41ef-af53-f6dc414644d0	false	include.in.token.scope
97bcf6ee-efc2-4db0-a062-ebbc00a84639	false	display.on.consent.screen
97bcf6ee-efc2-4db0-a062-ebbc00a84639	true	include.in.token.scope
f0941ea3-b402-49de-a53d-a37ea153fbf0	false	display.on.consent.screen
f0941ea3-b402-49de-a53d-a37ea153fbf0	false	include.in.token.scope
177a0779-60cf-4253-a402-17d6d6abf8b7	true	display.on.consent.screen
177a0779-60cf-4253-a402-17d6d6abf8b7	${offlineAccessScopeConsentText}	consent.screen.text
ff2083f6-54cc-48d7-96c1-79b8e86c54e7	true	display.on.consent.screen
ff2083f6-54cc-48d7-96c1-79b8e86c54e7	${samlRoleListScopeConsentText}	consent.screen.text
856e1f9c-046c-4f82-936a-514aa9c205c6	true	display.on.consent.screen
856e1f9c-046c-4f82-936a-514aa9c205c6	${profileScopeConsentText}	consent.screen.text
856e1f9c-046c-4f82-936a-514aa9c205c6	true	include.in.token.scope
6965b2ef-3ddb-45d1-99bd-470fc201bde6	true	display.on.consent.screen
6965b2ef-3ddb-45d1-99bd-470fc201bde6	${emailScopeConsentText}	consent.screen.text
6965b2ef-3ddb-45d1-99bd-470fc201bde6	true	include.in.token.scope
7707dede-2ef2-4421-896f-920b23f757c7	true	display.on.consent.screen
7707dede-2ef2-4421-896f-920b23f757c7	${addressScopeConsentText}	consent.screen.text
7707dede-2ef2-4421-896f-920b23f757c7	true	include.in.token.scope
a3526425-639e-4eb0-aa30-46439410db15	true	display.on.consent.screen
a3526425-639e-4eb0-aa30-46439410db15	${phoneScopeConsentText}	consent.screen.text
a3526425-639e-4eb0-aa30-46439410db15	true	include.in.token.scope
5de90e63-fe15-47d3-b122-812c6cea10d5	true	display.on.consent.screen
5de90e63-fe15-47d3-b122-812c6cea10d5	${rolesScopeConsentText}	consent.screen.text
5de90e63-fe15-47d3-b122-812c6cea10d5	false	include.in.token.scope
f3468c92-6959-46bc-870b-be2a3bc0c1f7	false	display.on.consent.screen
f3468c92-6959-46bc-870b-be2a3bc0c1f7		consent.screen.text
f3468c92-6959-46bc-870b-be2a3bc0c1f7	false	include.in.token.scope
77dc30a2-9f75-4e68-8d68-5e492d60c2f5	false	display.on.consent.screen
77dc30a2-9f75-4e68-8d68-5e492d60c2f5	true	include.in.token.scope
b5745f6e-73d5-413f-88b1-cede3858e9cd	false	display.on.consent.screen
b5745f6e-73d5-413f-88b1-cede3858e9cd	false	include.in.token.scope
\.


--
-- Data for Name: client_scope_client; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_scope_client (client_id, scope_id, default_scope) FROM stdin;
4cbb8291-d081-41ed-9cf2-cf6039ecdda1	fd471174-9087-4bb0-af05-dda19608232e	t
4cbb8291-d081-41ed-9cf2-cf6039ecdda1	9fdd8be0-7266-4fb4-828d-0a639292c403	t
4cbb8291-d081-41ed-9cf2-cf6039ecdda1	56574f43-072f-41ef-af53-f6dc414644d0	t
4cbb8291-d081-41ed-9cf2-cf6039ecdda1	f0941ea3-b402-49de-a53d-a37ea153fbf0	t
4cbb8291-d081-41ed-9cf2-cf6039ecdda1	47a25d9c-5ded-44a3-8d25-60e9ca92325b	t
4cbb8291-d081-41ed-9cf2-cf6039ecdda1	40db3c80-198c-444e-ad8f-c5ed9c07aff7	f
4cbb8291-d081-41ed-9cf2-cf6039ecdda1	d1bf1487-0883-46c2-b525-5fb6f8c09b2c	f
4cbb8291-d081-41ed-9cf2-cf6039ecdda1	0a916db0-add9-427f-a7be-79bb8be6fc87	f
4cbb8291-d081-41ed-9cf2-cf6039ecdda1	97bcf6ee-efc2-4db0-a062-ebbc00a84639	f
34f1651f-bcea-4cba-bb21-25ed92ce4940	fd471174-9087-4bb0-af05-dda19608232e	t
34f1651f-bcea-4cba-bb21-25ed92ce4940	9fdd8be0-7266-4fb4-828d-0a639292c403	t
34f1651f-bcea-4cba-bb21-25ed92ce4940	56574f43-072f-41ef-af53-f6dc414644d0	t
34f1651f-bcea-4cba-bb21-25ed92ce4940	f0941ea3-b402-49de-a53d-a37ea153fbf0	t
34f1651f-bcea-4cba-bb21-25ed92ce4940	47a25d9c-5ded-44a3-8d25-60e9ca92325b	t
34f1651f-bcea-4cba-bb21-25ed92ce4940	40db3c80-198c-444e-ad8f-c5ed9c07aff7	f
34f1651f-bcea-4cba-bb21-25ed92ce4940	d1bf1487-0883-46c2-b525-5fb6f8c09b2c	f
34f1651f-bcea-4cba-bb21-25ed92ce4940	0a916db0-add9-427f-a7be-79bb8be6fc87	f
34f1651f-bcea-4cba-bb21-25ed92ce4940	97bcf6ee-efc2-4db0-a062-ebbc00a84639	f
f272aa50-2bfc-450d-b55e-9d3bb6a21a72	fd471174-9087-4bb0-af05-dda19608232e	t
f272aa50-2bfc-450d-b55e-9d3bb6a21a72	9fdd8be0-7266-4fb4-828d-0a639292c403	t
f272aa50-2bfc-450d-b55e-9d3bb6a21a72	56574f43-072f-41ef-af53-f6dc414644d0	t
f272aa50-2bfc-450d-b55e-9d3bb6a21a72	f0941ea3-b402-49de-a53d-a37ea153fbf0	t
f272aa50-2bfc-450d-b55e-9d3bb6a21a72	47a25d9c-5ded-44a3-8d25-60e9ca92325b	t
f272aa50-2bfc-450d-b55e-9d3bb6a21a72	40db3c80-198c-444e-ad8f-c5ed9c07aff7	f
f272aa50-2bfc-450d-b55e-9d3bb6a21a72	d1bf1487-0883-46c2-b525-5fb6f8c09b2c	f
f272aa50-2bfc-450d-b55e-9d3bb6a21a72	0a916db0-add9-427f-a7be-79bb8be6fc87	f
f272aa50-2bfc-450d-b55e-9d3bb6a21a72	97bcf6ee-efc2-4db0-a062-ebbc00a84639	f
95b70658-1788-4b4a-8415-07f5ba81d747	fd471174-9087-4bb0-af05-dda19608232e	t
95b70658-1788-4b4a-8415-07f5ba81d747	9fdd8be0-7266-4fb4-828d-0a639292c403	t
95b70658-1788-4b4a-8415-07f5ba81d747	56574f43-072f-41ef-af53-f6dc414644d0	t
95b70658-1788-4b4a-8415-07f5ba81d747	f0941ea3-b402-49de-a53d-a37ea153fbf0	t
95b70658-1788-4b4a-8415-07f5ba81d747	47a25d9c-5ded-44a3-8d25-60e9ca92325b	t
95b70658-1788-4b4a-8415-07f5ba81d747	40db3c80-198c-444e-ad8f-c5ed9c07aff7	f
95b70658-1788-4b4a-8415-07f5ba81d747	d1bf1487-0883-46c2-b525-5fb6f8c09b2c	f
95b70658-1788-4b4a-8415-07f5ba81d747	0a916db0-add9-427f-a7be-79bb8be6fc87	f
95b70658-1788-4b4a-8415-07f5ba81d747	97bcf6ee-efc2-4db0-a062-ebbc00a84639	f
9b952648-c8ca-47c1-bd66-8101ca3cf78a	fd471174-9087-4bb0-af05-dda19608232e	t
9b952648-c8ca-47c1-bd66-8101ca3cf78a	9fdd8be0-7266-4fb4-828d-0a639292c403	t
9b952648-c8ca-47c1-bd66-8101ca3cf78a	56574f43-072f-41ef-af53-f6dc414644d0	t
9b952648-c8ca-47c1-bd66-8101ca3cf78a	f0941ea3-b402-49de-a53d-a37ea153fbf0	t
9b952648-c8ca-47c1-bd66-8101ca3cf78a	47a25d9c-5ded-44a3-8d25-60e9ca92325b	t
9b952648-c8ca-47c1-bd66-8101ca3cf78a	40db3c80-198c-444e-ad8f-c5ed9c07aff7	f
9b952648-c8ca-47c1-bd66-8101ca3cf78a	d1bf1487-0883-46c2-b525-5fb6f8c09b2c	f
9b952648-c8ca-47c1-bd66-8101ca3cf78a	0a916db0-add9-427f-a7be-79bb8be6fc87	f
9b952648-c8ca-47c1-bd66-8101ca3cf78a	97bcf6ee-efc2-4db0-a062-ebbc00a84639	f
a36d7658-791f-4656-ae44-f61719937235	fd471174-9087-4bb0-af05-dda19608232e	t
a36d7658-791f-4656-ae44-f61719937235	9fdd8be0-7266-4fb4-828d-0a639292c403	t
a36d7658-791f-4656-ae44-f61719937235	56574f43-072f-41ef-af53-f6dc414644d0	t
a36d7658-791f-4656-ae44-f61719937235	f0941ea3-b402-49de-a53d-a37ea153fbf0	t
a36d7658-791f-4656-ae44-f61719937235	47a25d9c-5ded-44a3-8d25-60e9ca92325b	t
a36d7658-791f-4656-ae44-f61719937235	40db3c80-198c-444e-ad8f-c5ed9c07aff7	f
a36d7658-791f-4656-ae44-f61719937235	d1bf1487-0883-46c2-b525-5fb6f8c09b2c	f
a36d7658-791f-4656-ae44-f61719937235	0a916db0-add9-427f-a7be-79bb8be6fc87	f
a36d7658-791f-4656-ae44-f61719937235	97bcf6ee-efc2-4db0-a062-ebbc00a84639	f
54a72e08-63fb-43e3-8687-158d85067249	6965b2ef-3ddb-45d1-99bd-470fc201bde6	t
54a72e08-63fb-43e3-8687-158d85067249	5de90e63-fe15-47d3-b122-812c6cea10d5	t
54a72e08-63fb-43e3-8687-158d85067249	856e1f9c-046c-4f82-936a-514aa9c205c6	t
54a72e08-63fb-43e3-8687-158d85067249	f3468c92-6959-46bc-870b-be2a3bc0c1f7	t
54a72e08-63fb-43e3-8687-158d85067249	b5745f6e-73d5-413f-88b1-cede3858e9cd	t
54a72e08-63fb-43e3-8687-158d85067249	77dc30a2-9f75-4e68-8d68-5e492d60c2f5	f
54a72e08-63fb-43e3-8687-158d85067249	177a0779-60cf-4253-a402-17d6d6abf8b7	f
54a72e08-63fb-43e3-8687-158d85067249	7707dede-2ef2-4421-896f-920b23f757c7	f
54a72e08-63fb-43e3-8687-158d85067249	a3526425-639e-4eb0-aa30-46439410db15	f
c2ddf74e-6ed3-4b56-8625-0c42a31dc8c2	6965b2ef-3ddb-45d1-99bd-470fc201bde6	t
c2ddf74e-6ed3-4b56-8625-0c42a31dc8c2	5de90e63-fe15-47d3-b122-812c6cea10d5	t
c2ddf74e-6ed3-4b56-8625-0c42a31dc8c2	856e1f9c-046c-4f82-936a-514aa9c205c6	t
c2ddf74e-6ed3-4b56-8625-0c42a31dc8c2	f3468c92-6959-46bc-870b-be2a3bc0c1f7	t
c2ddf74e-6ed3-4b56-8625-0c42a31dc8c2	b5745f6e-73d5-413f-88b1-cede3858e9cd	t
c2ddf74e-6ed3-4b56-8625-0c42a31dc8c2	77dc30a2-9f75-4e68-8d68-5e492d60c2f5	f
c2ddf74e-6ed3-4b56-8625-0c42a31dc8c2	177a0779-60cf-4253-a402-17d6d6abf8b7	f
c2ddf74e-6ed3-4b56-8625-0c42a31dc8c2	7707dede-2ef2-4421-896f-920b23f757c7	f
c2ddf74e-6ed3-4b56-8625-0c42a31dc8c2	a3526425-639e-4eb0-aa30-46439410db15	f
539cd5d5-da80-4c24-90c9-8376dca2d6b1	6965b2ef-3ddb-45d1-99bd-470fc201bde6	t
539cd5d5-da80-4c24-90c9-8376dca2d6b1	5de90e63-fe15-47d3-b122-812c6cea10d5	t
539cd5d5-da80-4c24-90c9-8376dca2d6b1	856e1f9c-046c-4f82-936a-514aa9c205c6	t
539cd5d5-da80-4c24-90c9-8376dca2d6b1	f3468c92-6959-46bc-870b-be2a3bc0c1f7	t
539cd5d5-da80-4c24-90c9-8376dca2d6b1	b5745f6e-73d5-413f-88b1-cede3858e9cd	t
539cd5d5-da80-4c24-90c9-8376dca2d6b1	77dc30a2-9f75-4e68-8d68-5e492d60c2f5	f
539cd5d5-da80-4c24-90c9-8376dca2d6b1	177a0779-60cf-4253-a402-17d6d6abf8b7	f
539cd5d5-da80-4c24-90c9-8376dca2d6b1	7707dede-2ef2-4421-896f-920b23f757c7	f
539cd5d5-da80-4c24-90c9-8376dca2d6b1	a3526425-639e-4eb0-aa30-46439410db15	f
f1a552dd-e198-4258-9bc5-21fe86b57963	6965b2ef-3ddb-45d1-99bd-470fc201bde6	t
f1a552dd-e198-4258-9bc5-21fe86b57963	5de90e63-fe15-47d3-b122-812c6cea10d5	t
f1a552dd-e198-4258-9bc5-21fe86b57963	856e1f9c-046c-4f82-936a-514aa9c205c6	t
f1a552dd-e198-4258-9bc5-21fe86b57963	f3468c92-6959-46bc-870b-be2a3bc0c1f7	t
f1a552dd-e198-4258-9bc5-21fe86b57963	b5745f6e-73d5-413f-88b1-cede3858e9cd	t
f1a552dd-e198-4258-9bc5-21fe86b57963	77dc30a2-9f75-4e68-8d68-5e492d60c2f5	f
f1a552dd-e198-4258-9bc5-21fe86b57963	177a0779-60cf-4253-a402-17d6d6abf8b7	f
f1a552dd-e198-4258-9bc5-21fe86b57963	7707dede-2ef2-4421-896f-920b23f757c7	f
f1a552dd-e198-4258-9bc5-21fe86b57963	a3526425-639e-4eb0-aa30-46439410db15	f
61e0950a-44e4-45c6-a261-52e2af025aae	6965b2ef-3ddb-45d1-99bd-470fc201bde6	t
61e0950a-44e4-45c6-a261-52e2af025aae	5de90e63-fe15-47d3-b122-812c6cea10d5	t
61e0950a-44e4-45c6-a261-52e2af025aae	856e1f9c-046c-4f82-936a-514aa9c205c6	t
61e0950a-44e4-45c6-a261-52e2af025aae	f3468c92-6959-46bc-870b-be2a3bc0c1f7	t
61e0950a-44e4-45c6-a261-52e2af025aae	b5745f6e-73d5-413f-88b1-cede3858e9cd	t
61e0950a-44e4-45c6-a261-52e2af025aae	77dc30a2-9f75-4e68-8d68-5e492d60c2f5	f
61e0950a-44e4-45c6-a261-52e2af025aae	177a0779-60cf-4253-a402-17d6d6abf8b7	f
61e0950a-44e4-45c6-a261-52e2af025aae	7707dede-2ef2-4421-896f-920b23f757c7	f
61e0950a-44e4-45c6-a261-52e2af025aae	a3526425-639e-4eb0-aa30-46439410db15	f
c8dbae89-1dda-433d-9df7-c6d284177f13	6965b2ef-3ddb-45d1-99bd-470fc201bde6	t
c8dbae89-1dda-433d-9df7-c6d284177f13	5de90e63-fe15-47d3-b122-812c6cea10d5	t
c8dbae89-1dda-433d-9df7-c6d284177f13	856e1f9c-046c-4f82-936a-514aa9c205c6	t
c8dbae89-1dda-433d-9df7-c6d284177f13	f3468c92-6959-46bc-870b-be2a3bc0c1f7	t
c8dbae89-1dda-433d-9df7-c6d284177f13	b5745f6e-73d5-413f-88b1-cede3858e9cd	t
c8dbae89-1dda-433d-9df7-c6d284177f13	77dc30a2-9f75-4e68-8d68-5e492d60c2f5	f
c8dbae89-1dda-433d-9df7-c6d284177f13	177a0779-60cf-4253-a402-17d6d6abf8b7	f
c8dbae89-1dda-433d-9df7-c6d284177f13	7707dede-2ef2-4421-896f-920b23f757c7	f
c8dbae89-1dda-433d-9df7-c6d284177f13	a3526425-639e-4eb0-aa30-46439410db15	f
\.


--
-- Data for Name: client_scope_role_mapping; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_scope_role_mapping (scope_id, role_id) FROM stdin;
d1bf1487-0883-46c2-b525-5fb6f8c09b2c	af78c9c5-4407-4758-b695-0c0ed9c48f7d
177a0779-60cf-4253-a402-17d6d6abf8b7	73634ccd-4f2d-4dad-8065-ac2ea50f8589
\.


--
-- Data for Name: client_session; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_session (id, client_id, redirect_uri, state, "timestamp", session_id, auth_method, realm_id, auth_user_id, current_action) FROM stdin;
\.


--
-- Data for Name: client_session_auth_status; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_session_auth_status (authenticator, status, client_session) FROM stdin;
\.


--
-- Data for Name: client_session_note; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_session_note (name, value, client_session) FROM stdin;
\.


--
-- Data for Name: client_session_prot_mapper; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_session_prot_mapper (protocol_mapper_id, client_session) FROM stdin;
\.


--
-- Data for Name: client_session_role; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_session_role (role_id, client_session) FROM stdin;
\.


--
-- Data for Name: client_user_session_note; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.client_user_session_note (name, value, client_session) FROM stdin;
\.


--
-- Data for Name: component; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.component (id, name, parent_id, provider_id, provider_type, realm_id, sub_type) FROM stdin;
596c0016-b823-4f2a-9a32-87507700d68c	Trusted Hosts	e18440d9-9a37-4182-b5a6-d24a52fbe8de	trusted-hosts	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	e18440d9-9a37-4182-b5a6-d24a52fbe8de	anonymous
ce34ad6e-6089-4efe-acdf-e19e9c02ed1b	Consent Required	e18440d9-9a37-4182-b5a6-d24a52fbe8de	consent-required	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	e18440d9-9a37-4182-b5a6-d24a52fbe8de	anonymous
996e51c0-78a9-45b9-a6b3-c9e2ccc32e25	Full Scope Disabled	e18440d9-9a37-4182-b5a6-d24a52fbe8de	scope	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	e18440d9-9a37-4182-b5a6-d24a52fbe8de	anonymous
7a560cb9-78c2-4c26-bca7-0f0561a67383	Max Clients Limit	e18440d9-9a37-4182-b5a6-d24a52fbe8de	max-clients	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	e18440d9-9a37-4182-b5a6-d24a52fbe8de	anonymous
452d6d8b-b7fb-48b6-91c0-c497b0b02682	Allowed Protocol Mapper Types	e18440d9-9a37-4182-b5a6-d24a52fbe8de	allowed-protocol-mappers	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	e18440d9-9a37-4182-b5a6-d24a52fbe8de	anonymous
e0e55188-7e6a-4389-9f1c-7003f1b57685	Allowed Client Scopes	e18440d9-9a37-4182-b5a6-d24a52fbe8de	allowed-client-templates	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	e18440d9-9a37-4182-b5a6-d24a52fbe8de	anonymous
6ac3f9a2-aaaa-4668-a529-8654ae7ffbe8	Allowed Protocol Mapper Types	e18440d9-9a37-4182-b5a6-d24a52fbe8de	allowed-protocol-mappers	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	e18440d9-9a37-4182-b5a6-d24a52fbe8de	authenticated
f9c2dcf8-ee1b-450a-a4ea-e13ddcbeb5f3	Allowed Client Scopes	e18440d9-9a37-4182-b5a6-d24a52fbe8de	allowed-client-templates	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	e18440d9-9a37-4182-b5a6-d24a52fbe8de	authenticated
c810fcf1-feaa-4c15-a570-e6462e8d189b	rsa-generated	e18440d9-9a37-4182-b5a6-d24a52fbe8de	rsa-generated	org.keycloak.keys.KeyProvider	e18440d9-9a37-4182-b5a6-d24a52fbe8de	\N
709ea7c4-6a20-4263-8430-172371234aec	rsa-enc-generated	e18440d9-9a37-4182-b5a6-d24a52fbe8de	rsa-enc-generated	org.keycloak.keys.KeyProvider	e18440d9-9a37-4182-b5a6-d24a52fbe8de	\N
7af9f04d-0c66-43d6-a6e8-c7abbc860b4e	hmac-generated	e18440d9-9a37-4182-b5a6-d24a52fbe8de	hmac-generated	org.keycloak.keys.KeyProvider	e18440d9-9a37-4182-b5a6-d24a52fbe8de	\N
0ab2a2d6-dba6-4499-a59b-249a7ce56898	aes-generated	e18440d9-9a37-4182-b5a6-d24a52fbe8de	aes-generated	org.keycloak.keys.KeyProvider	e18440d9-9a37-4182-b5a6-d24a52fbe8de	\N
2472db39-b5f8-4810-867c-a0cc8ba97c5c	rsa-generated	deffec2e-91ce-4521-869a-fabb8944dc44	rsa-generated	org.keycloak.keys.KeyProvider	deffec2e-91ce-4521-869a-fabb8944dc44	\N
65a61399-7af0-4637-8580-150123f32280	rsa-enc-generated	deffec2e-91ce-4521-869a-fabb8944dc44	rsa-enc-generated	org.keycloak.keys.KeyProvider	deffec2e-91ce-4521-869a-fabb8944dc44	\N
52fd4078-8915-4480-a440-fa1959b82769	hmac-generated	deffec2e-91ce-4521-869a-fabb8944dc44	hmac-generated	org.keycloak.keys.KeyProvider	deffec2e-91ce-4521-869a-fabb8944dc44	\N
6ec406a1-fe25-4a11-af2e-72d2097165bb	aes-generated	deffec2e-91ce-4521-869a-fabb8944dc44	aes-generated	org.keycloak.keys.KeyProvider	deffec2e-91ce-4521-869a-fabb8944dc44	\N
9302579f-bc4e-4de7-aed2-9610e988ba66	Trusted Hosts	deffec2e-91ce-4521-869a-fabb8944dc44	trusted-hosts	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	deffec2e-91ce-4521-869a-fabb8944dc44	anonymous
f2fb3d5e-66e0-454f-821e-68d8c614b48f	Consent Required	deffec2e-91ce-4521-869a-fabb8944dc44	consent-required	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	deffec2e-91ce-4521-869a-fabb8944dc44	anonymous
8edc42c5-ae11-469a-b773-3f7b0a958972	Full Scope Disabled	deffec2e-91ce-4521-869a-fabb8944dc44	scope	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	deffec2e-91ce-4521-869a-fabb8944dc44	anonymous
a485d8e3-58fb-4018-965b-c9647e81ff3f	Max Clients Limit	deffec2e-91ce-4521-869a-fabb8944dc44	max-clients	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	deffec2e-91ce-4521-869a-fabb8944dc44	anonymous
ee869fea-d50b-4e40-85b6-7123c55233d5	Allowed Protocol Mapper Types	deffec2e-91ce-4521-869a-fabb8944dc44	allowed-protocol-mappers	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	deffec2e-91ce-4521-869a-fabb8944dc44	anonymous
a663bc47-2c8f-4842-9b8e-e85745191717	Allowed Client Scopes	deffec2e-91ce-4521-869a-fabb8944dc44	allowed-client-templates	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	deffec2e-91ce-4521-869a-fabb8944dc44	anonymous
a00bdc65-8ff3-4eac-8184-86f20ecef5c2	Allowed Protocol Mapper Types	deffec2e-91ce-4521-869a-fabb8944dc44	allowed-protocol-mappers	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	deffec2e-91ce-4521-869a-fabb8944dc44	authenticated
143e8425-b049-4ec6-a403-5948a241f37e	Allowed Client Scopes	deffec2e-91ce-4521-869a-fabb8944dc44	allowed-client-templates	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	deffec2e-91ce-4521-869a-fabb8944dc44	authenticated
421f624a-f8fa-4a9e-9853-98d471e7f1da	ldap	deffec2e-91ce-4521-869a-fabb8944dc44	ldap	org.keycloak.storage.UserStorageProvider	deffec2e-91ce-4521-869a-fabb8944dc44	\N
b7990307-dc71-4acc-ab95-67748511bbdf	username	421f624a-f8fa-4a9e-9853-98d471e7f1da	user-attribute-ldap-mapper	org.keycloak.storage.ldap.mappers.LDAPStorageMapper	deffec2e-91ce-4521-869a-fabb8944dc44	\N
cd7ca05d-2356-45a8-8c30-3e8e7e7776ef	full name	421f624a-f8fa-4a9e-9853-98d471e7f1da	full-name-ldap-mapper	org.keycloak.storage.ldap.mappers.LDAPStorageMapper	deffec2e-91ce-4521-869a-fabb8944dc44	\N
5698c210-d29e-422b-8307-bff9da47e991	last name	421f624a-f8fa-4a9e-9853-98d471e7f1da	user-attribute-ldap-mapper	org.keycloak.storage.ldap.mappers.LDAPStorageMapper	deffec2e-91ce-4521-869a-fabb8944dc44	\N
8fb21468-bb0f-49a2-9b0a-358ba4deae7f	email	421f624a-f8fa-4a9e-9853-98d471e7f1da	user-attribute-ldap-mapper	org.keycloak.storage.ldap.mappers.LDAPStorageMapper	deffec2e-91ce-4521-869a-fabb8944dc44	\N
c94dc336-2a53-481e-ade7-462a1d3ff67e	creation date	421f624a-f8fa-4a9e-9853-98d471e7f1da	user-attribute-ldap-mapper	org.keycloak.storage.ldap.mappers.LDAPStorageMapper	deffec2e-91ce-4521-869a-fabb8944dc44	\N
4f886323-92d5-4b1f-898e-8fccd15a1cc4	modify date	421f624a-f8fa-4a9e-9853-98d471e7f1da	user-attribute-ldap-mapper	org.keycloak.storage.ldap.mappers.LDAPStorageMapper	deffec2e-91ce-4521-869a-fabb8944dc44	\N
94f40fd5-a633-4f04-8968-b6d27e7c3061	group	421f624a-f8fa-4a9e-9853-98d471e7f1da	group-ldap-mapper	org.keycloak.storage.ldap.mappers.LDAPStorageMapper	deffec2e-91ce-4521-869a-fabb8944dc44	\N
\.


--
-- Data for Name: component_config; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.component_config (id, component_id, name, value) FROM stdin;
2e015a5e-bb12-414e-a15e-9ac8ff81da01	7a560cb9-78c2-4c26-bca7-0f0561a67383	max-clients	200
c28802cc-3363-4144-812a-8230c7c7dad1	452d6d8b-b7fb-48b6-91c0-c497b0b02682	allowed-protocol-mapper-types	oidc-full-name-mapper
3faf75b1-81c9-4744-9365-c2e088b5ffd4	452d6d8b-b7fb-48b6-91c0-c497b0b02682	allowed-protocol-mapper-types	saml-user-attribute-mapper
5c77fac6-6959-4484-9f51-119970986253	452d6d8b-b7fb-48b6-91c0-c497b0b02682	allowed-protocol-mapper-types	oidc-usermodel-attribute-mapper
f3689e8e-308f-4070-9d26-159739f9b0fe	452d6d8b-b7fb-48b6-91c0-c497b0b02682	allowed-protocol-mapper-types	saml-user-property-mapper
2a86b649-8c5c-4a98-aebe-b26472559b81	452d6d8b-b7fb-48b6-91c0-c497b0b02682	allowed-protocol-mapper-types	oidc-sha256-pairwise-sub-mapper
07e53a26-3861-4c35-96cf-a333200e64b1	452d6d8b-b7fb-48b6-91c0-c497b0b02682	allowed-protocol-mapper-types	oidc-address-mapper
fd59a194-9f13-4586-9bcd-2d6b5a7fcca8	452d6d8b-b7fb-48b6-91c0-c497b0b02682	allowed-protocol-mapper-types	oidc-usermodel-property-mapper
ee30c66c-9e4e-4bb3-a0f9-1ef5f57c4f3f	452d6d8b-b7fb-48b6-91c0-c497b0b02682	allowed-protocol-mapper-types	saml-role-list-mapper
817cfa0f-ed46-462f-b70e-75e78f4cb15d	e0e55188-7e6a-4389-9f1c-7003f1b57685	allow-default-scopes	true
26523e94-ce33-47b8-877c-d81c394cdc44	596c0016-b823-4f2a-9a32-87507700d68c	client-uris-must-match	true
85375141-d1ab-453e-bd48-346a6db1b487	596c0016-b823-4f2a-9a32-87507700d68c	host-sending-registration-request-must-match	true
7f2b08cd-dcaa-44a0-b18c-8cf4bc4c5f37	6ac3f9a2-aaaa-4668-a529-8654ae7ffbe8	allowed-protocol-mapper-types	saml-user-property-mapper
aa709f24-6178-4e3a-856a-bf59f66a3431	6ac3f9a2-aaaa-4668-a529-8654ae7ffbe8	allowed-protocol-mapper-types	saml-role-list-mapper
aad971c4-6400-46f3-a264-5c2040db7606	6ac3f9a2-aaaa-4668-a529-8654ae7ffbe8	allowed-protocol-mapper-types	oidc-usermodel-attribute-mapper
9f55c30f-734b-4343-a9c2-174e69ab84b8	6ac3f9a2-aaaa-4668-a529-8654ae7ffbe8	allowed-protocol-mapper-types	oidc-usermodel-property-mapper
f6a8e311-041a-4fae-925c-cc9fecf492c1	6ac3f9a2-aaaa-4668-a529-8654ae7ffbe8	allowed-protocol-mapper-types	oidc-full-name-mapper
a2d2c8c7-15a4-4770-aa0a-e758b6ae8b76	6ac3f9a2-aaaa-4668-a529-8654ae7ffbe8	allowed-protocol-mapper-types	oidc-sha256-pairwise-sub-mapper
6e25db48-0492-4beb-86b4-e318e06d905b	6ac3f9a2-aaaa-4668-a529-8654ae7ffbe8	allowed-protocol-mapper-types	oidc-address-mapper
2277a526-ae79-4b5f-8ae4-7f614b1daa76	6ac3f9a2-aaaa-4668-a529-8654ae7ffbe8	allowed-protocol-mapper-types	saml-user-attribute-mapper
d280d17f-88cd-436d-bf04-254de3b4286d	f9c2dcf8-ee1b-450a-a4ea-e13ddcbeb5f3	allow-default-scopes	true
df4500da-aa7e-401d-b438-9f5034efce96	709ea7c4-6a20-4263-8430-172371234aec	certificate	MIICmzCCAYMCBgGN1TD5/zANBgkqhkiG9w0BAQsFADARMQ8wDQYDVQQDDAZtYXN0ZXIwHhcNMjQwMjIzMDg1NzUzWhcNMzQwMjIzMDg1OTMzWjARMQ8wDQYDVQQDDAZtYXN0ZXIwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCeOiExMDN5RivvljecDEbffJzwL+vY57cWQekvCu9U62A6FzK8KdHUD61qWMzaSzTG1DRvSIgJeQozEgrpn45pjep6GGHr2QIHZaQFGuViwCcLMdqITIwP1TVCs4w1gI108UGmHaplxE0wWz0pdTI3bTUX8Z4ac32KG+8bYKzr3MzG51LdFM1PJo2wdQLr3xwaMlyAOTZNlbA7gEERGjhhXQp6D945iEh41NAjug4h/tTznF9bZvorWN52t5pr+5rl2jmwunG3VBs0kco3vfitDqwU1Gk2I0a2b9A4EXxUFI5XNZNdLBQJHVhki/XdPf9at47OlzO0BZt7EegmN023AgMBAAEwDQYJKoZIhvcNAQELBQADggEBAGfcjqrseMu7mjT6dy3cg89P5MYbuNx1IDsZDnxkl24N9e/ZV/CY4E02bi/GQHjyfuyYuT7bzf7adXSFBTpqgB52KPZ1CLEtMwDqHrwgYv+zA9vq17nb4vTb8++3ibEblwPWIEvhZgnUx7ui99+XILIl4yR8iOCkgunHfK3NMPLnjEsohcJl8ijOLE3kvqvjK8qmOgK0tiYWgQdbPGDu9C7bIQhq2TyIr1BMsMV/iTiLpaHVQFN/6lzSspzKmzdwyEKwTqC0zvu1E3rI7+Cuhnl8xzi6SqM0fgwENRBSaoh7UiHUGOQ4h5+7fVDL1F4Xnt13NM0VlojqpDsdeDJiGec=
be166d83-a872-4ad8-80c6-84221d89239c	709ea7c4-6a20-4263-8430-172371234aec	priority	100
28b77238-80ae-435f-ac6e-26f66499638e	709ea7c4-6a20-4263-8430-172371234aec	privateKey	MIIEowIBAAKCAQEAnjohMTAzeUYr75Y3nAxG33yc8C/r2Oe3FkHpLwrvVOtgOhcyvCnR1A+taljM2ks0xtQ0b0iICXkKMxIK6Z+OaY3qehhh69kCB2WkBRrlYsAnCzHaiEyMD9U1QrOMNYCNdPFBph2qZcRNMFs9KXUyN201F/GeGnN9ihvvG2Cs69zMxudS3RTNTyaNsHUC698cGjJcgDk2TZWwO4BBERo4YV0Keg/eOYhIeNTQI7oOIf7U85xfW2b6K1jedreaa/ua5do5sLpxt1QbNJHKN734rQ6sFNRpNiNGtm/QOBF8VBSOVzWTXSwUCR1YZIv13T3/WreOzpcztAWbexHoJjdNtwIDAQABAoIBAAQQGbkXHpiUcN1f6JalCWQvYXeYwMAa7GxxuH32PxYETei/9BQOfi5T/A/OhELDX/FjvThG+a3wlzlKKHs+QccRF1PCRjAVrEPUsXpWFKIirVNQGOdGET9OKhDH5nzwi5v/SUBtjj9luSuu3r+unDb9zWQLgWlMIjhGe68iyN3s4le8K6dNXVBMPKrQ4KolLKCaPSHc+lwqgw7g9m5dGxj0MNVMsyiQYpDAjbVrIkAcGtFdZt1IAP9AoLEBtsCCoAD1vsLyzbOum6y8RWIxxbzkGXxVrzEUeExXbqgCKaiXCb1pLECCsatjQSMxPnC3X9kfz+Gq+tS+I3AlSg/TwWECgYEA0B7DbJR2nuwdMk/RbGCycdLzrg7q1t+On8GzYvUZfzenSuMe/Nzrh5HYVvxvHTGdI5+lMCbl4eXC1iNbZd3CbF4TOG+1nKvClhxW9VeYTAH/McvwsfB2ZnH3H76dsVJ1RZR7iY8AeFogopgLViOxwlQL/4tG/8dXPVMiI5EeJmECgYEAwqDpjSsT4etvCDVG2Ilsl4zcs/RLOGNSgmID1rt/57qw/SaXkHevEJg36L2xESb9rpGrV0MT2j38eLMjCxFMGADHoWLbTgL6GhLWb8tOyKJdB3dWcGSILpBsKi7WZRhitsEeCQrM1SYWNmcari7DMjm1eODb9GD1oswE1LcZuxcCgYEAh3MOIzO4xBPNqLn0BcIlQRlXSPgidThIXcc2VfhI4Ng6w+1vdIjfrXsJPwvJ0UlCCTZUzzLxuITNuoqGaJTcfaT4g2mI3G+ZFBNbsQ+Sah1+lk0x2M00cdZITNvFS+vrsR5DDLMKTknyJYApGKXggiYrLOTbj4qQR7Q8asN+yOECgYA0dSp94h55xfsnOzTdKC0cq9rQpgegKyUR/1kJh3/x9V++26f+SEPnNR/cm0QeW2QEqT6FRo8TQ6HI5n+LfB4GWi90UDDL1gGTBYDGoQWbDigE2yVxJaeO5V5CAF3I4cm5eFOgHEkZKirSfvex+uihoOxIqFKgi4GpX1PuAWvuAQKBgAVEEFAgXJwxx3bVWxyHlE4NVX7Rx59+Bxh+XVYA12oo6pEzsLJfX0Zmi4wvplpLxC7tPF8l2dCk1q8n6lYTCWc/+e1sLMY4K7pBD2wWUdb3cu4oP/0rjKmuAIm02EJdUi8/u4f1i6OeRlgUjvU8dw8I6yi4flC7mvhkCWwYM+SS
09a6d98b-3e18-4977-810d-ab319b1993ef	709ea7c4-6a20-4263-8430-172371234aec	keyUse	ENC
03c0b894-f57e-4532-a32f-9418a6483efc	709ea7c4-6a20-4263-8430-172371234aec	algorithm	RSA-OAEP
7890a4d2-9f7c-45d5-a427-ff9fa91fa3e8	c810fcf1-feaa-4c15-a570-e6462e8d189b	privateKey	MIIEogIBAAKCAQEAwjyvbK/8vp+g1uRh3c7CykU9i3/R4iIyHoObZATh0Wj4ENuKn4/JygPzMRwtro9Z+jVbAtTupiTwfM6qm4CCH+LV9jbTxBFzdgLDxE3zO6/+DkgT2jdcKPcHIEqFamL9oTLnWTMirHjRtL6w5oy3SFhgYIlHD6/GFNp/kqKnhLjpnWmKulpKPbsz/oyZPDbg9ABKCLrFwOExJchM0YisROpLQ3pT5LKc3dQVcr2VdVNe7gBLahHMnkafE9VZKYRC+IgM68ygpIjqgPGh8Tv1iT1kiO6kJCyz98fTS/YiVirb+iXUm599hoaJ+V81axCE+8O9I5N4CoEoCZrVqzX/1wIDAQABAoIBABIcbao18ELBLtKBHqb7kN1Vy3SAb8xYFLhHqThdEPlHtZAZogYl9oWbP+FqZGml/P7/9QNOLqc+doLZelfGVo75xapcvmFf0/ypXiIMHdi8HKit2KJv2wYIbDLhZlzfHt5MmTApPNuigFs/R86XfFeG9gv9gN5Z+dKwwbulTJCeMh3exLJwa9XXEcvF04ufmDQY+OmWCDURw1Hac2dn2F5UD09uukSlmYPta9sspUWyOvn5ToUXob0T1sh4BKudTT8BAChvpNX8+PZdNLJQ6VOmp6qSP2C9jARFyLbePKulBZPg9B0TnceiPFt4gewT8wT6rW8mhcVAQhyKHu3XfsECgYEA4KmJmTomKdGd7QuMGuyXpNO85F+MC2rE8XpDFfT/dMzUppVMDdGIHDKytDO0oMvBGlrzqZF9y/ZmACbq5QoZvK6QwrvBqByO5yzobUO98X+OhCtkRs1e+AHJyTvaa9FWBElMXK3aK6Mj3O1Vxut4NlNi2AlTwwh4NxMdVME8YRECgYEA3VSxxS16Brj5ru0NW6WJ7UvVQof2s01ubTLce8Xtr4b7A7LFSRnB1IqZUgF29wLGK5j8fbetZ7uzwDWKo21OCOYMkrP2xn4l7WdzVcbHT18YbNtXLGZu0rmKaBxRY48Q8yKKrSYAp6H/hh2UNPJFHKpioxpifW8KFzg8X6+b0mcCgYBwd27SrjF8rdsJV8aDk/02HmlpSgupi4GcAUCkNUnNBt1Np1+zazlgJGEhpOC/vkClGPLx6Eu5V1goq1Lb5fqMYjdFxQhlSCahw/F3AXqM8vY9ZBuG9jicnwiNHNFzOBB/hNIdc0rMnZbOemF+e1Jqn8PTspekAxFrQL5mN3YqgQKBgHowqNf3rFeLxWR6QJapBEV6SSkq0NraU617l9fJRNhTx76Z8mrSCn1haxWn81qZMHifRD3Pqq8LJEhoBrsEvEETaDuRmRqqSBwRsc3YKO67zEtEqJK9lk9F2ZBymchCEpR4LGE9Cr2BJQWQzOKSIe+abUwoY9ll9Qcup74XwAnfAoGAL15+voExSFxWdTrBl/FAahVyyf61rSOu0nOZ6/ozvq16gdmNBfOc9kt7IUJ7/JMubyrnoPxbl1WuacyljRCRNedKaUbE2EINNqwR8REUHVrfjTM8fBcxgNsSRTt5lcX2RDBa3msSoo7zQ82YKmpeXOu4m7MFWuGcL7Mdwcsl1EI=
7570f6d7-ec76-46b7-9d30-d4b561271002	c810fcf1-feaa-4c15-a570-e6462e8d189b	certificate	MIICmzCCAYMCBgGN1TD5cjANBgkqhkiG9w0BAQsFADARMQ8wDQYDVQQDDAZtYXN0ZXIwHhcNMjQwMjIzMDg1NzUzWhcNMzQwMjIzMDg1OTMzWjARMQ8wDQYDVQQDDAZtYXN0ZXIwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDCPK9sr/y+n6DW5GHdzsLKRT2Lf9HiIjIeg5tkBOHRaPgQ24qfj8nKA/MxHC2uj1n6NVsC1O6mJPB8zqqbgIIf4tX2NtPEEXN2AsPETfM7r/4OSBPaN1wo9wcgSoVqYv2hMudZMyKseNG0vrDmjLdIWGBgiUcPr8YU2n+SoqeEuOmdaYq6Wko9uzP+jJk8NuD0AEoIusXA4TElyEzRiKxE6ktDelPkspzd1BVyvZV1U17uAEtqEcyeRp8T1VkphEL4iAzrzKCkiOqA8aHxO/WJPWSI7qQkLLP3x9NL9iJWKtv6JdSbn32Ghon5XzVrEIT7w70jk3gKgSgJmtWrNf/XAgMBAAEwDQYJKoZIhvcNAQELBQADggEBABsfLhSXG2yjfMzSH9loc2xCxng4kwVMmiCSFiFvkB328BkTCzO+JVdruWTGIxcu2Xl4A4mmosVXHAU4OgZkt9T2pnvJkYGIEZV369WVaN83x1r2JDZlpHKaNbNB6kdJKMzxfVVatmVxtj8TBqat4Q/fmF0fqe84q5d+mkj63uvdBr5JmvEUvx2KJpQ5U5xij8EgF0oE4VNRf3MhJKVkFLqgo7/vy/ZJd+YA4hZJMIllV2faj2oGi4bRzR6N/04sZ27DyTdsZcEhFxKZcaKsoAIXJ9hG7IhkIyRjX90f7RM4rVyLYEtUNQQYI+/raUMFvhPXCR3w8GOZ5L+yGfNx/WU=
a4efa359-2d5f-42be-87ba-3f6feb6a5de2	c810fcf1-feaa-4c15-a570-e6462e8d189b	priority	100
c34b2014-4dcb-4d20-afe3-bcb263a9e94b	c810fcf1-feaa-4c15-a570-e6462e8d189b	keyUse	SIG
d702c698-3c7d-4523-accb-ee4595529182	7af9f04d-0c66-43d6-a6e8-c7abbc860b4e	priority	100
4e555b15-8458-4ef3-9651-ef209501161a	7af9f04d-0c66-43d6-a6e8-c7abbc860b4e	algorithm	HS256
b0e7e095-91e5-40e2-984f-b6b6dc6567cb	7af9f04d-0c66-43d6-a6e8-c7abbc860b4e	secret	Y5l2s1FMazXfuCLRw4TzDG2DkoWKHl5pR5PIiXc64wt6dCJCCGRISLEawX8mLXm6VFl5zQh_EVaUqz-etxmLOQ
aa44b318-f7c3-4a64-90aa-ab3e56e950c0	7af9f04d-0c66-43d6-a6e8-c7abbc860b4e	kid	a468c2f4-2271-498d-aad0-91f9bdc04930
7ab78324-3892-4681-8604-07781fb59ce7	0ab2a2d6-dba6-4499-a59b-249a7ce56898	secret	zKsWQuZpoQzbkfJ2tiITBQ
e4146c52-250a-40fe-b1bc-5c2f9e906e5f	0ab2a2d6-dba6-4499-a59b-249a7ce56898	priority	100
339e3369-7a41-472e-a0db-8427b6d45dac	0ab2a2d6-dba6-4499-a59b-249a7ce56898	kid	ace3ce63-3b13-44d1-9710-0afa771f0e8f
8e694130-2135-461b-996a-4b5c936c6685	52fd4078-8915-4480-a440-fa1959b82769	priority	100
ddee38c8-16cf-4a4e-acae-0503a86cacde	52fd4078-8915-4480-a440-fa1959b82769	algorithm	HS256
81aa26aa-ff71-4434-aac2-c426be0a7931	52fd4078-8915-4480-a440-fa1959b82769	kid	51892dfb-fa8a-43e4-8080-4559d95e028b
d030cc2c-c7e8-4208-be5f-25ca0d96352c	52fd4078-8915-4480-a440-fa1959b82769	secret	yymshy9s1jKaDiG--6UA5Jqm7Fb3S3eUVE7Sdw831g9HkO3PQ6WFxRg6cqaOVWOAMkd4ACvGEISsQQvgVB5AEA
0c687849-f5f9-451a-b7b3-ad5cff4c1af3	2472db39-b5f8-4810-867c-a0cc8ba97c5c	priority	100
847794e5-e170-47c2-8a12-8e4281786de6	2472db39-b5f8-4810-867c-a0cc8ba97c5c	keyUse	SIG
69ddea12-ac64-44e6-93e7-d7a3e3eb1fc9	2472db39-b5f8-4810-867c-a0cc8ba97c5c	privateKey	MIIEpAIBAAKCAQEA3OYMVq25RL31Is7zZ96lKs/jxbnTZ9OkopJDqb3EMq2Tr1H4vfnQNxieDDhmWR4alP0WFghqHqF7Y/naHp3hMIrJGMGa2h6Sv5IGA2FsZTl6iYEmaMcm63FQtPvO5x1tAQcxPVRmHIQ+Jn/Pz0MPBTSUJEp7tmaXrMR7sRdPDsN5758PQ82mUMEdjM2i9FvMc6CB2iK8O5Ms5kD2FGbEcVglq8nB1RJIoCMAUjrxEE8rid3Rui8fOA1WjD4Ogh9Nm3uOISD+8VSD8v0vJV2BXeURk7w+cSN/I+o90uzaBgJx/IF6mEncXCrWaXvddMU5uWuXsLSAmyj/ChwCl9XF+wIDAQABAoIBAGUQycdkn1XQtVXSKrI0vwvJ5rPh09P2lKYe1l9UZ+4p1V6K2gwNPlLe6/y6VzVh3Raafp7hBbBzAHHa8A0+/bdIYD534eH2x/xnEmI8kivz8tjzon+g0nE5PIw5g03hfCxSvpgJQ9i7NnZF1u3EiBxBFKBQBa8L3Exa7x60g+LD+iUziw+qB+NqoQqgKKz1KWhbaSqWhdQeQh0tAXug5bC1xBe8IROoRrEm8pO8dTgdtnr+PtulcdtKBSYheBUDPY/636ohsUbyNUx3Idfc9jzCKQzIIQrIDCsEi5NGs4ufndYflVHYsZwXo1g4LgRTiEplbDv1vztiLw8bAIQrGAECgYEA8ec846X4H7d1uhFlzkRoIT1ccx+7K+Hk6tGQp9jJ069lPzKoALVYVO0SLUcG3CqS6WNROGO5B1vQ0hIPUlmgYHFZ7RSQwEF27wAjSO8y+c4eP/HSnKhJHYSatYxIk0d+1TUgs4CnqEobAdS9Q4mL4LkNSxTlytfjRSg291pF+AECgYEA6cV1cS0RF9oWWA1W7Gq/CxUHq3xD5e1ckSdYzzc3lg9rssBizzEScmvrZJkSEVCwM8i4xBh+/Di8QWdJmxDoVBkXL6rz4HneZA0uoj0GCum2z+8XoW1ANiFnGZgaK9snEEiu0Cw9RUNcZb2w/Fz+SWzIeCF6k9L6b74Pr0QjnfsCgYAE1OaNcXo0P/jU/5X1+b3OtCgNkJuvc7Kb0hW+lIDrfnxaN8vNP9IE2DtdtiZ37U3D5ZzwsGU4tWfFWmD99xZR9tGh/6AohuY2Pd12jniJLsnB4zWetWnIciaY67VjY7Ev1wDRNQekP96sObCSEcQ+d9PBJSi11XwPnI8Ef8QYAQKBgQDkEGkINiBj9bcwxirUUTv6ktS9v2j6azyQvCNPXZ5UPs0iQcDkRAqsKI8owJE45VBR5PQlE4Tnim5XHG5Z4v/V8/iD37M3f42wbI/fZct8YBCjAa47JbusU6Ai/xohSRfuMgqiO1a3OQVumMaPHiZS+dcGJBtTFlSPKYxhwAdDewKBgQCrTSADjLp0mqpVW/RfWCf6rgPSZQTje2/4CnoX3dNSftLJPXt8p8shVWBCDE3yDJSd2nkgX6/HUrO/o4lhHRxFSdG8NJsyoouwu4FaCtG8LYFr9pK5vQHOIjB3hi8XTf8KD4Xw9FkdNNIKYkNGqOPck/Zc87xHqKhXFmDLaHMdHA==
5925c004-f7fa-41b5-9ecf-a07d9b162921	2472db39-b5f8-4810-867c-a0cc8ba97c5c	certificate	MIICnTCCAYUCBgGN1WGfcTANBgkqhkiG9w0BAQsFADASMRAwDgYDVQQDDAdkZWZhdWx0MB4XDTI0MDIyMzA5NTEwMVoXDTM0MDIyMzA5NTI0MVowEjEQMA4GA1UEAwwHZGVmYXVsdDCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBANzmDFatuUS99SLO82fepSrP48W502fTpKKSQ6m9xDKtk69R+L350DcYngw4ZlkeGpT9FhYIah6he2P52h6d4TCKyRjBmtoekr+SBgNhbGU5eomBJmjHJutxULT7zucdbQEHMT1UZhyEPiZ/z89DDwU0lCRKe7Zml6zEe7EXTw7Dee+fD0PNplDBHYzNovRbzHOggdoivDuTLOZA9hRmxHFYJavJwdUSSKAjAFI68RBPK4nd0bovHzgNVow+DoIfTZt7jiEg/vFUg/L9LyVdgV3lEZO8PnEjfyPqPdLs2gYCcfyBephJ3Fwq1ml73XTFOblrl7C0gJso/wocApfVxfsCAwEAATANBgkqhkiG9w0BAQsFAAOCAQEAYCY383p6zB9X2e+Htr0FVym2P+MXTYmeur6l49XISu9k7hnkM9QAOc8ef9Lwj6NX3yIBnzofcGYN90ItKg2AHGTPNc3+n+f8apyu/i2mP6yS14ig1DWjMMYl2V/GfJLL0/DXqBfdYk/mRShfbEndiOpEe4TO2ZUIthkyge3KEv7U+/f1apkI0SE+W0TIygszcg45A2UfTO/J85ur5vhkdE5KjHDaDgujlTZL9DcAmC+0VAT7VJIynuzQrsWnQdtpHobjXzaCH6XFcyR/ZPRTnf7HMp4MeonkpGy762ah6Dq0Lf5Bjvi5zV58vht2nzfEcGTlj+WIxKUFeHgpMWfkFQ==
34ae3155-f1d0-4ce5-b1b6-dd50c49e9b9d	6ec406a1-fe25-4a11-af2e-72d2097165bb	secret	1-FBlVTbUslG-481giiDEQ
d939ed80-c5c2-4389-93a0-2da13d6c4847	6ec406a1-fe25-4a11-af2e-72d2097165bb	priority	100
51f683ce-df71-4df0-b5f1-a8052504057c	6ec406a1-fe25-4a11-af2e-72d2097165bb	kid	ee0f9523-f219-47d5-894a-a889a0f5158d
ebc5288c-0e41-4833-a481-511a75d0c0ef	65a61399-7af0-4637-8580-150123f32280	certificate	MIICnTCCAYUCBgGN1WGgbjANBgkqhkiG9w0BAQsFADASMRAwDgYDVQQDDAdkZWZhdWx0MB4XDTI0MDIyMzA5NTEwMVoXDTM0MDIyMzA5NTI0MVowEjEQMA4GA1UEAwwHZGVmYXVsdDCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAMQ5FBmW9+J73JocRq0Dewxexo7/4v60KJMbl/EjzW8LkOpdPuR0WaS5VzuuXOXz8AcCqxPHm3SY+IO5YKJsbBRTUWK12wOEK0bLt+Aqaw9jJHCS/rBLuctxJNrVHgsYOO/16LNwAeVsEH2pj/u3vxLcmoHcvEEnL/N1xjBiIXFljMCa+s7hQVjun+hRpofy8FXf2eBOQ08mB/BejDXMe4hxvQL26DVG/dxcNhm4+tYktGIpCjaYdHIlzJ1ACLHGMPO8uaWmDft24FFOssZxbM9VbUSZbmqj5d88WnosKtvy5UUgpvHIfYzQ+8GtkuriTch7ECyxHTu6XGvZlibSPCcCAwEAATANBgkqhkiG9w0BAQsFAAOCAQEAN+AxgcHmo2kBFEV3wg+n0lQscHX7uI+MCYR9zlq7RP6eSCKNju7AFFnxYPHoqvQ66SdbRoUR3fOu3HbOiIZASvmP9e7oVVT2iVvYViS2onEeIJjL0VKH5PskO+fnAzg+vEG22kBEtEL+4olzNCqG3VQAjuAThXNESyiSPXhCXkYHwyy5PCn50FOE6beJcGInBJHLnxayIi9/9cKq10U4YXe4WdXhpSQ+eItI25NipJcXDM/v7zsjRoEnlSzXkCY8gKLiaKGNo5/sm9Ar/cSR+k5vgEnEsseH87cuwQe0ZKSuB7/VAXYTRb/SgIlKWnUSIOg9R0jBGIw5k/785uUzlA==
705fbb69-0a03-442c-9d8a-9f4e188b307a	65a61399-7af0-4637-8580-150123f32280	priority	100
23ff7b62-c1fd-4b8b-8950-1c27c2ff9ef9	65a61399-7af0-4637-8580-150123f32280	algorithm	RSA-OAEP
440811e3-8438-45db-a473-a77a92b4688f	65a61399-7af0-4637-8580-150123f32280	keyUse	ENC
5f2b5016-d1d7-4718-987d-de1ab6926672	65a61399-7af0-4637-8580-150123f32280	privateKey	MIIEpAIBAAKCAQEAxDkUGZb34nvcmhxGrQN7DF7Gjv/i/rQokxuX8SPNbwuQ6l0+5HRZpLlXO65c5fPwBwKrE8ebdJj4g7lgomxsFFNRYrXbA4QrRsu34CprD2MkcJL+sEu5y3Ek2tUeCxg47/Xos3AB5WwQfamP+7e/Etyagdy8QScv83XGMGIhcWWMwJr6zuFBWO6f6FGmh/LwVd/Z4E5DTyYH8F6MNcx7iHG9AvboNUb93Fw2Gbj61iS0YikKNph0ciXMnUAIscYw87y5paYN+3bgUU6yxnFsz1VtRJluaqPl3zxaeiwq2/LlRSCm8ch9jND7wa2S6uJNyHsQLLEdO7pca9mWJtI8JwIDAQABAoIBABaDlA5Rl5SJcKjQCL3uMc6cCz06F/Hwet1SI69b08Tjd1ekpkQxI132lA85dNg/knFDeZyV4PzSVmVKvk80kHwOiT6BriTro8mGM01JoKoNzo8KFqXksmcozrk7DazpNRM3TGFWPylzKjs42tffX9GKtUGkMYdqNyLAhyJjCAJKGF7fh8t5woJo70GdJ5NNL5xL7MSWxRfaQoSPXriQme7PyJTkshX8YLEAgSETVwXyd07fWlSRhuD5Mf0Zz8iCA1401eu/MWB2/rdlMQpA7wsvcU+M1HwoNyYfOx/o59evADelozNAF2RnvSsjEkDSHGcojjLlen65xALiE63/6BECgYEA9p5od3dFan9SuAGBrllhOUM0/VFyU77UOuNxGNbSp85Cnco+gbv+Cpp7d20kaQrEGX+aV5qYYMo4xKLT1jUMhz+ANsvJbtlrW2uq015lH+ow/N/xeII6ozFD08Kcw9KGRVx6ZFUsNlV5ji9G1S7jUaRFBb+GHOHedncj2MpZ93cCgYEAy6/piELxEirXgz8X98ICJrB/fHusb+Q6XZOuRVyU73FWez0aR6PXm+cFzFLJxzfPevTZ3Js43YZSNrHUMOkHW37hlxIiTqDvNGbcQMsi6bxJ/Zgk4wfLLhIrNegoefZzHRHMLJ9kZ+HeFvutQG+jXNqFwvNzo8JZxVpZBDkPbNECgYEAn5/qeCDwAj2FGeqHuITLpBe3DZuRB1mF3tPmGTC6yrh7b8w+5xP6G3zgG22+WmsIgISSLs+2fzeExOmreYN+p2/XmiAPMjtx/ItU11jK1Xxs1tBQaDLKp2Q0xbS6aRkzpWN1KMnkQwrSEdDR5RxjMC3GKzFLKhicOEtnHWPkFYMCgYEAo6gO+oXWzmMP0At0xYPjWJS9ihaQgUKeRquu/Voa7JxjARgiMmeJiGFB/l6Sc3f7Q+7R0XgCY7NWAU42kKnbWH+E4G4YlJaoO7FdzM2qmqTHynNhR+zuKnE8uM51HzGOYk/3fe7/rJwFZvAGz1wjpSqLCQ2032H74R7roQH7y9ECgYBbGhbFC9J9i5LMFni7x/za9YbV6UboLws3tP/o+Q3gJChUEto9uvJCkCvO+IKQEFZC9+dm1pHEK03Nc2tWdHAaW3sJ5FrhKXm5LDDhw9FXVQejRRsRhAixB3+0u5oYDWZcDHpeI6cUJ4Q1MkGJ3G1OG3SClvTvVjq9CS12uchhPw==
1828d67a-64fa-46ee-b8a4-f98291b41645	ee869fea-d50b-4e40-85b6-7123c55233d5	allowed-protocol-mapper-types	oidc-usermodel-attribute-mapper
3870cc36-f251-49c8-ba9a-b0d0213c847f	ee869fea-d50b-4e40-85b6-7123c55233d5	allowed-protocol-mapper-types	saml-user-property-mapper
8a430ae1-b59c-485f-a8cd-ca4d01839fcf	ee869fea-d50b-4e40-85b6-7123c55233d5	allowed-protocol-mapper-types	oidc-full-name-mapper
dd29f37b-7217-44e8-bfb6-97d2d576a5aa	ee869fea-d50b-4e40-85b6-7123c55233d5	allowed-protocol-mapper-types	saml-role-list-mapper
007defe9-453f-4c57-bf16-ea1055a26841	ee869fea-d50b-4e40-85b6-7123c55233d5	allowed-protocol-mapper-types	oidc-usermodel-property-mapper
68c1b7c5-69e1-4521-a3ef-5160a0b3859c	ee869fea-d50b-4e40-85b6-7123c55233d5	allowed-protocol-mapper-types	oidc-sha256-pairwise-sub-mapper
51a8aff7-6f32-49d4-97a9-b11cf0cf0406	ee869fea-d50b-4e40-85b6-7123c55233d5	allowed-protocol-mapper-types	saml-user-attribute-mapper
7d5355ad-2588-4a2f-9d25-5b3a063a1cfd	ee869fea-d50b-4e40-85b6-7123c55233d5	allowed-protocol-mapper-types	oidc-address-mapper
17cf7b38-65b9-493e-a008-a502855b97e1	a663bc47-2c8f-4842-9b8e-e85745191717	allow-default-scopes	true
52f520b3-2bb2-42cd-a36e-f9da029b5731	9302579f-bc4e-4de7-aed2-9610e988ba66	client-uris-must-match	true
5dc7c375-8710-4253-9541-60efbeb8e147	9302579f-bc4e-4de7-aed2-9610e988ba66	host-sending-registration-request-must-match	true
4f5e0df8-b354-45bb-89a1-5cfcdb9ea036	143e8425-b049-4ec6-a403-5948a241f37e	allow-default-scopes	true
d3b3747a-4bd7-436c-89f1-48325bc5a456	a00bdc65-8ff3-4eac-8184-86f20ecef5c2	allowed-protocol-mapper-types	oidc-usermodel-property-mapper
b0f0dad2-52c1-4cc1-9709-4568d551dce3	a00bdc65-8ff3-4eac-8184-86f20ecef5c2	allowed-protocol-mapper-types	oidc-address-mapper
830013cd-cd92-4c8c-bbe0-190d35a9abaa	a00bdc65-8ff3-4eac-8184-86f20ecef5c2	allowed-protocol-mapper-types	saml-user-attribute-mapper
be77e991-5f0b-4943-9341-07836744cd4c	a00bdc65-8ff3-4eac-8184-86f20ecef5c2	allowed-protocol-mapper-types	saml-user-property-mapper
ab72b568-26bd-4963-b9df-039daeb49814	a00bdc65-8ff3-4eac-8184-86f20ecef5c2	allowed-protocol-mapper-types	oidc-full-name-mapper
6b40558e-0ec7-4252-8e35-4ace963d5b75	a00bdc65-8ff3-4eac-8184-86f20ecef5c2	allowed-protocol-mapper-types	oidc-sha256-pairwise-sub-mapper
cb7fb958-de55-4ce8-b1b8-f58397a0c156	a00bdc65-8ff3-4eac-8184-86f20ecef5c2	allowed-protocol-mapper-types	saml-role-list-mapper
0e82933f-4f2d-44c5-b85a-b500b75211af	a00bdc65-8ff3-4eac-8184-86f20ecef5c2	allowed-protocol-mapper-types	oidc-usermodel-attribute-mapper
f2d4323a-338a-4a30-b0f5-b5cbeae0366b	a485d8e3-58fb-4018-965b-c9647e81ff3f	max-clients	200
4e4d472f-3b5c-4591-9085-def6b9ea2fab	cd7ca05d-2356-45a8-8c30-3e8e7e7776ef	ldap.full.name.attribute	cn
58cb49b4-0baf-4fa2-adf8-5726ab61e049	cd7ca05d-2356-45a8-8c30-3e8e7e7776ef	write.only	false
7ad5169c-9228-4f93-a96b-6c5db6acf40a	cd7ca05d-2356-45a8-8c30-3e8e7e7776ef	read.only	true
2cf9cf3b-5e44-46bd-b1bb-663e47d004ca	94f40fd5-a633-4f04-8968-b6d27e7c3061	groups.path	/
f09463e4-b9cf-4a7d-b896-82ae6f9aec5c	94f40fd5-a633-4f04-8968-b6d27e7c3061	group.name.ldap.attribute	cn
2395d0d9-d633-48ef-96a9-3c3e52105d5b	94f40fd5-a633-4f04-8968-b6d27e7c3061	mode	READ_ONLY
b137a60e-4f8c-4c88-b1b0-1e9a4c40cc64	94f40fd5-a633-4f04-8968-b6d27e7c3061	user.roles.retrieve.strategy	LOAD_GROUPS_BY_MEMBER_ATTRIBUTE
a0a2ed56-f655-4b70-9761-3e866e5a344f	94f40fd5-a633-4f04-8968-b6d27e7c3061	preserve.group.inheritance	false
822dafa9-de0f-47e6-9423-89ad62685121	94f40fd5-a633-4f04-8968-b6d27e7c3061	ignore.missing.groups	false
8f0bdae2-30f6-414b-a160-62c63ca9e459	94f40fd5-a633-4f04-8968-b6d27e7c3061	membership.user.ldap.attribute	uid
bce9d8b1-9e2a-4d2e-917a-4f6e8a4752e5	94f40fd5-a633-4f04-8968-b6d27e7c3061	group.object.classes	posixGroup
783f7936-22d1-412a-af35-018a27d69459	94f40fd5-a633-4f04-8968-b6d27e7c3061	groups.dn	ou=groups,dc=example,dc=org
d8d2397b-bea3-49bd-afe9-8bc3112eb4e2	94f40fd5-a633-4f04-8968-b6d27e7c3061	membership.attribute.type	UID
2a06f100-4031-491d-959d-4a4fa3896ebf	94f40fd5-a633-4f04-8968-b6d27e7c3061	membership.ldap.attribute	memberuid
4fd0fe85-ebab-46c2-bd34-33a75aa69c5d	94f40fd5-a633-4f04-8968-b6d27e7c3061	drop.non.existing.groups.during.sync	false
5a7db81a-7dc7-4091-8118-cd96b577b397	94f40fd5-a633-4f04-8968-b6d27e7c3061	memberof.ldap.attribute	memberOf
f13f185e-7b53-4e27-8532-61eafb5cbc30	c94dc336-2a53-481e-ade7-462a1d3ff67e	always.read.value.from.ldap	true
ca6a76d6-63f1-425a-96bd-c2ed805f9397	c94dc336-2a53-481e-ade7-462a1d3ff67e	is.mandatory.in.ldap	false
05a6abda-b95e-418a-bd60-f8662205edfc	c94dc336-2a53-481e-ade7-462a1d3ff67e	read.only	true
43273f74-2672-4a48-9177-c22a2d1be62b	c94dc336-2a53-481e-ade7-462a1d3ff67e	ldap.attribute	createTimestamp
d9546d67-7224-47ef-ba03-8e4039c60894	c94dc336-2a53-481e-ade7-462a1d3ff67e	user.model.attribute	createTimestamp
469a7e2b-535b-4eb3-a1cd-011eafa53201	8fb21468-bb0f-49a2-9b0a-358ba4deae7f	read.only	true
5cc4a4e4-2976-446e-a8e7-c1c98dcbcf64	8fb21468-bb0f-49a2-9b0a-358ba4deae7f	ldap.attribute	mail
8a34982a-734d-4ece-9bed-925ce9ea0fa1	8fb21468-bb0f-49a2-9b0a-358ba4deae7f	is.mandatory.in.ldap	false
5e7fecb5-9226-4d9d-b016-857cd9d11719	8fb21468-bb0f-49a2-9b0a-358ba4deae7f	always.read.value.from.ldap	false
d8f84b22-6c81-4276-8b48-d092f188a9af	8fb21468-bb0f-49a2-9b0a-358ba4deae7f	user.model.attribute	email
84323e8b-23a2-4011-9dd2-b517f94911eb	b7990307-dc71-4acc-ab95-67748511bbdf	user.model.attribute	username
67df0dc6-d213-4bcc-ab65-b74adfad15e7	b7990307-dc71-4acc-ab95-67748511bbdf	ldap.attribute	uid
aa59245d-d185-444f-9811-1f5a28c04f7c	b7990307-dc71-4acc-ab95-67748511bbdf	is.mandatory.in.ldap	true
5e177053-b0b8-4530-96c4-9dd24627b462	b7990307-dc71-4acc-ab95-67748511bbdf	always.read.value.from.ldap	false
a07c582c-cc54-4d6e-948d-e760df3db6ee	b7990307-dc71-4acc-ab95-67748511bbdf	read.only	true
0aaa9015-d086-4cc7-aa96-6f4f2960faab	4f886323-92d5-4b1f-898e-8fccd15a1cc4	is.mandatory.in.ldap	false
0a7fbeb0-566a-4801-a371-bd83b4b87e2b	4f886323-92d5-4b1f-898e-8fccd15a1cc4	user.model.attribute	modifyTimestamp
08aba4e3-58d3-4916-a24f-f788847a3004	4f886323-92d5-4b1f-898e-8fccd15a1cc4	always.read.value.from.ldap	true
50fc2214-ae48-46cb-949a-3d27c350ccd5	4f886323-92d5-4b1f-898e-8fccd15a1cc4	ldap.attribute	modifyTimestamp
bc17bb82-c751-4307-982b-119195da691d	4f886323-92d5-4b1f-898e-8fccd15a1cc4	read.only	true
5447f849-3810-4d99-a297-e1a4aba926c4	5698c210-d29e-422b-8307-bff9da47e991	is.mandatory.in.ldap	true
7d6e478c-4a4f-4b05-ba23-16acd8a34f72	5698c210-d29e-422b-8307-bff9da47e991	read.only	true
4c3ac2f4-9312-4a2f-a268-bfc15533c0a5	5698c210-d29e-422b-8307-bff9da47e991	always.read.value.from.ldap	true
e2656f7e-0c49-4722-a774-524ec0573036	5698c210-d29e-422b-8307-bff9da47e991	ldap.attribute	sn
529dfcc3-ac85-42fc-b81e-d2c8c196c657	5698c210-d29e-422b-8307-bff9da47e991	user.model.attribute	lastName
d7c76522-b2e7-4b70-b3af-eb9a0542fbee	421f624a-f8fa-4a9e-9853-98d471e7f1da	usernameLDAPAttribute	uid
ac0fd0b2-fbfa-4619-9c80-cb809eacc629	421f624a-f8fa-4a9e-9853-98d471e7f1da	allowKerberosAuthentication	false
ad06a168-0329-4f17-bdbb-90a92480680c	421f624a-f8fa-4a9e-9853-98d471e7f1da	bindDn	cn=admin,dc=example,dc=org
c2ad90fb-29a9-4b65-a1de-6ef3c289f20a	421f624a-f8fa-4a9e-9853-98d471e7f1da	usersDn	ou=people,dc=example,dc=org
30e70e64-5450-4c18-909a-a0c9f8c4b164	421f624a-f8fa-4a9e-9853-98d471e7f1da	trustEmail	false
545a9119-ecd3-4e79-b89d-35809c929ee0	421f624a-f8fa-4a9e-9853-98d471e7f1da	lastSync	1708686330
b37dd75f-f592-47a1-b12e-2d0a2c8bac8b	421f624a-f8fa-4a9e-9853-98d471e7f1da	editMode	READ_ONLY
e9edcc98-0995-4f8e-bde6-b593455d1d2e	421f624a-f8fa-4a9e-9853-98d471e7f1da	userObjectClasses	inetOrgPerson, organizationalPerson
7ce5f565-fef7-496c-862a-c0866fd9079c	421f624a-f8fa-4a9e-9853-98d471e7f1da	importEnabled	true
ee856b78-2fde-419a-acec-efd82e714fee	421f624a-f8fa-4a9e-9853-98d471e7f1da	rdnLDAPAttribute	cn
3af74b89-7b97-4b61-b925-be8f1d8d122c	421f624a-f8fa-4a9e-9853-98d471e7f1da	uuidLDAPAttribute	uid
4daa72fc-69e8-462b-8bf4-d3e4cf79aa4c	421f624a-f8fa-4a9e-9853-98d471e7f1da	authType	simple
8513083c-f859-4e70-96e2-74d08d98191d	421f624a-f8fa-4a9e-9853-98d471e7f1da	cachePolicy	DEFAULT
cdd25b6f-b6b9-4bdd-a231-bdc1c859512d	421f624a-f8fa-4a9e-9853-98d471e7f1da	connectionPooling	false
33c9cc70-a857-4fcd-acd5-cbac440a698f	421f624a-f8fa-4a9e-9853-98d471e7f1da	syncRegistrations	true
77e70c9d-9932-423a-bbb0-a2a83eb8ff8b	421f624a-f8fa-4a9e-9853-98d471e7f1da	enabled	true
7be9aa06-0889-459d-8fab-df2399ad6b47	421f624a-f8fa-4a9e-9853-98d471e7f1da	changedSyncPeriod	-1
3fc21c6c-7cad-4d67-8c94-b7e5bc8e32b0	421f624a-f8fa-4a9e-9853-98d471e7f1da	usePasswordModifyExtendedOp	false
a9e8de95-60fc-4c61-a2ba-b6c884a37505	421f624a-f8fa-4a9e-9853-98d471e7f1da	startTls	false
fcc2a306-499e-4ad3-b9c6-f82ea2d9fa9a	421f624a-f8fa-4a9e-9853-98d471e7f1da	useTruststoreSpi	always
0569fcd3-68b8-4762-b9a5-463ea39694f0	421f624a-f8fa-4a9e-9853-98d471e7f1da	vendor	other
b668ccd0-5d9c-4f5a-bab5-321bc28a59bc	421f624a-f8fa-4a9e-9853-98d471e7f1da	krbPrincipalAttribute	krb5PrincipalName
7368d1f0-7583-47b0-9c70-e8b8f64f0058	421f624a-f8fa-4a9e-9853-98d471e7f1da	bindCredential	adminpassword
c77de225-e136-4939-9b28-18a51d3eb537	421f624a-f8fa-4a9e-9853-98d471e7f1da	validatePasswordPolicy	false
447ebbc3-df2b-42df-be6b-6566d3f32a24	421f624a-f8fa-4a9e-9853-98d471e7f1da	useKerberosForPasswordAuthentication	false
7861825f-1b48-450f-aa71-b830b9c65533	421f624a-f8fa-4a9e-9853-98d471e7f1da	connectionUrl	ldap://openldap:1389
f264f533-1464-4227-9727-17a98f7d4628	421f624a-f8fa-4a9e-9853-98d471e7f1da	fullSyncPeriod	-1
59a44cb9-b01a-4199-beb0-89bc7bd21a1b	421f624a-f8fa-4a9e-9853-98d471e7f1da	pagination	false
\.


--
-- Data for Name: composite_role; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.composite_role (composite, child_role) FROM stdin;
b11e6758-c4c3-4830-a537-dca51a5c65ad	0e2d6618-377f-4c3e-a8b8-a6f672e25c3c
b11e6758-c4c3-4830-a537-dca51a5c65ad	4ab9a7dd-bad2-4522-9130-4a3cec5c396f
b11e6758-c4c3-4830-a537-dca51a5c65ad	605956cf-0433-4729-9eb1-d67cbb2a2078
b11e6758-c4c3-4830-a537-dca51a5c65ad	5d1d306e-b9a4-4ed1-a81b-486c29df9062
b11e6758-c4c3-4830-a537-dca51a5c65ad	8216b6db-f68d-4279-8a03-dd8f8fd26c64
b11e6758-c4c3-4830-a537-dca51a5c65ad	b34ddbed-885f-40eb-8a43-26054e563e08
b11e6758-c4c3-4830-a537-dca51a5c65ad	11f16876-0f73-487a-859e-ce535e6afbd8
b11e6758-c4c3-4830-a537-dca51a5c65ad	d67cbcce-691c-4a94-832e-4bd4588c4cac
b11e6758-c4c3-4830-a537-dca51a5c65ad	7dd807ed-59ff-4597-8a83-b5fdb9a82c1f
b11e6758-c4c3-4830-a537-dca51a5c65ad	eeba6d65-f5fa-4a66-a800-a43e32f19740
b11e6758-c4c3-4830-a537-dca51a5c65ad	0005e94e-f367-4670-88e4-c98ae5cf5a3b
b11e6758-c4c3-4830-a537-dca51a5c65ad	ff9f7d3a-4ab7-46aa-9f0c-c0e62f9b7847
b11e6758-c4c3-4830-a537-dca51a5c65ad	2a92f917-2450-45e4-ba7d-58883f9861ce
b11e6758-c4c3-4830-a537-dca51a5c65ad	0212eaa7-1dfb-4ba3-93c3-dbb77254477e
b11e6758-c4c3-4830-a537-dca51a5c65ad	c342bc7d-8660-4a44-aab1-66828351715c
b11e6758-c4c3-4830-a537-dca51a5c65ad	42b59d48-9bee-4da0-bc7d-2d844ff1e028
b11e6758-c4c3-4830-a537-dca51a5c65ad	48345658-25c9-4eb6-bd31-584b082da591
b11e6758-c4c3-4830-a537-dca51a5c65ad	8223ff6e-c467-4864-8ccd-9645e68612c6
2ccf34b6-5260-46ac-9721-0bc72ae22fff	059f6d95-c5b8-456a-85d5-49a6fe88c9da
5d1d306e-b9a4-4ed1-a81b-486c29df9062	8223ff6e-c467-4864-8ccd-9645e68612c6
5d1d306e-b9a4-4ed1-a81b-486c29df9062	c342bc7d-8660-4a44-aab1-66828351715c
8216b6db-f68d-4279-8a03-dd8f8fd26c64	42b59d48-9bee-4da0-bc7d-2d844ff1e028
2ccf34b6-5260-46ac-9721-0bc72ae22fff	278430ae-a38e-4866-ae62-2f15c9ab6dc3
278430ae-a38e-4866-ae62-2f15c9ab6dc3	5cb2c5dc-2288-4a16-9a10-2e6ba28395ad
f0afe3a7-f46a-4ad9-ab14-59408a716a2f	7e32234a-91ed-4518-9b1c-6dbfd2340ae8
b11e6758-c4c3-4830-a537-dca51a5c65ad	82179503-110f-464b-9eee-64dcc8e73703
2ccf34b6-5260-46ac-9721-0bc72ae22fff	af78c9c5-4407-4758-b695-0c0ed9c48f7d
2ccf34b6-5260-46ac-9721-0bc72ae22fff	2a1fb157-3652-42a5-8367-5ce806810477
b11e6758-c4c3-4830-a537-dca51a5c65ad	99c44041-ab13-4da3-bbe8-6472b77cd69f
b11e6758-c4c3-4830-a537-dca51a5c65ad	8f766919-e328-4abc-bd9b-dad7d646ffb8
b11e6758-c4c3-4830-a537-dca51a5c65ad	0553ef1b-2199-49a3-8f6c-e17fd35e9091
b11e6758-c4c3-4830-a537-dca51a5c65ad	7b56de6c-9030-452f-9e79-ec642e71b387
b11e6758-c4c3-4830-a537-dca51a5c65ad	0e3f4912-92f1-459e-a091-ae227d0a9c1e
b11e6758-c4c3-4830-a537-dca51a5c65ad	0ee3d458-d424-47bb-a859-fad809a37bca
b11e6758-c4c3-4830-a537-dca51a5c65ad	4d5f8969-27c8-431f-9db9-a7faad11d8df
b11e6758-c4c3-4830-a537-dca51a5c65ad	fcd4d616-98a7-4c86-b257-9fc3b3d07bc9
b11e6758-c4c3-4830-a537-dca51a5c65ad	653cde7a-6f0f-472d-8b9e-c03905cba101
b11e6758-c4c3-4830-a537-dca51a5c65ad	e41bfb1d-0313-4571-a941-bebaf435592e
b11e6758-c4c3-4830-a537-dca51a5c65ad	4d242743-9695-44ee-9a16-d62806ec50ce
b11e6758-c4c3-4830-a537-dca51a5c65ad	c3beaa1f-1460-4958-afeb-6a422d2e1f5b
b11e6758-c4c3-4830-a537-dca51a5c65ad	f06578ac-d771-482f-95ad-fa91bfe52310
b11e6758-c4c3-4830-a537-dca51a5c65ad	8f7cf384-47a1-49ff-b315-38f7f1e2e2d4
b11e6758-c4c3-4830-a537-dca51a5c65ad	2cc2232d-2a4f-4616-853d-f8066c731fd2
b11e6758-c4c3-4830-a537-dca51a5c65ad	9aadb555-9811-491a-8088-e46ddf70c512
b11e6758-c4c3-4830-a537-dca51a5c65ad	0795878b-9c43-4235-a834-295058c72d24
0553ef1b-2199-49a3-8f6c-e17fd35e9091	8f7cf384-47a1-49ff-b315-38f7f1e2e2d4
0553ef1b-2199-49a3-8f6c-e17fd35e9091	0795878b-9c43-4235-a834-295058c72d24
7b56de6c-9030-452f-9e79-ec642e71b387	2cc2232d-2a4f-4616-853d-f8066c731fd2
93b1251d-4532-4968-ae6a-3c8490507d1e	22cac92a-f579-41c1-98f7-f4352b9d014c
93b1251d-4532-4968-ae6a-3c8490507d1e	cdfb805a-1e6d-49d8-849f-b363b2334d35
93b1251d-4532-4968-ae6a-3c8490507d1e	4a21e9d2-f338-4c91-8f09-c8af58fc9c4b
93b1251d-4532-4968-ae6a-3c8490507d1e	f9d11edf-7e34-4379-901e-0fee52b4daf5
93b1251d-4532-4968-ae6a-3c8490507d1e	42fabba5-ab58-45a4-a167-b94e8d0181bd
93b1251d-4532-4968-ae6a-3c8490507d1e	eaad16c2-de78-4064-80f0-5266974f9c0f
93b1251d-4532-4968-ae6a-3c8490507d1e	fd1a802d-5396-4d9d-8eb5-93db432229b5
93b1251d-4532-4968-ae6a-3c8490507d1e	1a0d37c4-aa5e-414a-b286-622707a65934
93b1251d-4532-4968-ae6a-3c8490507d1e	12e39b2c-e01b-46dd-8d38-3c9035dddcd2
93b1251d-4532-4968-ae6a-3c8490507d1e	f28fddce-4801-43d3-aef5-a120ba8ce349
93b1251d-4532-4968-ae6a-3c8490507d1e	e85d9fa1-8d79-4a26-a9ca-17d44abee976
93b1251d-4532-4968-ae6a-3c8490507d1e	19e46747-32ff-42f2-ab72-0ba58d2ce7af
93b1251d-4532-4968-ae6a-3c8490507d1e	8139629a-365c-43e8-952a-06173fdba1ba
93b1251d-4532-4968-ae6a-3c8490507d1e	395f7ebd-0ad4-40d1-8aa0-c05359ccce46
93b1251d-4532-4968-ae6a-3c8490507d1e	449429f3-cd47-4ef7-94de-7f6203a9f4e4
93b1251d-4532-4968-ae6a-3c8490507d1e	5e3e9e94-faa2-453f-892c-fe3340242990
93b1251d-4532-4968-ae6a-3c8490507d1e	fe4f49a1-ae39-4af5-972a-b0cb27346070
4a21e9d2-f338-4c91-8f09-c8af58fc9c4b	fe4f49a1-ae39-4af5-972a-b0cb27346070
4a21e9d2-f338-4c91-8f09-c8af58fc9c4b	395f7ebd-0ad4-40d1-8aa0-c05359ccce46
53d1d24b-be08-4619-8251-344248259fab	8eee6307-acfa-42fd-9fe1-3183c23f0dd3
f9d11edf-7e34-4379-901e-0fee52b4daf5	449429f3-cd47-4ef7-94de-7f6203a9f4e4
53d1d24b-be08-4619-8251-344248259fab	b443590c-6f71-4160-93d5-963dd078b4bc
b443590c-6f71-4160-93d5-963dd078b4bc	eeedfd35-9d82-46f8-ac23-ee5c47d9d505
5711edc2-8399-46fb-b05c-24e42e595a0e	ea7321ac-004f-492d-9ad5-8739238202e5
b11e6758-c4c3-4830-a537-dca51a5c65ad	42929287-a82d-4b3a-b78d-4d871d23b76d
93b1251d-4532-4968-ae6a-3c8490507d1e	61a6a39c-4eb3-4cbe-be2d-7b7f0564a723
53d1d24b-be08-4619-8251-344248259fab	73634ccd-4f2d-4dad-8065-ac2ea50f8589
53d1d24b-be08-4619-8251-344248259fab	50e0165d-707a-454d-a441-be65436ebf59
\.


--
-- Data for Name: credential; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.credential (id, salt, type, user_id, created_date, user_label, secret_data, credential_data, priority) FROM stdin;
ed691ec2-c620-4038-8734-4ae0a86eb28d	\N	password	aa3e0315-52b2-4fc2-88f1-07e02682f580	1708678773715	\N	{"value":"AmEFAx8cIJaDtlZZqvcIZC/50jMLkC2WESI3/SBWrY0=","salt":"8/WlMTg+3zp9esjiOi3f3g==","additionalParameters":{}}	{"hashIterations":27500,"algorithm":"pbkdf2-sha256","additionalParameters":{}}	10
\.


--
-- Data for Name: databasechangelog; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.databasechangelog (id, author, filename, dateexecuted, orderexecuted, exectype, md5sum, description, comments, tag, liquibase, contexts, labels, deployment_id) FROM stdin;
1.0.0.Final-KEYCLOAK-5461	sthorger@redhat.com	META-INF/jpa-changelog-1.0.0.Final.xml	2024-02-23 08:59:30.454616	1	EXECUTED	9:6f1016664e21e16d26517a4418f5e3df	createTable tableName=APPLICATION_DEFAULT_ROLES; createTable tableName=CLIENT; createTable tableName=CLIENT_SESSION; createTable tableName=CLIENT_SESSION_ROLE; createTable tableName=COMPOSITE_ROLE; createTable tableName=CREDENTIAL; createTable tab...		\N	4.23.2	\N	\N	8678769796
1.0.0.Final-KEYCLOAK-5461	sthorger@redhat.com	META-INF/db2-jpa-changelog-1.0.0.Final.xml	2024-02-23 08:59:30.490887	2	MARK_RAN	9:828775b1596a07d1200ba1d49e5e3941	createTable tableName=APPLICATION_DEFAULT_ROLES; createTable tableName=CLIENT; createTable tableName=CLIENT_SESSION; createTable tableName=CLIENT_SESSION_ROLE; createTable tableName=COMPOSITE_ROLE; createTable tableName=CREDENTIAL; createTable tab...		\N	4.23.2	\N	\N	8678769796
1.1.0.Beta1	sthorger@redhat.com	META-INF/jpa-changelog-1.1.0.Beta1.xml	2024-02-23 08:59:30.518516	3	EXECUTED	9:5f090e44a7d595883c1fb61f4b41fd38	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION; createTable tableName=CLIENT_ATTRIBUTES; createTable tableName=CLIENT_SESSION_NOTE; createTable tableName=APP_NODE_REGISTRATIONS; addColumn table...		\N	4.23.2	\N	\N	8678769796
1.1.0.Final	sthorger@redhat.com	META-INF/jpa-changelog-1.1.0.Final.xml	2024-02-23 08:59:30.521305	4	EXECUTED	9:c07e577387a3d2c04d1adc9aaad8730e	renameColumn newColumnName=EVENT_TIME, oldColumnName=TIME, tableName=EVENT_ENTITY		\N	4.23.2	\N	\N	8678769796
1.2.0.Beta1	psilva@redhat.com	META-INF/jpa-changelog-1.2.0.Beta1.xml	2024-02-23 08:59:30.59225	5	EXECUTED	9:b68ce996c655922dbcd2fe6b6ae72686	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION; createTable tableName=PROTOCOL_MAPPER; createTable tableName=PROTOCOL_MAPPER_CONFIG; createTable tableName=...		\N	4.23.2	\N	\N	8678769796
1.2.0.Beta1	psilva@redhat.com	META-INF/db2-jpa-changelog-1.2.0.Beta1.xml	2024-02-23 08:59:30.606474	6	MARK_RAN	9:543b5c9989f024fe35c6f6c5a97de88e	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION; createTable tableName=PROTOCOL_MAPPER; createTable tableName=PROTOCOL_MAPPER_CONFIG; createTable tableName=...		\N	4.23.2	\N	\N	8678769796
1.2.0.RC1	bburke@redhat.com	META-INF/jpa-changelog-1.2.0.CR1.xml	2024-02-23 08:59:30.672003	7	EXECUTED	9:765afebbe21cf5bbca048e632df38336	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete tableName=USER_SESSION; createTable tableName=MIGRATION_MODEL; createTable tableName=IDENTITY_P...		\N	4.23.2	\N	\N	8678769796
1.2.0.RC1	bburke@redhat.com	META-INF/db2-jpa-changelog-1.2.0.CR1.xml	2024-02-23 08:59:30.74669	8	MARK_RAN	9:db4a145ba11a6fdaefb397f6dbf829a1	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete tableName=USER_SESSION; createTable tableName=MIGRATION_MODEL; createTable tableName=IDENTITY_P...		\N	4.23.2	\N	\N	8678769796
1.2.0.Final	keycloak	META-INF/jpa-changelog-1.2.0.Final.xml	2024-02-23 08:59:30.752847	9	EXECUTED	9:9d05c7be10cdb873f8bcb41bc3a8ab23	update tableName=CLIENT; update tableName=CLIENT; update tableName=CLIENT		\N	4.23.2	\N	\N	8678769796
1.3.0	bburke@redhat.com	META-INF/jpa-changelog-1.3.0.xml	2024-02-23 08:59:30.806845	10	EXECUTED	9:18593702353128d53111f9b1ff0b82b8	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete tableName=USER_SESSION; createTable tableName=ADMI...		\N	4.23.2	\N	\N	8678769796
1.4.0	bburke@redhat.com	META-INF/jpa-changelog-1.4.0.xml	2024-02-23 08:59:30.863552	11	EXECUTED	9:6122efe5f090e41a85c0f1c9e52cbb62	delete tableName=CLIENT_SESSION_AUTH_STATUS; delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete table...		\N	4.23.2	\N	\N	8678769796
1.4.0	bburke@redhat.com	META-INF/db2-jpa-changelog-1.4.0.xml	2024-02-23 08:59:30.87644	12	MARK_RAN	9:e1ff28bf7568451453f844c5d54bb0b5	delete tableName=CLIENT_SESSION_AUTH_STATUS; delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete table...		\N	4.23.2	\N	\N	8678769796
1.5.0	bburke@redhat.com	META-INF/jpa-changelog-1.5.0.xml	2024-02-23 08:59:30.894501	13	EXECUTED	9:7af32cd8957fbc069f796b61217483fd	delete tableName=CLIENT_SESSION_AUTH_STATUS; delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete table...		\N	4.23.2	\N	\N	8678769796
1.6.1_from15	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2024-02-23 08:59:30.911592	14	EXECUTED	9:6005e15e84714cd83226bf7879f54190	addColumn tableName=REALM; addColumn tableName=KEYCLOAK_ROLE; addColumn tableName=CLIENT; createTable tableName=OFFLINE_USER_SESSION; createTable tableName=OFFLINE_CLIENT_SESSION; addPrimaryKey constraintName=CONSTRAINT_OFFL_US_SES_PK2, tableName=...		\N	4.23.2	\N	\N	8678769796
1.6.1_from16-pre	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2024-02-23 08:59:30.913563	15	MARK_RAN	9:bf656f5a2b055d07f314431cae76f06c	delete tableName=OFFLINE_CLIENT_SESSION; delete tableName=OFFLINE_USER_SESSION		\N	4.23.2	\N	\N	8678769796
1.6.1_from16	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2024-02-23 08:59:30.917792	16	MARK_RAN	9:f8dadc9284440469dcf71e25ca6ab99b	dropPrimaryKey constraintName=CONSTRAINT_OFFLINE_US_SES_PK, tableName=OFFLINE_USER_SESSION; dropPrimaryKey constraintName=CONSTRAINT_OFFLINE_CL_SES_PK, tableName=OFFLINE_CLIENT_SESSION; addColumn tableName=OFFLINE_USER_SESSION; update tableName=OF...		\N	4.23.2	\N	\N	8678769796
1.6.1	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2024-02-23 08:59:30.928813	17	EXECUTED	9:d41d8cd98f00b204e9800998ecf8427e	empty		\N	4.23.2	\N	\N	8678769796
1.7.0	bburke@redhat.com	META-INF/jpa-changelog-1.7.0.xml	2024-02-23 08:59:30.966001	18	EXECUTED	9:3368ff0be4c2855ee2dd9ca813b38d8e	createTable tableName=KEYCLOAK_GROUP; createTable tableName=GROUP_ROLE_MAPPING; createTable tableName=GROUP_ATTRIBUTE; createTable tableName=USER_GROUP_MEMBERSHIP; createTable tableName=REALM_DEFAULT_GROUPS; addColumn tableName=IDENTITY_PROVIDER; ...		\N	4.23.2	\N	\N	8678769796
1.8.0	mposolda@redhat.com	META-INF/jpa-changelog-1.8.0.xml	2024-02-23 08:59:31.015515	19	EXECUTED	9:8ac2fb5dd030b24c0570a763ed75ed20	addColumn tableName=IDENTITY_PROVIDER; createTable tableName=CLIENT_TEMPLATE; createTable tableName=CLIENT_TEMPLATE_ATTRIBUTES; createTable tableName=TEMPLATE_SCOPE_MAPPING; dropNotNullConstraint columnName=CLIENT_ID, tableName=PROTOCOL_MAPPER; ad...		\N	4.23.2	\N	\N	8678769796
1.8.0-2	keycloak	META-INF/jpa-changelog-1.8.0.xml	2024-02-23 08:59:31.020219	20	EXECUTED	9:f91ddca9b19743db60e3057679810e6c	dropDefaultValue columnName=ALGORITHM, tableName=CREDENTIAL; update tableName=CREDENTIAL		\N	4.23.2	\N	\N	8678769796
1.8.0	mposolda@redhat.com	META-INF/db2-jpa-changelog-1.8.0.xml	2024-02-23 08:59:31.031961	21	MARK_RAN	9:831e82914316dc8a57dc09d755f23c51	addColumn tableName=IDENTITY_PROVIDER; createTable tableName=CLIENT_TEMPLATE; createTable tableName=CLIENT_TEMPLATE_ATTRIBUTES; createTable tableName=TEMPLATE_SCOPE_MAPPING; dropNotNullConstraint columnName=CLIENT_ID, tableName=PROTOCOL_MAPPER; ad...		\N	4.23.2	\N	\N	8678769796
1.8.0-2	keycloak	META-INF/db2-jpa-changelog-1.8.0.xml	2024-02-23 08:59:31.035943	22	MARK_RAN	9:f91ddca9b19743db60e3057679810e6c	dropDefaultValue columnName=ALGORITHM, tableName=CREDENTIAL; update tableName=CREDENTIAL		\N	4.23.2	\N	\N	8678769796
1.9.0	mposolda@redhat.com	META-INF/jpa-changelog-1.9.0.xml	2024-02-23 08:59:31.051742	23	EXECUTED	9:bc3d0f9e823a69dc21e23e94c7a94bb1	update tableName=REALM; update tableName=REALM; update tableName=REALM; update tableName=REALM; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=REALM; update tableName=REALM; customChange; dr...		\N	4.23.2	\N	\N	8678769796
1.9.1	keycloak	META-INF/jpa-changelog-1.9.1.xml	2024-02-23 08:59:31.056338	24	EXECUTED	9:c9999da42f543575ab790e76439a2679	modifyDataType columnName=PRIVATE_KEY, tableName=REALM; modifyDataType columnName=PUBLIC_KEY, tableName=REALM; modifyDataType columnName=CERTIFICATE, tableName=REALM		\N	4.23.2	\N	\N	8678769796
1.9.1	keycloak	META-INF/db2-jpa-changelog-1.9.1.xml	2024-02-23 08:59:31.058258	25	MARK_RAN	9:0d6c65c6f58732d81569e77b10ba301d	modifyDataType columnName=PRIVATE_KEY, tableName=REALM; modifyDataType columnName=CERTIFICATE, tableName=REALM		\N	4.23.2	\N	\N	8678769796
1.9.2	keycloak	META-INF/jpa-changelog-1.9.2.xml	2024-02-23 08:59:31.161784	26	EXECUTED	9:fc576660fc016ae53d2d4778d84d86d0	createIndex indexName=IDX_USER_EMAIL, tableName=USER_ENTITY; createIndex indexName=IDX_USER_ROLE_MAPPING, tableName=USER_ROLE_MAPPING; createIndex indexName=IDX_USER_GROUP_MAPPING, tableName=USER_GROUP_MEMBERSHIP; createIndex indexName=IDX_USER_CO...		\N	4.23.2	\N	\N	8678769796
authz-2.0.0	psilva@redhat.com	META-INF/jpa-changelog-authz-2.0.0.xml	2024-02-23 08:59:31.209776	27	EXECUTED	9:43ed6b0da89ff77206289e87eaa9c024	createTable tableName=RESOURCE_SERVER; addPrimaryKey constraintName=CONSTRAINT_FARS, tableName=RESOURCE_SERVER; addUniqueConstraint constraintName=UK_AU8TT6T700S9V50BU18WS5HA6, tableName=RESOURCE_SERVER; createTable tableName=RESOURCE_SERVER_RESOU...		\N	4.23.2	\N	\N	8678769796
authz-2.5.1	psilva@redhat.com	META-INF/jpa-changelog-authz-2.5.1.xml	2024-02-23 08:59:31.212982	28	EXECUTED	9:44bae577f551b3738740281eceb4ea70	update tableName=RESOURCE_SERVER_POLICY		\N	4.23.2	\N	\N	8678769796
2.1.0-KEYCLOAK-5461	bburke@redhat.com	META-INF/jpa-changelog-2.1.0.xml	2024-02-23 08:59:31.247718	29	EXECUTED	9:bd88e1f833df0420b01e114533aee5e8	createTable tableName=BROKER_LINK; createTable tableName=FED_USER_ATTRIBUTE; createTable tableName=FED_USER_CONSENT; createTable tableName=FED_USER_CONSENT_ROLE; createTable tableName=FED_USER_CONSENT_PROT_MAPPER; createTable tableName=FED_USER_CR...		\N	4.23.2	\N	\N	8678769796
2.2.0	bburke@redhat.com	META-INF/jpa-changelog-2.2.0.xml	2024-02-23 08:59:31.257925	30	EXECUTED	9:a7022af5267f019d020edfe316ef4371	addColumn tableName=ADMIN_EVENT_ENTITY; createTable tableName=CREDENTIAL_ATTRIBUTE; createTable tableName=FED_CREDENTIAL_ATTRIBUTE; modifyDataType columnName=VALUE, tableName=CREDENTIAL; addForeignKeyConstraint baseTableName=FED_CREDENTIAL_ATTRIBU...		\N	4.23.2	\N	\N	8678769796
2.3.0	bburke@redhat.com	META-INF/jpa-changelog-2.3.0.xml	2024-02-23 08:59:31.271904	31	EXECUTED	9:fc155c394040654d6a79227e56f5e25a	createTable tableName=FEDERATED_USER; addPrimaryKey constraintName=CONSTR_FEDERATED_USER, tableName=FEDERATED_USER; dropDefaultValue columnName=TOTP, tableName=USER_ENTITY; dropColumn columnName=TOTP, tableName=USER_ENTITY; addColumn tableName=IDE...		\N	4.23.2	\N	\N	8678769796
2.4.0	bburke@redhat.com	META-INF/jpa-changelog-2.4.0.xml	2024-02-23 08:59:31.275624	32	EXECUTED	9:eac4ffb2a14795e5dc7b426063e54d88	customChange		\N	4.23.2	\N	\N	8678769796
2.5.0	bburke@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2024-02-23 08:59:31.279357	33	EXECUTED	9:54937c05672568c4c64fc9524c1e9462	customChange; modifyDataType columnName=USER_ID, tableName=OFFLINE_USER_SESSION		\N	4.23.2	\N	\N	8678769796
2.5.0-unicode-oracle	hmlnarik@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2024-02-23 08:59:31.28208	34	MARK_RAN	9:3a32bace77c84d7678d035a7f5a8084e	modifyDataType columnName=DESCRIPTION, tableName=AUTHENTICATION_FLOW; modifyDataType columnName=DESCRIPTION, tableName=CLIENT_TEMPLATE; modifyDataType columnName=DESCRIPTION, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=DESCRIPTION,...		\N	4.23.2	\N	\N	8678769796
2.5.0-unicode-other-dbs	hmlnarik@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2024-02-23 08:59:31.303201	35	EXECUTED	9:33d72168746f81f98ae3a1e8e0ca3554	modifyDataType columnName=DESCRIPTION, tableName=AUTHENTICATION_FLOW; modifyDataType columnName=DESCRIPTION, tableName=CLIENT_TEMPLATE; modifyDataType columnName=DESCRIPTION, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=DESCRIPTION,...		\N	4.23.2	\N	\N	8678769796
2.5.0-duplicate-email-support	slawomir@dabek.name	META-INF/jpa-changelog-2.5.0.xml	2024-02-23 08:59:31.3067	36	EXECUTED	9:61b6d3d7a4c0e0024b0c839da283da0c	addColumn tableName=REALM		\N	4.23.2	\N	\N	8678769796
2.5.0-unique-group-names	hmlnarik@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2024-02-23 08:59:31.31056	37	EXECUTED	9:8dcac7bdf7378e7d823cdfddebf72fda	addUniqueConstraint constraintName=SIBLING_NAMES, tableName=KEYCLOAK_GROUP		\N	4.23.2	\N	\N	8678769796
2.5.1	bburke@redhat.com	META-INF/jpa-changelog-2.5.1.xml	2024-02-23 08:59:31.313192	38	EXECUTED	9:a2b870802540cb3faa72098db5388af3	addColumn tableName=FED_USER_CONSENT		\N	4.23.2	\N	\N	8678769796
3.0.0	bburke@redhat.com	META-INF/jpa-changelog-3.0.0.xml	2024-02-23 08:59:31.315621	39	EXECUTED	9:132a67499ba24bcc54fb5cbdcfe7e4c0	addColumn tableName=IDENTITY_PROVIDER		\N	4.23.2	\N	\N	8678769796
3.2.0-fix	keycloak	META-INF/jpa-changelog-3.2.0.xml	2024-02-23 08:59:31.316793	40	MARK_RAN	9:938f894c032f5430f2b0fafb1a243462	addNotNullConstraint columnName=REALM_ID, tableName=CLIENT_INITIAL_ACCESS		\N	4.23.2	\N	\N	8678769796
3.2.0-fix-with-keycloak-5416	keycloak	META-INF/jpa-changelog-3.2.0.xml	2024-02-23 08:59:31.318629	41	MARK_RAN	9:845c332ff1874dc5d35974b0babf3006	dropIndex indexName=IDX_CLIENT_INIT_ACC_REALM, tableName=CLIENT_INITIAL_ACCESS; addNotNullConstraint columnName=REALM_ID, tableName=CLIENT_INITIAL_ACCESS; createIndex indexName=IDX_CLIENT_INIT_ACC_REALM, tableName=CLIENT_INITIAL_ACCESS		\N	4.23.2	\N	\N	8678769796
3.2.0-fix-offline-sessions	hmlnarik	META-INF/jpa-changelog-3.2.0.xml	2024-02-23 08:59:31.322178	42	EXECUTED	9:fc86359c079781adc577c5a217e4d04c	customChange		\N	4.23.2	\N	\N	8678769796
3.2.0-fixed	keycloak	META-INF/jpa-changelog-3.2.0.xml	2024-02-23 08:59:31.390906	43	EXECUTED	9:59a64800e3c0d09b825f8a3b444fa8f4	addColumn tableName=REALM; dropPrimaryKey constraintName=CONSTRAINT_OFFL_CL_SES_PK2, tableName=OFFLINE_CLIENT_SESSION; dropColumn columnName=CLIENT_SESSION_ID, tableName=OFFLINE_CLIENT_SESSION; addPrimaryKey constraintName=CONSTRAINT_OFFL_CL_SES_P...		\N	4.23.2	\N	\N	8678769796
3.3.0	keycloak	META-INF/jpa-changelog-3.3.0.xml	2024-02-23 08:59:31.394801	44	EXECUTED	9:d48d6da5c6ccf667807f633fe489ce88	addColumn tableName=USER_ENTITY		\N	4.23.2	\N	\N	8678769796
authz-3.4.0.CR1-resource-server-pk-change-part1	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2024-02-23 08:59:31.397412	45	EXECUTED	9:dde36f7973e80d71fceee683bc5d2951	addColumn tableName=RESOURCE_SERVER_POLICY; addColumn tableName=RESOURCE_SERVER_RESOURCE; addColumn tableName=RESOURCE_SERVER_SCOPE		\N	4.23.2	\N	\N	8678769796
authz-3.4.0.CR1-resource-server-pk-change-part2-KEYCLOAK-6095	hmlnarik@redhat.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2024-02-23 08:59:31.400225	46	EXECUTED	9:b855e9b0a406b34fa323235a0cf4f640	customChange		\N	4.23.2	\N	\N	8678769796
authz-3.4.0.CR1-resource-server-pk-change-part3-fixed	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2024-02-23 08:59:31.40128	47	MARK_RAN	9:51abbacd7b416c50c4421a8cabf7927e	dropIndex indexName=IDX_RES_SERV_POL_RES_SERV, tableName=RESOURCE_SERVER_POLICY; dropIndex indexName=IDX_RES_SRV_RES_RES_SRV, tableName=RESOURCE_SERVER_RESOURCE; dropIndex indexName=IDX_RES_SRV_SCOPE_RES_SRV, tableName=RESOURCE_SERVER_SCOPE		\N	4.23.2	\N	\N	8678769796
authz-3.4.0.CR1-resource-server-pk-change-part3-fixed-nodropindex	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2024-02-23 08:59:31.422717	48	EXECUTED	9:bdc99e567b3398bac83263d375aad143	addNotNullConstraint columnName=RESOURCE_SERVER_CLIENT_ID, tableName=RESOURCE_SERVER_POLICY; addNotNullConstraint columnName=RESOURCE_SERVER_CLIENT_ID, tableName=RESOURCE_SERVER_RESOURCE; addNotNullConstraint columnName=RESOURCE_SERVER_CLIENT_ID, ...		\N	4.23.2	\N	\N	8678769796
authn-3.4.0.CR1-refresh-token-max-reuse	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2024-02-23 08:59:31.425362	49	EXECUTED	9:d198654156881c46bfba39abd7769e69	addColumn tableName=REALM		\N	4.23.2	\N	\N	8678769796
3.4.0	keycloak	META-INF/jpa-changelog-3.4.0.xml	2024-02-23 08:59:31.445697	50	EXECUTED	9:cfdd8736332ccdd72c5256ccb42335db	addPrimaryKey constraintName=CONSTRAINT_REALM_DEFAULT_ROLES, tableName=REALM_DEFAULT_ROLES; addPrimaryKey constraintName=CONSTRAINT_COMPOSITE_ROLE, tableName=COMPOSITE_ROLE; addPrimaryKey constraintName=CONSTR_REALM_DEFAULT_GROUPS, tableName=REALM...		\N	4.23.2	\N	\N	8678769796
3.4.0-KEYCLOAK-5230	hmlnarik@redhat.com	META-INF/jpa-changelog-3.4.0.xml	2024-02-23 08:59:31.460279	51	EXECUTED	9:7c84de3d9bd84d7f077607c1a4dcb714	createIndex indexName=IDX_FU_ATTRIBUTE, tableName=FED_USER_ATTRIBUTE; createIndex indexName=IDX_FU_CONSENT, tableName=FED_USER_CONSENT; createIndex indexName=IDX_FU_CONSENT_RU, tableName=FED_USER_CONSENT; createIndex indexName=IDX_FU_CREDENTIAL, t...		\N	4.23.2	\N	\N	8678769796
3.4.1	psilva@redhat.com	META-INF/jpa-changelog-3.4.1.xml	2024-02-23 08:59:31.462212	52	EXECUTED	9:5a6bb36cbefb6a9d6928452c0852af2d	modifyDataType columnName=VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.23.2	\N	\N	8678769796
3.4.2	keycloak	META-INF/jpa-changelog-3.4.2.xml	2024-02-23 08:59:31.463847	53	EXECUTED	9:8f23e334dbc59f82e0a328373ca6ced0	update tableName=REALM		\N	4.23.2	\N	\N	8678769796
3.4.2-KEYCLOAK-5172	mkanis@redhat.com	META-INF/jpa-changelog-3.4.2.xml	2024-02-23 08:59:31.465334	54	EXECUTED	9:9156214268f09d970cdf0e1564d866af	update tableName=CLIENT		\N	4.23.2	\N	\N	8678769796
4.0.0-KEYCLOAK-6335	bburke@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2024-02-23 08:59:31.468793	55	EXECUTED	9:db806613b1ed154826c02610b7dbdf74	createTable tableName=CLIENT_AUTH_FLOW_BINDINGS; addPrimaryKey constraintName=C_CLI_FLOW_BIND, tableName=CLIENT_AUTH_FLOW_BINDINGS		\N	4.23.2	\N	\N	8678769796
4.0.0-CLEANUP-UNUSED-TABLE	bburke@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2024-02-23 08:59:31.471303	56	EXECUTED	9:229a041fb72d5beac76bb94a5fa709de	dropTable tableName=CLIENT_IDENTITY_PROV_MAPPING		\N	4.23.2	\N	\N	8678769796
4.0.0-KEYCLOAK-6228	bburke@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2024-02-23 08:59:31.482449	57	EXECUTED	9:079899dade9c1e683f26b2aa9ca6ff04	dropUniqueConstraint constraintName=UK_JKUWUVD56ONTGSUHOGM8UEWRT, tableName=USER_CONSENT; dropNotNullConstraint columnName=CLIENT_ID, tableName=USER_CONSENT; addColumn tableName=USER_CONSENT; addUniqueConstraint constraintName=UK_JKUWUVD56ONTGSUHO...		\N	4.23.2	\N	\N	8678769796
4.0.0-KEYCLOAK-5579-fixed	mposolda@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2024-02-23 08:59:31.534662	58	EXECUTED	9:139b79bcbbfe903bb1c2d2a4dbf001d9	dropForeignKeyConstraint baseTableName=CLIENT_TEMPLATE_ATTRIBUTES, constraintName=FK_CL_TEMPL_ATTR_TEMPL; renameTable newTableName=CLIENT_SCOPE_ATTRIBUTES, oldTableName=CLIENT_TEMPLATE_ATTRIBUTES; renameColumn newColumnName=SCOPE_ID, oldColumnName...		\N	4.23.2	\N	\N	8678769796
authz-4.0.0.CR1	psilva@redhat.com	META-INF/jpa-changelog-authz-4.0.0.CR1.xml	2024-02-23 08:59:31.550753	59	EXECUTED	9:b55738ad889860c625ba2bf483495a04	createTable tableName=RESOURCE_SERVER_PERM_TICKET; addPrimaryKey constraintName=CONSTRAINT_FAPMT, tableName=RESOURCE_SERVER_PERM_TICKET; addForeignKeyConstraint baseTableName=RESOURCE_SERVER_PERM_TICKET, constraintName=FK_FRSRHO213XCX4WNKOG82SSPMT...		\N	4.23.2	\N	\N	8678769796
authz-4.0.0.Beta3	psilva@redhat.com	META-INF/jpa-changelog-authz-4.0.0.Beta3.xml	2024-02-23 08:59:31.554583	60	EXECUTED	9:e0057eac39aa8fc8e09ac6cfa4ae15fe	addColumn tableName=RESOURCE_SERVER_POLICY; addColumn tableName=RESOURCE_SERVER_PERM_TICKET; addForeignKeyConstraint baseTableName=RESOURCE_SERVER_PERM_TICKET, constraintName=FK_FRSRPO2128CX4WNKOG82SSRFY, referencedTableName=RESOURCE_SERVER_POLICY		\N	4.23.2	\N	\N	8678769796
authz-4.2.0.Final	mhajas@redhat.com	META-INF/jpa-changelog-authz-4.2.0.Final.xml	2024-02-23 08:59:31.560073	61	EXECUTED	9:42a33806f3a0443fe0e7feeec821326c	createTable tableName=RESOURCE_URIS; addForeignKeyConstraint baseTableName=RESOURCE_URIS, constraintName=FK_RESOURCE_SERVER_URIS, referencedTableName=RESOURCE_SERVER_RESOURCE; customChange; dropColumn columnName=URI, tableName=RESOURCE_SERVER_RESO...		\N	4.23.2	\N	\N	8678769796
authz-4.2.0.Final-KEYCLOAK-9944	hmlnarik@redhat.com	META-INF/jpa-changelog-authz-4.2.0.Final.xml	2024-02-23 08:59:31.563433	62	EXECUTED	9:9968206fca46eecc1f51db9c024bfe56	addPrimaryKey constraintName=CONSTRAINT_RESOUR_URIS_PK, tableName=RESOURCE_URIS		\N	4.23.2	\N	\N	8678769796
4.2.0-KEYCLOAK-6313	wadahiro@gmail.com	META-INF/jpa-changelog-4.2.0.xml	2024-02-23 08:59:31.565326	63	EXECUTED	9:92143a6daea0a3f3b8f598c97ce55c3d	addColumn tableName=REQUIRED_ACTION_PROVIDER		\N	4.23.2	\N	\N	8678769796
4.3.0-KEYCLOAK-7984	wadahiro@gmail.com	META-INF/jpa-changelog-4.3.0.xml	2024-02-23 08:59:31.566796	64	EXECUTED	9:82bab26a27195d889fb0429003b18f40	update tableName=REQUIRED_ACTION_PROVIDER		\N	4.23.2	\N	\N	8678769796
4.6.0-KEYCLOAK-7950	psilva@redhat.com	META-INF/jpa-changelog-4.6.0.xml	2024-02-23 08:59:31.568301	65	EXECUTED	9:e590c88ddc0b38b0ae4249bbfcb5abc3	update tableName=RESOURCE_SERVER_RESOURCE		\N	4.23.2	\N	\N	8678769796
4.6.0-KEYCLOAK-8377	keycloak	META-INF/jpa-changelog-4.6.0.xml	2024-02-23 08:59:31.577156	66	EXECUTED	9:5c1f475536118dbdc38d5d7977950cc0	createTable tableName=ROLE_ATTRIBUTE; addPrimaryKey constraintName=CONSTRAINT_ROLE_ATTRIBUTE_PK, tableName=ROLE_ATTRIBUTE; addForeignKeyConstraint baseTableName=ROLE_ATTRIBUTE, constraintName=FK_ROLE_ATTRIBUTE_ID, referencedTableName=KEYCLOAK_ROLE...		\N	4.23.2	\N	\N	8678769796
4.6.0-KEYCLOAK-8555	gideonray@gmail.com	META-INF/jpa-changelog-4.6.0.xml	2024-02-23 08:59:31.586347	67	EXECUTED	9:e7c9f5f9c4d67ccbbcc215440c718a17	createIndex indexName=IDX_COMPONENT_PROVIDER_TYPE, tableName=COMPONENT		\N	4.23.2	\N	\N	8678769796
4.7.0-KEYCLOAK-1267	sguilhen@redhat.com	META-INF/jpa-changelog-4.7.0.xml	2024-02-23 08:59:31.59446	68	EXECUTED	9:88e0bfdda924690d6f4e430c53447dd5	addColumn tableName=REALM		\N	4.23.2	\N	\N	8678769796
4.7.0-KEYCLOAK-7275	keycloak	META-INF/jpa-changelog-4.7.0.xml	2024-02-23 08:59:31.600079	69	EXECUTED	9:f53177f137e1c46b6a88c59ec1cb5218	renameColumn newColumnName=CREATED_ON, oldColumnName=LAST_SESSION_REFRESH, tableName=OFFLINE_USER_SESSION; addNotNullConstraint columnName=CREATED_ON, tableName=OFFLINE_USER_SESSION; addColumn tableName=OFFLINE_USER_SESSION; customChange; createIn...		\N	4.23.2	\N	\N	8678769796
4.8.0-KEYCLOAK-8835	sguilhen@redhat.com	META-INF/jpa-changelog-4.8.0.xml	2024-02-23 08:59:31.60261	70	EXECUTED	9:a74d33da4dc42a37ec27121580d1459f	addNotNullConstraint columnName=SSO_MAX_LIFESPAN_REMEMBER_ME, tableName=REALM; addNotNullConstraint columnName=SSO_IDLE_TIMEOUT_REMEMBER_ME, tableName=REALM		\N	4.23.2	\N	\N	8678769796
authz-7.0.0-KEYCLOAK-10443	psilva@redhat.com	META-INF/jpa-changelog-authz-7.0.0.xml	2024-02-23 08:59:31.604713	71	EXECUTED	9:fd4ade7b90c3b67fae0bfcfcb42dfb5f	addColumn tableName=RESOURCE_SERVER		\N	4.23.2	\N	\N	8678769796
8.0.0-adding-credential-columns	keycloak	META-INF/jpa-changelog-8.0.0.xml	2024-02-23 08:59:31.607438	72	EXECUTED	9:aa072ad090bbba210d8f18781b8cebf4	addColumn tableName=CREDENTIAL; addColumn tableName=FED_USER_CREDENTIAL		\N	4.23.2	\N	\N	8678769796
8.0.0-updating-credential-data-not-oracle-fixed	keycloak	META-INF/jpa-changelog-8.0.0.xml	2024-02-23 08:59:31.610617	73	EXECUTED	9:1ae6be29bab7c2aa376f6983b932be37	update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL		\N	4.23.2	\N	\N	8678769796
8.0.0-updating-credential-data-oracle-fixed	keycloak	META-INF/jpa-changelog-8.0.0.xml	2024-02-23 08:59:31.612033	74	MARK_RAN	9:14706f286953fc9a25286dbd8fb30d97	update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL		\N	4.23.2	\N	\N	8678769796
8.0.0-credential-cleanup-fixed	keycloak	META-INF/jpa-changelog-8.0.0.xml	2024-02-23 08:59:31.620934	75	EXECUTED	9:2b9cc12779be32c5b40e2e67711a218b	dropDefaultValue columnName=COUNTER, tableName=CREDENTIAL; dropDefaultValue columnName=DIGITS, tableName=CREDENTIAL; dropDefaultValue columnName=PERIOD, tableName=CREDENTIAL; dropDefaultValue columnName=ALGORITHM, tableName=CREDENTIAL; dropColumn ...		\N	4.23.2	\N	\N	8678769796
8.0.0-resource-tag-support	keycloak	META-INF/jpa-changelog-8.0.0.xml	2024-02-23 08:59:31.624766	76	EXECUTED	9:91fa186ce7a5af127a2d7a91ee083cc5	addColumn tableName=MIGRATION_MODEL; createIndex indexName=IDX_UPDATE_TIME, tableName=MIGRATION_MODEL		\N	4.23.2	\N	\N	8678769796
9.0.0-always-display-client	keycloak	META-INF/jpa-changelog-9.0.0.xml	2024-02-23 08:59:31.626809	77	EXECUTED	9:6335e5c94e83a2639ccd68dd24e2e5ad	addColumn tableName=CLIENT		\N	4.23.2	\N	\N	8678769796
9.0.0-drop-constraints-for-column-increase	keycloak	META-INF/jpa-changelog-9.0.0.xml	2024-02-23 08:59:31.627972	78	MARK_RAN	9:6bdb5658951e028bfe16fa0a8228b530	dropUniqueConstraint constraintName=UK_FRSR6T700S9V50BU18WS5PMT, tableName=RESOURCE_SERVER_PERM_TICKET; dropUniqueConstraint constraintName=UK_FRSR6T700S9V50BU18WS5HA6, tableName=RESOURCE_SERVER_RESOURCE; dropPrimaryKey constraintName=CONSTRAINT_O...		\N	4.23.2	\N	\N	8678769796
9.0.0-increase-column-size-federated-fk	keycloak	META-INF/jpa-changelog-9.0.0.xml	2024-02-23 08:59:31.638711	79	EXECUTED	9:d5bc15a64117ccad481ce8792d4c608f	modifyDataType columnName=CLIENT_ID, tableName=FED_USER_CONSENT; modifyDataType columnName=CLIENT_REALM_CONSTRAINT, tableName=KEYCLOAK_ROLE; modifyDataType columnName=OWNER, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=CLIENT_ID, ta...		\N	4.23.2	\N	\N	8678769796
9.0.0-recreate-constraints-after-column-increase	keycloak	META-INF/jpa-changelog-9.0.0.xml	2024-02-23 08:59:31.64148	80	MARK_RAN	9:077cba51999515f4d3e7ad5619ab592c	addNotNullConstraint columnName=CLIENT_ID, tableName=OFFLINE_CLIENT_SESSION; addNotNullConstraint columnName=OWNER, tableName=RESOURCE_SERVER_PERM_TICKET; addNotNullConstraint columnName=REQUESTER, tableName=RESOURCE_SERVER_PERM_TICKET; addNotNull...		\N	4.23.2	\N	\N	8678769796
9.0.1-add-index-to-client.client_id	keycloak	META-INF/jpa-changelog-9.0.1.xml	2024-02-23 08:59:31.645185	81	EXECUTED	9:be969f08a163bf47c6b9e9ead8ac2afb	createIndex indexName=IDX_CLIENT_ID, tableName=CLIENT		\N	4.23.2	\N	\N	8678769796
9.0.1-KEYCLOAK-12579-drop-constraints	keycloak	META-INF/jpa-changelog-9.0.1.xml	2024-02-23 08:59:31.646169	82	MARK_RAN	9:6d3bb4408ba5a72f39bd8a0b301ec6e3	dropUniqueConstraint constraintName=SIBLING_NAMES, tableName=KEYCLOAK_GROUP		\N	4.23.2	\N	\N	8678769796
9.0.1-KEYCLOAK-12579-add-not-null-constraint	keycloak	META-INF/jpa-changelog-9.0.1.xml	2024-02-23 08:59:31.649424	83	EXECUTED	9:966bda61e46bebf3cc39518fbed52fa7	addNotNullConstraint columnName=PARENT_GROUP, tableName=KEYCLOAK_GROUP		\N	4.23.2	\N	\N	8678769796
9.0.1-KEYCLOAK-12579-recreate-constraints	keycloak	META-INF/jpa-changelog-9.0.1.xml	2024-02-23 08:59:31.651557	84	MARK_RAN	9:8dcac7bdf7378e7d823cdfddebf72fda	addUniqueConstraint constraintName=SIBLING_NAMES, tableName=KEYCLOAK_GROUP		\N	4.23.2	\N	\N	8678769796
9.0.1-add-index-to-events	keycloak	META-INF/jpa-changelog-9.0.1.xml	2024-02-23 08:59:31.655663	85	EXECUTED	9:7d93d602352a30c0c317e6a609b56599	createIndex indexName=IDX_EVENT_TIME, tableName=EVENT_ENTITY		\N	4.23.2	\N	\N	8678769796
map-remove-ri	keycloak	META-INF/jpa-changelog-11.0.0.xml	2024-02-23 08:59:31.658635	86	EXECUTED	9:71c5969e6cdd8d7b6f47cebc86d37627	dropForeignKeyConstraint baseTableName=REALM, constraintName=FK_TRAF444KK6QRKMS7N56AIWQ5Y; dropForeignKeyConstraint baseTableName=KEYCLOAK_ROLE, constraintName=FK_KJHO5LE2C0RAL09FL8CM9WFW9		\N	4.23.2	\N	\N	8678769796
map-remove-ri	keycloak	META-INF/jpa-changelog-12.0.0.xml	2024-02-23 08:59:31.662449	87	EXECUTED	9:a9ba7d47f065f041b7da856a81762021	dropForeignKeyConstraint baseTableName=REALM_DEFAULT_GROUPS, constraintName=FK_DEF_GROUPS_GROUP; dropForeignKeyConstraint baseTableName=REALM_DEFAULT_ROLES, constraintName=FK_H4WPD7W4HSOOLNI3H0SW7BTJE; dropForeignKeyConstraint baseTableName=CLIENT...		\N	4.23.2	\N	\N	8678769796
12.1.0-add-realm-localization-table	keycloak	META-INF/jpa-changelog-12.0.0.xml	2024-02-23 08:59:31.668495	88	EXECUTED	9:fffabce2bc01e1a8f5110d5278500065	createTable tableName=REALM_LOCALIZATIONS; addPrimaryKey tableName=REALM_LOCALIZATIONS		\N	4.23.2	\N	\N	8678769796
default-roles	keycloak	META-INF/jpa-changelog-13.0.0.xml	2024-02-23 08:59:31.671721	89	EXECUTED	9:fa8a5b5445e3857f4b010bafb5009957	addColumn tableName=REALM; customChange		\N	4.23.2	\N	\N	8678769796
default-roles-cleanup	keycloak	META-INF/jpa-changelog-13.0.0.xml	2024-02-23 08:59:31.675168	90	EXECUTED	9:67ac3241df9a8582d591c5ed87125f39	dropTable tableName=REALM_DEFAULT_ROLES; dropTable tableName=CLIENT_DEFAULT_ROLES		\N	4.23.2	\N	\N	8678769796
13.0.0-KEYCLOAK-16844	keycloak	META-INF/jpa-changelog-13.0.0.xml	2024-02-23 08:59:31.678243	91	EXECUTED	9:ad1194d66c937e3ffc82386c050ba089	createIndex indexName=IDX_OFFLINE_USS_PRELOAD, tableName=OFFLINE_USER_SESSION		\N	4.23.2	\N	\N	8678769796
map-remove-ri-13.0.0	keycloak	META-INF/jpa-changelog-13.0.0.xml	2024-02-23 08:59:31.681661	92	EXECUTED	9:d9be619d94af5a2f5d07b9f003543b91	dropForeignKeyConstraint baseTableName=DEFAULT_CLIENT_SCOPE, constraintName=FK_R_DEF_CLI_SCOPE_SCOPE; dropForeignKeyConstraint baseTableName=CLIENT_SCOPE_CLIENT, constraintName=FK_C_CLI_SCOPE_SCOPE; dropForeignKeyConstraint baseTableName=CLIENT_SC...		\N	4.23.2	\N	\N	8678769796
13.0.0-KEYCLOAK-17992-drop-constraints	keycloak	META-INF/jpa-changelog-13.0.0.xml	2024-02-23 08:59:31.682614	93	MARK_RAN	9:544d201116a0fcc5a5da0925fbbc3bde	dropPrimaryKey constraintName=C_CLI_SCOPE_BIND, tableName=CLIENT_SCOPE_CLIENT; dropIndex indexName=IDX_CLSCOPE_CL, tableName=CLIENT_SCOPE_CLIENT; dropIndex indexName=IDX_CL_CLSCOPE, tableName=CLIENT_SCOPE_CLIENT		\N	4.23.2	\N	\N	8678769796
13.0.0-increase-column-size-federated	keycloak	META-INF/jpa-changelog-13.0.0.xml	2024-02-23 08:59:31.686823	94	EXECUTED	9:43c0c1055b6761b4b3e89de76d612ccf	modifyDataType columnName=CLIENT_ID, tableName=CLIENT_SCOPE_CLIENT; modifyDataType columnName=SCOPE_ID, tableName=CLIENT_SCOPE_CLIENT		\N	4.23.2	\N	\N	8678769796
13.0.0-KEYCLOAK-17992-recreate-constraints	keycloak	META-INF/jpa-changelog-13.0.0.xml	2024-02-23 08:59:31.688436	95	MARK_RAN	9:8bd711fd0330f4fe980494ca43ab1139	addNotNullConstraint columnName=CLIENT_ID, tableName=CLIENT_SCOPE_CLIENT; addNotNullConstraint columnName=SCOPE_ID, tableName=CLIENT_SCOPE_CLIENT; addPrimaryKey constraintName=C_CLI_SCOPE_BIND, tableName=CLIENT_SCOPE_CLIENT; createIndex indexName=...		\N	4.23.2	\N	\N	8678769796
json-string-accomodation-fixed	keycloak	META-INF/jpa-changelog-13.0.0.xml	2024-02-23 08:59:31.691613	96	EXECUTED	9:e07d2bc0970c348bb06fb63b1f82ddbf	addColumn tableName=REALM_ATTRIBUTE; update tableName=REALM_ATTRIBUTE; dropColumn columnName=VALUE, tableName=REALM_ATTRIBUTE; renameColumn newColumnName=VALUE, oldColumnName=VALUE_NEW, tableName=REALM_ATTRIBUTE		\N	4.23.2	\N	\N	8678769796
14.0.0-KEYCLOAK-11019	keycloak	META-INF/jpa-changelog-14.0.0.xml	2024-02-23 08:59:31.697229	97	EXECUTED	9:24fb8611e97f29989bea412aa38d12b7	createIndex indexName=IDX_OFFLINE_CSS_PRELOAD, tableName=OFFLINE_CLIENT_SESSION; createIndex indexName=IDX_OFFLINE_USS_BY_USER, tableName=OFFLINE_USER_SESSION; createIndex indexName=IDX_OFFLINE_USS_BY_USERSESS, tableName=OFFLINE_USER_SESSION		\N	4.23.2	\N	\N	8678769796
14.0.0-KEYCLOAK-18286	keycloak	META-INF/jpa-changelog-14.0.0.xml	2024-02-23 08:59:31.698252	98	MARK_RAN	9:259f89014ce2506ee84740cbf7163aa7	createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.23.2	\N	\N	8678769796
14.0.0-KEYCLOAK-18286-revert	keycloak	META-INF/jpa-changelog-14.0.0.xml	2024-02-23 08:59:31.702576	99	MARK_RAN	9:04baaf56c116ed19951cbc2cca584022	dropIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.23.2	\N	\N	8678769796
14.0.0-KEYCLOAK-18286-supported-dbs	keycloak	META-INF/jpa-changelog-14.0.0.xml	2024-02-23 08:59:31.706528	100	EXECUTED	9:60ca84a0f8c94ec8c3504a5a3bc88ee8	createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.23.2	\N	\N	8678769796
14.0.0-KEYCLOAK-18286-unsupported-dbs	keycloak	META-INF/jpa-changelog-14.0.0.xml	2024-02-23 08:59:31.707707	101	MARK_RAN	9:d3d977031d431db16e2c181ce49d73e9	createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.23.2	\N	\N	8678769796
KEYCLOAK-17267-add-index-to-user-attributes	keycloak	META-INF/jpa-changelog-14.0.0.xml	2024-02-23 08:59:31.710831	102	EXECUTED	9:0b305d8d1277f3a89a0a53a659ad274c	createIndex indexName=IDX_USER_ATTRIBUTE_NAME, tableName=USER_ATTRIBUTE		\N	4.23.2	\N	\N	8678769796
KEYCLOAK-18146-add-saml-art-binding-identifier	keycloak	META-INF/jpa-changelog-14.0.0.xml	2024-02-23 08:59:31.713246	103	EXECUTED	9:2c374ad2cdfe20e2905a84c8fac48460	customChange		\N	4.23.2	\N	\N	8678769796
15.0.0-KEYCLOAK-18467	keycloak	META-INF/jpa-changelog-15.0.0.xml	2024-02-23 08:59:31.716234	104	EXECUTED	9:47a760639ac597360a8219f5b768b4de	addColumn tableName=REALM_LOCALIZATIONS; update tableName=REALM_LOCALIZATIONS; dropColumn columnName=TEXTS, tableName=REALM_LOCALIZATIONS; renameColumn newColumnName=TEXTS, oldColumnName=TEXTS_NEW, tableName=REALM_LOCALIZATIONS; addNotNullConstrai...		\N	4.23.2	\N	\N	8678769796
17.0.0-9562	keycloak	META-INF/jpa-changelog-17.0.0.xml	2024-02-23 08:59:31.719018	105	EXECUTED	9:a6272f0576727dd8cad2522335f5d99e	createIndex indexName=IDX_USER_SERVICE_ACCOUNT, tableName=USER_ENTITY		\N	4.23.2	\N	\N	8678769796
18.0.0-10625-IDX_ADMIN_EVENT_TIME	keycloak	META-INF/jpa-changelog-18.0.0.xml	2024-02-23 08:59:31.721606	106	EXECUTED	9:015479dbd691d9cc8669282f4828c41d	createIndex indexName=IDX_ADMIN_EVENT_TIME, tableName=ADMIN_EVENT_ENTITY		\N	4.23.2	\N	\N	8678769796
19.0.0-10135	keycloak	META-INF/jpa-changelog-19.0.0.xml	2024-02-23 08:59:31.72381	107	EXECUTED	9:9518e495fdd22f78ad6425cc30630221	customChange		\N	4.23.2	\N	\N	8678769796
20.0.0-12964-supported-dbs	keycloak	META-INF/jpa-changelog-20.0.0.xml	2024-02-23 08:59:31.726865	108	EXECUTED	9:e5f243877199fd96bcc842f27a1656ac	createIndex indexName=IDX_GROUP_ATT_BY_NAME_VALUE, tableName=GROUP_ATTRIBUTE		\N	4.23.2	\N	\N	8678769796
20.0.0-12964-unsupported-dbs	keycloak	META-INF/jpa-changelog-20.0.0.xml	2024-02-23 08:59:31.72787	109	MARK_RAN	9:1a6fcaa85e20bdeae0a9ce49b41946a5	createIndex indexName=IDX_GROUP_ATT_BY_NAME_VALUE, tableName=GROUP_ATTRIBUTE		\N	4.23.2	\N	\N	8678769796
client-attributes-string-accomodation-fixed	keycloak	META-INF/jpa-changelog-20.0.0.xml	2024-02-23 08:59:31.731034	110	EXECUTED	9:3f332e13e90739ed0c35b0b25b7822ca	addColumn tableName=CLIENT_ATTRIBUTES; update tableName=CLIENT_ATTRIBUTES; dropColumn columnName=VALUE, tableName=CLIENT_ATTRIBUTES; renameColumn newColumnName=VALUE, oldColumnName=VALUE_NEW, tableName=CLIENT_ATTRIBUTES		\N	4.23.2	\N	\N	8678769796
21.0.2-17277	keycloak	META-INF/jpa-changelog-21.0.2.xml	2024-02-23 08:59:31.733354	111	EXECUTED	9:7ee1f7a3fb8f5588f171fb9a6ab623c0	customChange		\N	4.23.2	\N	\N	8678769796
21.1.0-19404	keycloak	META-INF/jpa-changelog-21.1.0.xml	2024-02-23 08:59:31.745352	112	EXECUTED	9:3d7e830b52f33676b9d64f7f2b2ea634	modifyDataType columnName=DECISION_STRATEGY, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=LOGIC, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=POLICY_ENFORCE_MODE, tableName=RESOURCE_SERVER		\N	4.23.2	\N	\N	8678769796
21.1.0-19404-2	keycloak	META-INF/jpa-changelog-21.1.0.xml	2024-02-23 08:59:31.747486	113	MARK_RAN	9:627d032e3ef2c06c0e1f73d2ae25c26c	addColumn tableName=RESOURCE_SERVER_POLICY; update tableName=RESOURCE_SERVER_POLICY; dropColumn columnName=DECISION_STRATEGY, tableName=RESOURCE_SERVER_POLICY; renameColumn newColumnName=DECISION_STRATEGY, oldColumnName=DECISION_STRATEGY_NEW, tabl...		\N	4.23.2	\N	\N	8678769796
22.0.0-17484-updated	keycloak	META-INF/jpa-changelog-22.0.0.xml	2024-02-23 08:59:31.751092	114	EXECUTED	9:90af0bfd30cafc17b9f4d6eccd92b8b3	customChange		\N	4.23.2	\N	\N	8678769796
22.0.5-24031	keycloak	META-INF/jpa-changelog-22.0.0.xml	2024-02-23 08:59:31.75186	115	MARK_RAN	9:a60d2d7b315ec2d3eba9e2f145f9df28	customChange		\N	4.23.2	\N	\N	8678769796
23.0.0-12062	keycloak	META-INF/jpa-changelog-23.0.0.xml	2024-02-23 08:59:31.75476	116	EXECUTED	9:2168fbe728fec46ae9baf15bf80927b8	addColumn tableName=COMPONENT_CONFIG; update tableName=COMPONENT_CONFIG; dropColumn columnName=VALUE, tableName=COMPONENT_CONFIG; renameColumn newColumnName=VALUE, oldColumnName=VALUE_NEW, tableName=COMPONENT_CONFIG		\N	4.23.2	\N	\N	8678769796
23.0.0-17258	keycloak	META-INF/jpa-changelog-23.0.0.xml	2024-02-23 08:59:31.756591	117	EXECUTED	9:36506d679a83bbfda85a27ea1864dca8	addColumn tableName=EVENT_ENTITY		\N	4.23.2	\N	\N	8678769796
\.


--
-- Data for Name: databasechangeloglock; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.databasechangeloglock (id, locked, lockgranted, lockedby) FROM stdin;
1	f	\N	\N
1000	f	\N	\N
1001	f	\N	\N
\.


--
-- Data for Name: default_client_scope; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.default_client_scope (realm_id, scope_id, default_scope) FROM stdin;
e18440d9-9a37-4182-b5a6-d24a52fbe8de	d1bf1487-0883-46c2-b525-5fb6f8c09b2c	f
e18440d9-9a37-4182-b5a6-d24a52fbe8de	71d44657-6446-4dc7-9a28-1dd930a8ed5a	t
e18440d9-9a37-4182-b5a6-d24a52fbe8de	47a25d9c-5ded-44a3-8d25-60e9ca92325b	t
e18440d9-9a37-4182-b5a6-d24a52fbe8de	9fdd8be0-7266-4fb4-828d-0a639292c403	t
e18440d9-9a37-4182-b5a6-d24a52fbe8de	40db3c80-198c-444e-ad8f-c5ed9c07aff7	f
e18440d9-9a37-4182-b5a6-d24a52fbe8de	0a916db0-add9-427f-a7be-79bb8be6fc87	f
e18440d9-9a37-4182-b5a6-d24a52fbe8de	fd471174-9087-4bb0-af05-dda19608232e	t
e18440d9-9a37-4182-b5a6-d24a52fbe8de	56574f43-072f-41ef-af53-f6dc414644d0	t
e18440d9-9a37-4182-b5a6-d24a52fbe8de	97bcf6ee-efc2-4db0-a062-ebbc00a84639	f
e18440d9-9a37-4182-b5a6-d24a52fbe8de	f0941ea3-b402-49de-a53d-a37ea153fbf0	t
deffec2e-91ce-4521-869a-fabb8944dc44	177a0779-60cf-4253-a402-17d6d6abf8b7	f
deffec2e-91ce-4521-869a-fabb8944dc44	ff2083f6-54cc-48d7-96c1-79b8e86c54e7	t
deffec2e-91ce-4521-869a-fabb8944dc44	856e1f9c-046c-4f82-936a-514aa9c205c6	t
deffec2e-91ce-4521-869a-fabb8944dc44	6965b2ef-3ddb-45d1-99bd-470fc201bde6	t
deffec2e-91ce-4521-869a-fabb8944dc44	7707dede-2ef2-4421-896f-920b23f757c7	f
deffec2e-91ce-4521-869a-fabb8944dc44	a3526425-639e-4eb0-aa30-46439410db15	f
deffec2e-91ce-4521-869a-fabb8944dc44	5de90e63-fe15-47d3-b122-812c6cea10d5	t
deffec2e-91ce-4521-869a-fabb8944dc44	f3468c92-6959-46bc-870b-be2a3bc0c1f7	t
deffec2e-91ce-4521-869a-fabb8944dc44	77dc30a2-9f75-4e68-8d68-5e492d60c2f5	f
deffec2e-91ce-4521-869a-fabb8944dc44	b5745f6e-73d5-413f-88b1-cede3858e9cd	t
\.


--
-- Data for Name: event_entity; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.event_entity (id, client_id, details_json, error, ip_address, realm_id, session_id, event_time, type, user_id, details_json_long_value) FROM stdin;
\.


--
-- Data for Name: fed_user_attribute; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.fed_user_attribute (id, name, user_id, realm_id, storage_provider_id, value) FROM stdin;
\.


--
-- Data for Name: fed_user_consent; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.fed_user_consent (id, client_id, user_id, realm_id, storage_provider_id, created_date, last_updated_date, client_storage_provider, external_client_id) FROM stdin;
\.


--
-- Data for Name: fed_user_consent_cl_scope; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.fed_user_consent_cl_scope (user_consent_id, scope_id) FROM stdin;
\.


--
-- Data for Name: fed_user_credential; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.fed_user_credential (id, salt, type, created_date, user_id, realm_id, storage_provider_id, user_label, secret_data, credential_data, priority) FROM stdin;
\.


--
-- Data for Name: fed_user_group_membership; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.fed_user_group_membership (group_id, user_id, realm_id, storage_provider_id) FROM stdin;
\.


--
-- Data for Name: fed_user_required_action; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.fed_user_required_action (required_action, user_id, realm_id, storage_provider_id) FROM stdin;
\.


--
-- Data for Name: fed_user_role_mapping; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.fed_user_role_mapping (role_id, user_id, realm_id, storage_provider_id) FROM stdin;
\.


--
-- Data for Name: federated_identity; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.federated_identity (identity_provider, realm_id, federated_user_id, federated_username, token, user_id) FROM stdin;
\.


--
-- Data for Name: federated_user; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.federated_user (id, storage_provider_id, realm_id) FROM stdin;
\.


--
-- Data for Name: group_attribute; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.group_attribute (id, name, value, group_id) FROM stdin;
\.


--
-- Data for Name: group_role_mapping; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.group_role_mapping (role_id, group_id) FROM stdin;
\.


--
-- Data for Name: identity_provider; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.identity_provider (internal_id, enabled, provider_alias, provider_id, store_token, authenticate_by_default, realm_id, add_token_role, trust_email, first_broker_login_flow_id, post_broker_login_flow_id, provider_display_name, link_only) FROM stdin;
\.


--
-- Data for Name: identity_provider_config; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.identity_provider_config (identity_provider_id, value, name) FROM stdin;
\.


--
-- Data for Name: identity_provider_mapper; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.identity_provider_mapper (id, name, idp_alias, idp_mapper_name, realm_id) FROM stdin;
\.


--
-- Data for Name: idp_mapper_config; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.idp_mapper_config (idp_mapper_id, value, name) FROM stdin;
\.


--
-- Data for Name: keycloak_group; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.keycloak_group (id, name, parent_group, realm_id) FROM stdin;
6f0e3e6e-dc53-4747-865f-b2ffe8558082	phaidrusers	 	deffec2e-91ce-4521-869a-fabb8944dc44
e4d98ad5-da01-4f3a-ad47-a6d9f4bf23a8	phaidradmins	 	deffec2e-91ce-4521-869a-fabb8944dc44
\.


--
-- Data for Name: keycloak_role; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.keycloak_role (id, client_realm_constraint, client_role, description, name, realm_id, client, realm) FROM stdin;
2ccf34b6-5260-46ac-9721-0bc72ae22fff	e18440d9-9a37-4182-b5a6-d24a52fbe8de	f	${role_default-roles}	default-roles-master	e18440d9-9a37-4182-b5a6-d24a52fbe8de	\N	\N
0e2d6618-377f-4c3e-a8b8-a6f672e25c3c	e18440d9-9a37-4182-b5a6-d24a52fbe8de	f	${role_create-realm}	create-realm	e18440d9-9a37-4182-b5a6-d24a52fbe8de	\N	\N
b11e6758-c4c3-4830-a537-dca51a5c65ad	e18440d9-9a37-4182-b5a6-d24a52fbe8de	f	${role_admin}	admin	e18440d9-9a37-4182-b5a6-d24a52fbe8de	\N	\N
4ab9a7dd-bad2-4522-9130-4a3cec5c396f	9b952648-c8ca-47c1-bd66-8101ca3cf78a	t	${role_create-client}	create-client	e18440d9-9a37-4182-b5a6-d24a52fbe8de	9b952648-c8ca-47c1-bd66-8101ca3cf78a	\N
605956cf-0433-4729-9eb1-d67cbb2a2078	9b952648-c8ca-47c1-bd66-8101ca3cf78a	t	${role_view-realm}	view-realm	e18440d9-9a37-4182-b5a6-d24a52fbe8de	9b952648-c8ca-47c1-bd66-8101ca3cf78a	\N
5d1d306e-b9a4-4ed1-a81b-486c29df9062	9b952648-c8ca-47c1-bd66-8101ca3cf78a	t	${role_view-users}	view-users	e18440d9-9a37-4182-b5a6-d24a52fbe8de	9b952648-c8ca-47c1-bd66-8101ca3cf78a	\N
8216b6db-f68d-4279-8a03-dd8f8fd26c64	9b952648-c8ca-47c1-bd66-8101ca3cf78a	t	${role_view-clients}	view-clients	e18440d9-9a37-4182-b5a6-d24a52fbe8de	9b952648-c8ca-47c1-bd66-8101ca3cf78a	\N
b34ddbed-885f-40eb-8a43-26054e563e08	9b952648-c8ca-47c1-bd66-8101ca3cf78a	t	${role_view-events}	view-events	e18440d9-9a37-4182-b5a6-d24a52fbe8de	9b952648-c8ca-47c1-bd66-8101ca3cf78a	\N
11f16876-0f73-487a-859e-ce535e6afbd8	9b952648-c8ca-47c1-bd66-8101ca3cf78a	t	${role_view-identity-providers}	view-identity-providers	e18440d9-9a37-4182-b5a6-d24a52fbe8de	9b952648-c8ca-47c1-bd66-8101ca3cf78a	\N
d67cbcce-691c-4a94-832e-4bd4588c4cac	9b952648-c8ca-47c1-bd66-8101ca3cf78a	t	${role_view-authorization}	view-authorization	e18440d9-9a37-4182-b5a6-d24a52fbe8de	9b952648-c8ca-47c1-bd66-8101ca3cf78a	\N
7dd807ed-59ff-4597-8a83-b5fdb9a82c1f	9b952648-c8ca-47c1-bd66-8101ca3cf78a	t	${role_manage-realm}	manage-realm	e18440d9-9a37-4182-b5a6-d24a52fbe8de	9b952648-c8ca-47c1-bd66-8101ca3cf78a	\N
eeba6d65-f5fa-4a66-a800-a43e32f19740	9b952648-c8ca-47c1-bd66-8101ca3cf78a	t	${role_manage-users}	manage-users	e18440d9-9a37-4182-b5a6-d24a52fbe8de	9b952648-c8ca-47c1-bd66-8101ca3cf78a	\N
0005e94e-f367-4670-88e4-c98ae5cf5a3b	9b952648-c8ca-47c1-bd66-8101ca3cf78a	t	${role_manage-clients}	manage-clients	e18440d9-9a37-4182-b5a6-d24a52fbe8de	9b952648-c8ca-47c1-bd66-8101ca3cf78a	\N
ff9f7d3a-4ab7-46aa-9f0c-c0e62f9b7847	9b952648-c8ca-47c1-bd66-8101ca3cf78a	t	${role_manage-events}	manage-events	e18440d9-9a37-4182-b5a6-d24a52fbe8de	9b952648-c8ca-47c1-bd66-8101ca3cf78a	\N
2a92f917-2450-45e4-ba7d-58883f9861ce	9b952648-c8ca-47c1-bd66-8101ca3cf78a	t	${role_manage-identity-providers}	manage-identity-providers	e18440d9-9a37-4182-b5a6-d24a52fbe8de	9b952648-c8ca-47c1-bd66-8101ca3cf78a	\N
0212eaa7-1dfb-4ba3-93c3-dbb77254477e	9b952648-c8ca-47c1-bd66-8101ca3cf78a	t	${role_manage-authorization}	manage-authorization	e18440d9-9a37-4182-b5a6-d24a52fbe8de	9b952648-c8ca-47c1-bd66-8101ca3cf78a	\N
c342bc7d-8660-4a44-aab1-66828351715c	9b952648-c8ca-47c1-bd66-8101ca3cf78a	t	${role_query-users}	query-users	e18440d9-9a37-4182-b5a6-d24a52fbe8de	9b952648-c8ca-47c1-bd66-8101ca3cf78a	\N
42b59d48-9bee-4da0-bc7d-2d844ff1e028	9b952648-c8ca-47c1-bd66-8101ca3cf78a	t	${role_query-clients}	query-clients	e18440d9-9a37-4182-b5a6-d24a52fbe8de	9b952648-c8ca-47c1-bd66-8101ca3cf78a	\N
48345658-25c9-4eb6-bd31-584b082da591	9b952648-c8ca-47c1-bd66-8101ca3cf78a	t	${role_query-realms}	query-realms	e18440d9-9a37-4182-b5a6-d24a52fbe8de	9b952648-c8ca-47c1-bd66-8101ca3cf78a	\N
8223ff6e-c467-4864-8ccd-9645e68612c6	9b952648-c8ca-47c1-bd66-8101ca3cf78a	t	${role_query-groups}	query-groups	e18440d9-9a37-4182-b5a6-d24a52fbe8de	9b952648-c8ca-47c1-bd66-8101ca3cf78a	\N
059f6d95-c5b8-456a-85d5-49a6fe88c9da	4cbb8291-d081-41ed-9cf2-cf6039ecdda1	t	${role_view-profile}	view-profile	e18440d9-9a37-4182-b5a6-d24a52fbe8de	4cbb8291-d081-41ed-9cf2-cf6039ecdda1	\N
278430ae-a38e-4866-ae62-2f15c9ab6dc3	4cbb8291-d081-41ed-9cf2-cf6039ecdda1	t	${role_manage-account}	manage-account	e18440d9-9a37-4182-b5a6-d24a52fbe8de	4cbb8291-d081-41ed-9cf2-cf6039ecdda1	\N
5cb2c5dc-2288-4a16-9a10-2e6ba28395ad	4cbb8291-d081-41ed-9cf2-cf6039ecdda1	t	${role_manage-account-links}	manage-account-links	e18440d9-9a37-4182-b5a6-d24a52fbe8de	4cbb8291-d081-41ed-9cf2-cf6039ecdda1	\N
1ed36ec7-a5eb-4109-a844-0fcccf2abf73	4cbb8291-d081-41ed-9cf2-cf6039ecdda1	t	${role_view-applications}	view-applications	e18440d9-9a37-4182-b5a6-d24a52fbe8de	4cbb8291-d081-41ed-9cf2-cf6039ecdda1	\N
7e32234a-91ed-4518-9b1c-6dbfd2340ae8	4cbb8291-d081-41ed-9cf2-cf6039ecdda1	t	${role_view-consent}	view-consent	e18440d9-9a37-4182-b5a6-d24a52fbe8de	4cbb8291-d081-41ed-9cf2-cf6039ecdda1	\N
f0afe3a7-f46a-4ad9-ab14-59408a716a2f	4cbb8291-d081-41ed-9cf2-cf6039ecdda1	t	${role_manage-consent}	manage-consent	e18440d9-9a37-4182-b5a6-d24a52fbe8de	4cbb8291-d081-41ed-9cf2-cf6039ecdda1	\N
fa8e5678-5b56-4a28-87f1-f378099a00c2	4cbb8291-d081-41ed-9cf2-cf6039ecdda1	t	${role_view-groups}	view-groups	e18440d9-9a37-4182-b5a6-d24a52fbe8de	4cbb8291-d081-41ed-9cf2-cf6039ecdda1	\N
290200f9-790a-4098-bcf3-223f31d6f2f5	4cbb8291-d081-41ed-9cf2-cf6039ecdda1	t	${role_delete-account}	delete-account	e18440d9-9a37-4182-b5a6-d24a52fbe8de	4cbb8291-d081-41ed-9cf2-cf6039ecdda1	\N
694ec71d-5b53-4745-8387-a483831dfc76	95b70658-1788-4b4a-8415-07f5ba81d747	t	${role_read-token}	read-token	e18440d9-9a37-4182-b5a6-d24a52fbe8de	95b70658-1788-4b4a-8415-07f5ba81d747	\N
82179503-110f-464b-9eee-64dcc8e73703	9b952648-c8ca-47c1-bd66-8101ca3cf78a	t	${role_impersonation}	impersonation	e18440d9-9a37-4182-b5a6-d24a52fbe8de	9b952648-c8ca-47c1-bd66-8101ca3cf78a	\N
af78c9c5-4407-4758-b695-0c0ed9c48f7d	e18440d9-9a37-4182-b5a6-d24a52fbe8de	f	${role_offline-access}	offline_access	e18440d9-9a37-4182-b5a6-d24a52fbe8de	\N	\N
2a1fb157-3652-42a5-8367-5ce806810477	e18440d9-9a37-4182-b5a6-d24a52fbe8de	f	${role_uma_authorization}	uma_authorization	e18440d9-9a37-4182-b5a6-d24a52fbe8de	\N	\N
53d1d24b-be08-4619-8251-344248259fab	deffec2e-91ce-4521-869a-fabb8944dc44	f	${role_default-roles}	default-roles-default	deffec2e-91ce-4521-869a-fabb8944dc44	\N	\N
99c44041-ab13-4da3-bbe8-6472b77cd69f	cbfd8c2d-001c-47d5-b7fa-c06d60c9348a	t	${role_create-client}	create-client	e18440d9-9a37-4182-b5a6-d24a52fbe8de	cbfd8c2d-001c-47d5-b7fa-c06d60c9348a	\N
8f766919-e328-4abc-bd9b-dad7d646ffb8	cbfd8c2d-001c-47d5-b7fa-c06d60c9348a	t	${role_view-realm}	view-realm	e18440d9-9a37-4182-b5a6-d24a52fbe8de	cbfd8c2d-001c-47d5-b7fa-c06d60c9348a	\N
0553ef1b-2199-49a3-8f6c-e17fd35e9091	cbfd8c2d-001c-47d5-b7fa-c06d60c9348a	t	${role_view-users}	view-users	e18440d9-9a37-4182-b5a6-d24a52fbe8de	cbfd8c2d-001c-47d5-b7fa-c06d60c9348a	\N
7b56de6c-9030-452f-9e79-ec642e71b387	cbfd8c2d-001c-47d5-b7fa-c06d60c9348a	t	${role_view-clients}	view-clients	e18440d9-9a37-4182-b5a6-d24a52fbe8de	cbfd8c2d-001c-47d5-b7fa-c06d60c9348a	\N
0e3f4912-92f1-459e-a091-ae227d0a9c1e	cbfd8c2d-001c-47d5-b7fa-c06d60c9348a	t	${role_view-events}	view-events	e18440d9-9a37-4182-b5a6-d24a52fbe8de	cbfd8c2d-001c-47d5-b7fa-c06d60c9348a	\N
0ee3d458-d424-47bb-a859-fad809a37bca	cbfd8c2d-001c-47d5-b7fa-c06d60c9348a	t	${role_view-identity-providers}	view-identity-providers	e18440d9-9a37-4182-b5a6-d24a52fbe8de	cbfd8c2d-001c-47d5-b7fa-c06d60c9348a	\N
4d5f8969-27c8-431f-9db9-a7faad11d8df	cbfd8c2d-001c-47d5-b7fa-c06d60c9348a	t	${role_view-authorization}	view-authorization	e18440d9-9a37-4182-b5a6-d24a52fbe8de	cbfd8c2d-001c-47d5-b7fa-c06d60c9348a	\N
fcd4d616-98a7-4c86-b257-9fc3b3d07bc9	cbfd8c2d-001c-47d5-b7fa-c06d60c9348a	t	${role_manage-realm}	manage-realm	e18440d9-9a37-4182-b5a6-d24a52fbe8de	cbfd8c2d-001c-47d5-b7fa-c06d60c9348a	\N
653cde7a-6f0f-472d-8b9e-c03905cba101	cbfd8c2d-001c-47d5-b7fa-c06d60c9348a	t	${role_manage-users}	manage-users	e18440d9-9a37-4182-b5a6-d24a52fbe8de	cbfd8c2d-001c-47d5-b7fa-c06d60c9348a	\N
e41bfb1d-0313-4571-a941-bebaf435592e	cbfd8c2d-001c-47d5-b7fa-c06d60c9348a	t	${role_manage-clients}	manage-clients	e18440d9-9a37-4182-b5a6-d24a52fbe8de	cbfd8c2d-001c-47d5-b7fa-c06d60c9348a	\N
4d242743-9695-44ee-9a16-d62806ec50ce	cbfd8c2d-001c-47d5-b7fa-c06d60c9348a	t	${role_manage-events}	manage-events	e18440d9-9a37-4182-b5a6-d24a52fbe8de	cbfd8c2d-001c-47d5-b7fa-c06d60c9348a	\N
c3beaa1f-1460-4958-afeb-6a422d2e1f5b	cbfd8c2d-001c-47d5-b7fa-c06d60c9348a	t	${role_manage-identity-providers}	manage-identity-providers	e18440d9-9a37-4182-b5a6-d24a52fbe8de	cbfd8c2d-001c-47d5-b7fa-c06d60c9348a	\N
f06578ac-d771-482f-95ad-fa91bfe52310	cbfd8c2d-001c-47d5-b7fa-c06d60c9348a	t	${role_manage-authorization}	manage-authorization	e18440d9-9a37-4182-b5a6-d24a52fbe8de	cbfd8c2d-001c-47d5-b7fa-c06d60c9348a	\N
8f7cf384-47a1-49ff-b315-38f7f1e2e2d4	cbfd8c2d-001c-47d5-b7fa-c06d60c9348a	t	${role_query-users}	query-users	e18440d9-9a37-4182-b5a6-d24a52fbe8de	cbfd8c2d-001c-47d5-b7fa-c06d60c9348a	\N
2cc2232d-2a4f-4616-853d-f8066c731fd2	cbfd8c2d-001c-47d5-b7fa-c06d60c9348a	t	${role_query-clients}	query-clients	e18440d9-9a37-4182-b5a6-d24a52fbe8de	cbfd8c2d-001c-47d5-b7fa-c06d60c9348a	\N
9aadb555-9811-491a-8088-e46ddf70c512	cbfd8c2d-001c-47d5-b7fa-c06d60c9348a	t	${role_query-realms}	query-realms	e18440d9-9a37-4182-b5a6-d24a52fbe8de	cbfd8c2d-001c-47d5-b7fa-c06d60c9348a	\N
0795878b-9c43-4235-a834-295058c72d24	cbfd8c2d-001c-47d5-b7fa-c06d60c9348a	t	${role_query-groups}	query-groups	e18440d9-9a37-4182-b5a6-d24a52fbe8de	cbfd8c2d-001c-47d5-b7fa-c06d60c9348a	\N
93b1251d-4532-4968-ae6a-3c8490507d1e	61e0950a-44e4-45c6-a261-52e2af025aae	t	${role_realm-admin}	realm-admin	deffec2e-91ce-4521-869a-fabb8944dc44	61e0950a-44e4-45c6-a261-52e2af025aae	\N
22cac92a-f579-41c1-98f7-f4352b9d014c	61e0950a-44e4-45c6-a261-52e2af025aae	t	${role_create-client}	create-client	deffec2e-91ce-4521-869a-fabb8944dc44	61e0950a-44e4-45c6-a261-52e2af025aae	\N
cdfb805a-1e6d-49d8-849f-b363b2334d35	61e0950a-44e4-45c6-a261-52e2af025aae	t	${role_view-realm}	view-realm	deffec2e-91ce-4521-869a-fabb8944dc44	61e0950a-44e4-45c6-a261-52e2af025aae	\N
4a21e9d2-f338-4c91-8f09-c8af58fc9c4b	61e0950a-44e4-45c6-a261-52e2af025aae	t	${role_view-users}	view-users	deffec2e-91ce-4521-869a-fabb8944dc44	61e0950a-44e4-45c6-a261-52e2af025aae	\N
f9d11edf-7e34-4379-901e-0fee52b4daf5	61e0950a-44e4-45c6-a261-52e2af025aae	t	${role_view-clients}	view-clients	deffec2e-91ce-4521-869a-fabb8944dc44	61e0950a-44e4-45c6-a261-52e2af025aae	\N
42fabba5-ab58-45a4-a167-b94e8d0181bd	61e0950a-44e4-45c6-a261-52e2af025aae	t	${role_view-events}	view-events	deffec2e-91ce-4521-869a-fabb8944dc44	61e0950a-44e4-45c6-a261-52e2af025aae	\N
eaad16c2-de78-4064-80f0-5266974f9c0f	61e0950a-44e4-45c6-a261-52e2af025aae	t	${role_view-identity-providers}	view-identity-providers	deffec2e-91ce-4521-869a-fabb8944dc44	61e0950a-44e4-45c6-a261-52e2af025aae	\N
fd1a802d-5396-4d9d-8eb5-93db432229b5	61e0950a-44e4-45c6-a261-52e2af025aae	t	${role_view-authorization}	view-authorization	deffec2e-91ce-4521-869a-fabb8944dc44	61e0950a-44e4-45c6-a261-52e2af025aae	\N
1a0d37c4-aa5e-414a-b286-622707a65934	61e0950a-44e4-45c6-a261-52e2af025aae	t	${role_manage-realm}	manage-realm	deffec2e-91ce-4521-869a-fabb8944dc44	61e0950a-44e4-45c6-a261-52e2af025aae	\N
12e39b2c-e01b-46dd-8d38-3c9035dddcd2	61e0950a-44e4-45c6-a261-52e2af025aae	t	${role_manage-users}	manage-users	deffec2e-91ce-4521-869a-fabb8944dc44	61e0950a-44e4-45c6-a261-52e2af025aae	\N
f28fddce-4801-43d3-aef5-a120ba8ce349	61e0950a-44e4-45c6-a261-52e2af025aae	t	${role_manage-clients}	manage-clients	deffec2e-91ce-4521-869a-fabb8944dc44	61e0950a-44e4-45c6-a261-52e2af025aae	\N
e85d9fa1-8d79-4a26-a9ca-17d44abee976	61e0950a-44e4-45c6-a261-52e2af025aae	t	${role_manage-events}	manage-events	deffec2e-91ce-4521-869a-fabb8944dc44	61e0950a-44e4-45c6-a261-52e2af025aae	\N
19e46747-32ff-42f2-ab72-0ba58d2ce7af	61e0950a-44e4-45c6-a261-52e2af025aae	t	${role_manage-identity-providers}	manage-identity-providers	deffec2e-91ce-4521-869a-fabb8944dc44	61e0950a-44e4-45c6-a261-52e2af025aae	\N
8139629a-365c-43e8-952a-06173fdba1ba	61e0950a-44e4-45c6-a261-52e2af025aae	t	${role_manage-authorization}	manage-authorization	deffec2e-91ce-4521-869a-fabb8944dc44	61e0950a-44e4-45c6-a261-52e2af025aae	\N
395f7ebd-0ad4-40d1-8aa0-c05359ccce46	61e0950a-44e4-45c6-a261-52e2af025aae	t	${role_query-users}	query-users	deffec2e-91ce-4521-869a-fabb8944dc44	61e0950a-44e4-45c6-a261-52e2af025aae	\N
449429f3-cd47-4ef7-94de-7f6203a9f4e4	61e0950a-44e4-45c6-a261-52e2af025aae	t	${role_query-clients}	query-clients	deffec2e-91ce-4521-869a-fabb8944dc44	61e0950a-44e4-45c6-a261-52e2af025aae	\N
5e3e9e94-faa2-453f-892c-fe3340242990	61e0950a-44e4-45c6-a261-52e2af025aae	t	${role_query-realms}	query-realms	deffec2e-91ce-4521-869a-fabb8944dc44	61e0950a-44e4-45c6-a261-52e2af025aae	\N
fe4f49a1-ae39-4af5-972a-b0cb27346070	61e0950a-44e4-45c6-a261-52e2af025aae	t	${role_query-groups}	query-groups	deffec2e-91ce-4521-869a-fabb8944dc44	61e0950a-44e4-45c6-a261-52e2af025aae	\N
8eee6307-acfa-42fd-9fe1-3183c23f0dd3	54a72e08-63fb-43e3-8687-158d85067249	t	${role_view-profile}	view-profile	deffec2e-91ce-4521-869a-fabb8944dc44	54a72e08-63fb-43e3-8687-158d85067249	\N
b443590c-6f71-4160-93d5-963dd078b4bc	54a72e08-63fb-43e3-8687-158d85067249	t	${role_manage-account}	manage-account	deffec2e-91ce-4521-869a-fabb8944dc44	54a72e08-63fb-43e3-8687-158d85067249	\N
eeedfd35-9d82-46f8-ac23-ee5c47d9d505	54a72e08-63fb-43e3-8687-158d85067249	t	${role_manage-account-links}	manage-account-links	deffec2e-91ce-4521-869a-fabb8944dc44	54a72e08-63fb-43e3-8687-158d85067249	\N
f108114e-f459-43b7-9b19-4d69348358e9	54a72e08-63fb-43e3-8687-158d85067249	t	${role_view-applications}	view-applications	deffec2e-91ce-4521-869a-fabb8944dc44	54a72e08-63fb-43e3-8687-158d85067249	\N
ea7321ac-004f-492d-9ad5-8739238202e5	54a72e08-63fb-43e3-8687-158d85067249	t	${role_view-consent}	view-consent	deffec2e-91ce-4521-869a-fabb8944dc44	54a72e08-63fb-43e3-8687-158d85067249	\N
5711edc2-8399-46fb-b05c-24e42e595a0e	54a72e08-63fb-43e3-8687-158d85067249	t	${role_manage-consent}	manage-consent	deffec2e-91ce-4521-869a-fabb8944dc44	54a72e08-63fb-43e3-8687-158d85067249	\N
0c0f01f9-e10a-4cc7-bfd9-1d3f28782180	54a72e08-63fb-43e3-8687-158d85067249	t	${role_view-groups}	view-groups	deffec2e-91ce-4521-869a-fabb8944dc44	54a72e08-63fb-43e3-8687-158d85067249	\N
34fd1cec-0025-4fc2-864e-1687e5737b7a	54a72e08-63fb-43e3-8687-158d85067249	t	${role_delete-account}	delete-account	deffec2e-91ce-4521-869a-fabb8944dc44	54a72e08-63fb-43e3-8687-158d85067249	\N
42929287-a82d-4b3a-b78d-4d871d23b76d	cbfd8c2d-001c-47d5-b7fa-c06d60c9348a	t	${role_impersonation}	impersonation	e18440d9-9a37-4182-b5a6-d24a52fbe8de	cbfd8c2d-001c-47d5-b7fa-c06d60c9348a	\N
61a6a39c-4eb3-4cbe-be2d-7b7f0564a723	61e0950a-44e4-45c6-a261-52e2af025aae	t	${role_impersonation}	impersonation	deffec2e-91ce-4521-869a-fabb8944dc44	61e0950a-44e4-45c6-a261-52e2af025aae	\N
f1ef88ab-3637-4441-a911-39b450ee07f4	f1a552dd-e198-4258-9bc5-21fe86b57963	t	${role_read-token}	read-token	deffec2e-91ce-4521-869a-fabb8944dc44	f1a552dd-e198-4258-9bc5-21fe86b57963	\N
73634ccd-4f2d-4dad-8065-ac2ea50f8589	deffec2e-91ce-4521-869a-fabb8944dc44	f	${role_offline-access}	offline_access	deffec2e-91ce-4521-869a-fabb8944dc44	\N	\N
50e0165d-707a-454d-a441-be65436ebf59	deffec2e-91ce-4521-869a-fabb8944dc44	f	${role_uma_authorization}	uma_authorization	deffec2e-91ce-4521-869a-fabb8944dc44	\N	\N
\.


--
-- Data for Name: migration_model; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.migration_model (id, version, update_time) FROM stdin;
z6cyx	23.0.6	1708678771
\.


--
-- Data for Name: offline_client_session; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.offline_client_session (user_session_id, client_id, offline_flag, "timestamp", data, client_storage_provider, external_client_id) FROM stdin;
\.


--
-- Data for Name: offline_user_session; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.offline_user_session (user_session_id, user_id, realm_id, created_on, offline_flag, data, last_session_refresh) FROM stdin;
\.


--
-- Data for Name: policy_config; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.policy_config (policy_id, name, value) FROM stdin;
\.


--
-- Data for Name: protocol_mapper; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.protocol_mapper (id, name, protocol, protocol_mapper_name, client_id, client_scope_id) FROM stdin;
19de1df5-085b-4f76-a2f7-b8769b57275e	audience resolve	openid-connect	oidc-audience-resolve-mapper	34f1651f-bcea-4cba-bb21-25ed92ce4940	\N
d86482b6-57f2-4246-ae8b-9e3866c79b98	locale	openid-connect	oidc-usermodel-attribute-mapper	a36d7658-791f-4656-ae44-f61719937235	\N
58cc0743-1101-4055-bd30-bbc034aeaad4	role list	saml	saml-role-list-mapper	\N	71d44657-6446-4dc7-9a28-1dd930a8ed5a
17c40dad-626d-4ad9-8366-441775b446c4	full name	openid-connect	oidc-full-name-mapper	\N	47a25d9c-5ded-44a3-8d25-60e9ca92325b
059de738-02bf-45e6-9de2-38436abef50a	family name	openid-connect	oidc-usermodel-attribute-mapper	\N	47a25d9c-5ded-44a3-8d25-60e9ca92325b
1a9c714c-afe4-4caa-b5d5-75aff33984ab	given name	openid-connect	oidc-usermodel-attribute-mapper	\N	47a25d9c-5ded-44a3-8d25-60e9ca92325b
cb31918c-c24b-448c-9e5a-ab29cd99f3f5	middle name	openid-connect	oidc-usermodel-attribute-mapper	\N	47a25d9c-5ded-44a3-8d25-60e9ca92325b
7391278b-967b-4778-a8ee-c7289613ad82	nickname	openid-connect	oidc-usermodel-attribute-mapper	\N	47a25d9c-5ded-44a3-8d25-60e9ca92325b
cf80ccc7-31a0-42e8-8aa5-fe8a6287390a	username	openid-connect	oidc-usermodel-attribute-mapper	\N	47a25d9c-5ded-44a3-8d25-60e9ca92325b
a52c6821-873d-4e11-9f5c-77a964423322	profile	openid-connect	oidc-usermodel-attribute-mapper	\N	47a25d9c-5ded-44a3-8d25-60e9ca92325b
5337099c-6745-4f82-9f3d-128fa303b472	picture	openid-connect	oidc-usermodel-attribute-mapper	\N	47a25d9c-5ded-44a3-8d25-60e9ca92325b
4009bb83-c084-41cc-aa9e-05f099e1f680	website	openid-connect	oidc-usermodel-attribute-mapper	\N	47a25d9c-5ded-44a3-8d25-60e9ca92325b
1af70236-d594-430a-902c-c97178811cb1	gender	openid-connect	oidc-usermodel-attribute-mapper	\N	47a25d9c-5ded-44a3-8d25-60e9ca92325b
6fc1fc35-c686-4554-9a2f-80c9d6652231	birthdate	openid-connect	oidc-usermodel-attribute-mapper	\N	47a25d9c-5ded-44a3-8d25-60e9ca92325b
97d06ec8-7cdf-4d40-b0fa-485104dd70e2	zoneinfo	openid-connect	oidc-usermodel-attribute-mapper	\N	47a25d9c-5ded-44a3-8d25-60e9ca92325b
1eb590c1-f5ae-4786-8bdf-b915840555bd	locale	openid-connect	oidc-usermodel-attribute-mapper	\N	47a25d9c-5ded-44a3-8d25-60e9ca92325b
fa6f35d4-98a5-4050-ac8c-32e29ab50f92	updated at	openid-connect	oidc-usermodel-attribute-mapper	\N	47a25d9c-5ded-44a3-8d25-60e9ca92325b
897e5ac3-bd38-462e-a79e-738818a14f8c	email	openid-connect	oidc-usermodel-attribute-mapper	\N	9fdd8be0-7266-4fb4-828d-0a639292c403
2dff1737-d894-4b57-b14d-7557ed822597	email verified	openid-connect	oidc-usermodel-property-mapper	\N	9fdd8be0-7266-4fb4-828d-0a639292c403
9d7f80b4-55b2-4203-b8ae-c3c8f52972cf	address	openid-connect	oidc-address-mapper	\N	40db3c80-198c-444e-ad8f-c5ed9c07aff7
cf359733-fa2f-4e22-aff3-836560d89d79	phone number	openid-connect	oidc-usermodel-attribute-mapper	\N	0a916db0-add9-427f-a7be-79bb8be6fc87
525a099b-8c54-4d26-bc84-d0a54c49c3f8	phone number verified	openid-connect	oidc-usermodel-attribute-mapper	\N	0a916db0-add9-427f-a7be-79bb8be6fc87
a75ad0d9-d878-4335-b609-f41ce03cdac0	realm roles	openid-connect	oidc-usermodel-realm-role-mapper	\N	fd471174-9087-4bb0-af05-dda19608232e
7e71862e-d978-470c-8753-9a8013aaed0a	client roles	openid-connect	oidc-usermodel-client-role-mapper	\N	fd471174-9087-4bb0-af05-dda19608232e
805ab952-e941-4ad2-a752-88cce4fb88fa	audience resolve	openid-connect	oidc-audience-resolve-mapper	\N	fd471174-9087-4bb0-af05-dda19608232e
bcc20792-3df2-4eb4-ac89-5a1e426192e4	allowed web origins	openid-connect	oidc-allowed-origins-mapper	\N	56574f43-072f-41ef-af53-f6dc414644d0
4ff6e85c-a2ba-40f1-ac87-0d1946be684d	upn	openid-connect	oidc-usermodel-attribute-mapper	\N	97bcf6ee-efc2-4db0-a062-ebbc00a84639
5d266e30-5a12-4516-b9ea-6064e74fb5d6	groups	openid-connect	oidc-usermodel-realm-role-mapper	\N	97bcf6ee-efc2-4db0-a062-ebbc00a84639
37459bba-d4c9-4ecf-8db3-8ae006aa861f	acr loa level	openid-connect	oidc-acr-mapper	\N	f0941ea3-b402-49de-a53d-a37ea153fbf0
77e4b9a8-a0fb-49a1-bb21-3f6fb2b17c99	audience resolve	openid-connect	oidc-audience-resolve-mapper	c2ddf74e-6ed3-4b56-8625-0c42a31dc8c2	\N
5b30d857-76b4-4510-b0c5-c1486b49791e	role list	saml	saml-role-list-mapper	\N	ff2083f6-54cc-48d7-96c1-79b8e86c54e7
46acc7b7-fa0c-4ef4-813b-b9fca3f218e9	full name	openid-connect	oidc-full-name-mapper	\N	856e1f9c-046c-4f82-936a-514aa9c205c6
98dda73f-223f-43e7-9a80-068cfd45b99e	family name	openid-connect	oidc-usermodel-attribute-mapper	\N	856e1f9c-046c-4f82-936a-514aa9c205c6
0caf7d19-757e-4f62-b7cf-5585ef84c3d0	given name	openid-connect	oidc-usermodel-attribute-mapper	\N	856e1f9c-046c-4f82-936a-514aa9c205c6
c7745a47-f206-44e9-ba44-3b20f08cd54a	middle name	openid-connect	oidc-usermodel-attribute-mapper	\N	856e1f9c-046c-4f82-936a-514aa9c205c6
f8181aa3-5e42-495c-a53b-58fe80654cf8	nickname	openid-connect	oidc-usermodel-attribute-mapper	\N	856e1f9c-046c-4f82-936a-514aa9c205c6
65ad87ae-3f03-4e90-8874-cf22b2cd2ee5	username	openid-connect	oidc-usermodel-attribute-mapper	\N	856e1f9c-046c-4f82-936a-514aa9c205c6
437c9929-91ab-4ef4-ab4f-8088ced1e10f	profile	openid-connect	oidc-usermodel-attribute-mapper	\N	856e1f9c-046c-4f82-936a-514aa9c205c6
5317be81-272f-4a44-a666-b9548bb54430	picture	openid-connect	oidc-usermodel-attribute-mapper	\N	856e1f9c-046c-4f82-936a-514aa9c205c6
9809660f-1bb3-492e-b255-b749ce6d8268	website	openid-connect	oidc-usermodel-attribute-mapper	\N	856e1f9c-046c-4f82-936a-514aa9c205c6
41ac20d0-0e76-4fa6-8ea2-c8380c14000c	gender	openid-connect	oidc-usermodel-attribute-mapper	\N	856e1f9c-046c-4f82-936a-514aa9c205c6
3e235ea1-b445-4ae9-8e98-c08af0717177	birthdate	openid-connect	oidc-usermodel-attribute-mapper	\N	856e1f9c-046c-4f82-936a-514aa9c205c6
e70b1e50-7a41-446d-85fb-aa77c78d9b9b	zoneinfo	openid-connect	oidc-usermodel-attribute-mapper	\N	856e1f9c-046c-4f82-936a-514aa9c205c6
8215fca5-4c9c-40de-867e-a3d2e9123785	locale	openid-connect	oidc-usermodel-attribute-mapper	\N	856e1f9c-046c-4f82-936a-514aa9c205c6
f7e67440-c64e-46a9-931c-c7b675e36142	updated at	openid-connect	oidc-usermodel-attribute-mapper	\N	856e1f9c-046c-4f82-936a-514aa9c205c6
e1cc1e22-dc62-4b07-87f4-7d94e2d37b31	email	openid-connect	oidc-usermodel-attribute-mapper	\N	6965b2ef-3ddb-45d1-99bd-470fc201bde6
a61095df-c1ba-44f9-9e17-faedb0244562	email verified	openid-connect	oidc-usermodel-property-mapper	\N	6965b2ef-3ddb-45d1-99bd-470fc201bde6
636e4877-0037-4009-936a-4b7395795605	address	openid-connect	oidc-address-mapper	\N	7707dede-2ef2-4421-896f-920b23f757c7
ee5434f1-e2f0-4679-9aee-6e77a003625e	phone number	openid-connect	oidc-usermodel-attribute-mapper	\N	a3526425-639e-4eb0-aa30-46439410db15
0e598a3d-ce6d-42e2-9c60-cffc071806de	phone number verified	openid-connect	oidc-usermodel-attribute-mapper	\N	a3526425-639e-4eb0-aa30-46439410db15
d4086b0a-dfef-4aa4-9976-7e4f5ec7de02	realm roles	openid-connect	oidc-usermodel-realm-role-mapper	\N	5de90e63-fe15-47d3-b122-812c6cea10d5
a327301c-e8e7-4d7b-954d-de699c050917	client roles	openid-connect	oidc-usermodel-client-role-mapper	\N	5de90e63-fe15-47d3-b122-812c6cea10d5
2ca814d3-80bd-4ab9-b862-92bc5843f2a1	audience resolve	openid-connect	oidc-audience-resolve-mapper	\N	5de90e63-fe15-47d3-b122-812c6cea10d5
64221ac9-df8a-4557-855e-9ec31fe0b22d	allowed web origins	openid-connect	oidc-allowed-origins-mapper	\N	f3468c92-6959-46bc-870b-be2a3bc0c1f7
1acc84d9-2beb-40cc-a97f-c58b8bd76abe	upn	openid-connect	oidc-usermodel-attribute-mapper	\N	77dc30a2-9f75-4e68-8d68-5e492d60c2f5
8b7604d1-0602-4c4e-b9be-747becfb5795	groups	openid-connect	oidc-usermodel-realm-role-mapper	\N	77dc30a2-9f75-4e68-8d68-5e492d60c2f5
20617bb4-bb67-4714-834a-6305ff105e06	acr loa level	openid-connect	oidc-acr-mapper	\N	b5745f6e-73d5-413f-88b1-cede3858e9cd
3971e64c-1e6c-4f3e-8908-59c02ef90a29	locale	openid-connect	oidc-usermodel-attribute-mapper	c8dbae89-1dda-433d-9df7-c6d284177f13	\N
\.


--
-- Data for Name: protocol_mapper_config; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.protocol_mapper_config (protocol_mapper_id, value, name) FROM stdin;
d86482b6-57f2-4246-ae8b-9e3866c79b98	true	introspection.token.claim
d86482b6-57f2-4246-ae8b-9e3866c79b98	true	userinfo.token.claim
d86482b6-57f2-4246-ae8b-9e3866c79b98	locale	user.attribute
d86482b6-57f2-4246-ae8b-9e3866c79b98	true	id.token.claim
d86482b6-57f2-4246-ae8b-9e3866c79b98	true	access.token.claim
d86482b6-57f2-4246-ae8b-9e3866c79b98	locale	claim.name
d86482b6-57f2-4246-ae8b-9e3866c79b98	String	jsonType.label
58cc0743-1101-4055-bd30-bbc034aeaad4	false	single
58cc0743-1101-4055-bd30-bbc034aeaad4	Basic	attribute.nameformat
58cc0743-1101-4055-bd30-bbc034aeaad4	Role	attribute.name
059de738-02bf-45e6-9de2-38436abef50a	true	introspection.token.claim
059de738-02bf-45e6-9de2-38436abef50a	true	userinfo.token.claim
059de738-02bf-45e6-9de2-38436abef50a	lastName	user.attribute
059de738-02bf-45e6-9de2-38436abef50a	true	id.token.claim
059de738-02bf-45e6-9de2-38436abef50a	true	access.token.claim
059de738-02bf-45e6-9de2-38436abef50a	family_name	claim.name
059de738-02bf-45e6-9de2-38436abef50a	String	jsonType.label
17c40dad-626d-4ad9-8366-441775b446c4	true	introspection.token.claim
17c40dad-626d-4ad9-8366-441775b446c4	true	userinfo.token.claim
17c40dad-626d-4ad9-8366-441775b446c4	true	id.token.claim
17c40dad-626d-4ad9-8366-441775b446c4	true	access.token.claim
1a9c714c-afe4-4caa-b5d5-75aff33984ab	true	introspection.token.claim
1a9c714c-afe4-4caa-b5d5-75aff33984ab	true	userinfo.token.claim
1a9c714c-afe4-4caa-b5d5-75aff33984ab	firstName	user.attribute
1a9c714c-afe4-4caa-b5d5-75aff33984ab	true	id.token.claim
1a9c714c-afe4-4caa-b5d5-75aff33984ab	true	access.token.claim
1a9c714c-afe4-4caa-b5d5-75aff33984ab	given_name	claim.name
1a9c714c-afe4-4caa-b5d5-75aff33984ab	String	jsonType.label
1af70236-d594-430a-902c-c97178811cb1	true	introspection.token.claim
1af70236-d594-430a-902c-c97178811cb1	true	userinfo.token.claim
1af70236-d594-430a-902c-c97178811cb1	gender	user.attribute
1af70236-d594-430a-902c-c97178811cb1	true	id.token.claim
1af70236-d594-430a-902c-c97178811cb1	true	access.token.claim
1af70236-d594-430a-902c-c97178811cb1	gender	claim.name
1af70236-d594-430a-902c-c97178811cb1	String	jsonType.label
1eb590c1-f5ae-4786-8bdf-b915840555bd	true	introspection.token.claim
1eb590c1-f5ae-4786-8bdf-b915840555bd	true	userinfo.token.claim
1eb590c1-f5ae-4786-8bdf-b915840555bd	locale	user.attribute
1eb590c1-f5ae-4786-8bdf-b915840555bd	true	id.token.claim
1eb590c1-f5ae-4786-8bdf-b915840555bd	true	access.token.claim
1eb590c1-f5ae-4786-8bdf-b915840555bd	locale	claim.name
1eb590c1-f5ae-4786-8bdf-b915840555bd	String	jsonType.label
4009bb83-c084-41cc-aa9e-05f099e1f680	true	introspection.token.claim
4009bb83-c084-41cc-aa9e-05f099e1f680	true	userinfo.token.claim
4009bb83-c084-41cc-aa9e-05f099e1f680	website	user.attribute
4009bb83-c084-41cc-aa9e-05f099e1f680	true	id.token.claim
4009bb83-c084-41cc-aa9e-05f099e1f680	true	access.token.claim
4009bb83-c084-41cc-aa9e-05f099e1f680	website	claim.name
4009bb83-c084-41cc-aa9e-05f099e1f680	String	jsonType.label
5337099c-6745-4f82-9f3d-128fa303b472	true	introspection.token.claim
5337099c-6745-4f82-9f3d-128fa303b472	true	userinfo.token.claim
5337099c-6745-4f82-9f3d-128fa303b472	picture	user.attribute
5337099c-6745-4f82-9f3d-128fa303b472	true	id.token.claim
5337099c-6745-4f82-9f3d-128fa303b472	true	access.token.claim
5337099c-6745-4f82-9f3d-128fa303b472	picture	claim.name
5337099c-6745-4f82-9f3d-128fa303b472	String	jsonType.label
6fc1fc35-c686-4554-9a2f-80c9d6652231	true	introspection.token.claim
6fc1fc35-c686-4554-9a2f-80c9d6652231	true	userinfo.token.claim
6fc1fc35-c686-4554-9a2f-80c9d6652231	birthdate	user.attribute
6fc1fc35-c686-4554-9a2f-80c9d6652231	true	id.token.claim
6fc1fc35-c686-4554-9a2f-80c9d6652231	true	access.token.claim
6fc1fc35-c686-4554-9a2f-80c9d6652231	birthdate	claim.name
6fc1fc35-c686-4554-9a2f-80c9d6652231	String	jsonType.label
7391278b-967b-4778-a8ee-c7289613ad82	true	introspection.token.claim
7391278b-967b-4778-a8ee-c7289613ad82	true	userinfo.token.claim
7391278b-967b-4778-a8ee-c7289613ad82	nickname	user.attribute
7391278b-967b-4778-a8ee-c7289613ad82	true	id.token.claim
7391278b-967b-4778-a8ee-c7289613ad82	true	access.token.claim
7391278b-967b-4778-a8ee-c7289613ad82	nickname	claim.name
7391278b-967b-4778-a8ee-c7289613ad82	String	jsonType.label
97d06ec8-7cdf-4d40-b0fa-485104dd70e2	true	introspection.token.claim
97d06ec8-7cdf-4d40-b0fa-485104dd70e2	true	userinfo.token.claim
97d06ec8-7cdf-4d40-b0fa-485104dd70e2	zoneinfo	user.attribute
97d06ec8-7cdf-4d40-b0fa-485104dd70e2	true	id.token.claim
97d06ec8-7cdf-4d40-b0fa-485104dd70e2	true	access.token.claim
97d06ec8-7cdf-4d40-b0fa-485104dd70e2	zoneinfo	claim.name
97d06ec8-7cdf-4d40-b0fa-485104dd70e2	String	jsonType.label
a52c6821-873d-4e11-9f5c-77a964423322	true	introspection.token.claim
a52c6821-873d-4e11-9f5c-77a964423322	true	userinfo.token.claim
a52c6821-873d-4e11-9f5c-77a964423322	profile	user.attribute
a52c6821-873d-4e11-9f5c-77a964423322	true	id.token.claim
a52c6821-873d-4e11-9f5c-77a964423322	true	access.token.claim
a52c6821-873d-4e11-9f5c-77a964423322	profile	claim.name
a52c6821-873d-4e11-9f5c-77a964423322	String	jsonType.label
cb31918c-c24b-448c-9e5a-ab29cd99f3f5	true	introspection.token.claim
cb31918c-c24b-448c-9e5a-ab29cd99f3f5	true	userinfo.token.claim
cb31918c-c24b-448c-9e5a-ab29cd99f3f5	middleName	user.attribute
cb31918c-c24b-448c-9e5a-ab29cd99f3f5	true	id.token.claim
cb31918c-c24b-448c-9e5a-ab29cd99f3f5	true	access.token.claim
cb31918c-c24b-448c-9e5a-ab29cd99f3f5	middle_name	claim.name
cb31918c-c24b-448c-9e5a-ab29cd99f3f5	String	jsonType.label
cf80ccc7-31a0-42e8-8aa5-fe8a6287390a	true	introspection.token.claim
cf80ccc7-31a0-42e8-8aa5-fe8a6287390a	true	userinfo.token.claim
cf80ccc7-31a0-42e8-8aa5-fe8a6287390a	username	user.attribute
cf80ccc7-31a0-42e8-8aa5-fe8a6287390a	true	id.token.claim
cf80ccc7-31a0-42e8-8aa5-fe8a6287390a	true	access.token.claim
cf80ccc7-31a0-42e8-8aa5-fe8a6287390a	preferred_username	claim.name
cf80ccc7-31a0-42e8-8aa5-fe8a6287390a	String	jsonType.label
fa6f35d4-98a5-4050-ac8c-32e29ab50f92	true	introspection.token.claim
fa6f35d4-98a5-4050-ac8c-32e29ab50f92	true	userinfo.token.claim
fa6f35d4-98a5-4050-ac8c-32e29ab50f92	updatedAt	user.attribute
fa6f35d4-98a5-4050-ac8c-32e29ab50f92	true	id.token.claim
fa6f35d4-98a5-4050-ac8c-32e29ab50f92	true	access.token.claim
fa6f35d4-98a5-4050-ac8c-32e29ab50f92	updated_at	claim.name
fa6f35d4-98a5-4050-ac8c-32e29ab50f92	long	jsonType.label
2dff1737-d894-4b57-b14d-7557ed822597	true	introspection.token.claim
2dff1737-d894-4b57-b14d-7557ed822597	true	userinfo.token.claim
2dff1737-d894-4b57-b14d-7557ed822597	emailVerified	user.attribute
2dff1737-d894-4b57-b14d-7557ed822597	true	id.token.claim
2dff1737-d894-4b57-b14d-7557ed822597	true	access.token.claim
2dff1737-d894-4b57-b14d-7557ed822597	email_verified	claim.name
2dff1737-d894-4b57-b14d-7557ed822597	boolean	jsonType.label
897e5ac3-bd38-462e-a79e-738818a14f8c	true	introspection.token.claim
897e5ac3-bd38-462e-a79e-738818a14f8c	true	userinfo.token.claim
897e5ac3-bd38-462e-a79e-738818a14f8c	email	user.attribute
897e5ac3-bd38-462e-a79e-738818a14f8c	true	id.token.claim
897e5ac3-bd38-462e-a79e-738818a14f8c	true	access.token.claim
897e5ac3-bd38-462e-a79e-738818a14f8c	email	claim.name
897e5ac3-bd38-462e-a79e-738818a14f8c	String	jsonType.label
9d7f80b4-55b2-4203-b8ae-c3c8f52972cf	formatted	user.attribute.formatted
9d7f80b4-55b2-4203-b8ae-c3c8f52972cf	country	user.attribute.country
9d7f80b4-55b2-4203-b8ae-c3c8f52972cf	true	introspection.token.claim
9d7f80b4-55b2-4203-b8ae-c3c8f52972cf	postal_code	user.attribute.postal_code
9d7f80b4-55b2-4203-b8ae-c3c8f52972cf	true	userinfo.token.claim
9d7f80b4-55b2-4203-b8ae-c3c8f52972cf	street	user.attribute.street
9d7f80b4-55b2-4203-b8ae-c3c8f52972cf	true	id.token.claim
9d7f80b4-55b2-4203-b8ae-c3c8f52972cf	region	user.attribute.region
9d7f80b4-55b2-4203-b8ae-c3c8f52972cf	true	access.token.claim
9d7f80b4-55b2-4203-b8ae-c3c8f52972cf	locality	user.attribute.locality
525a099b-8c54-4d26-bc84-d0a54c49c3f8	true	introspection.token.claim
525a099b-8c54-4d26-bc84-d0a54c49c3f8	true	userinfo.token.claim
525a099b-8c54-4d26-bc84-d0a54c49c3f8	phoneNumberVerified	user.attribute
525a099b-8c54-4d26-bc84-d0a54c49c3f8	true	id.token.claim
525a099b-8c54-4d26-bc84-d0a54c49c3f8	true	access.token.claim
525a099b-8c54-4d26-bc84-d0a54c49c3f8	phone_number_verified	claim.name
525a099b-8c54-4d26-bc84-d0a54c49c3f8	boolean	jsonType.label
cf359733-fa2f-4e22-aff3-836560d89d79	true	introspection.token.claim
cf359733-fa2f-4e22-aff3-836560d89d79	true	userinfo.token.claim
cf359733-fa2f-4e22-aff3-836560d89d79	phoneNumber	user.attribute
cf359733-fa2f-4e22-aff3-836560d89d79	true	id.token.claim
cf359733-fa2f-4e22-aff3-836560d89d79	true	access.token.claim
cf359733-fa2f-4e22-aff3-836560d89d79	phone_number	claim.name
cf359733-fa2f-4e22-aff3-836560d89d79	String	jsonType.label
7e71862e-d978-470c-8753-9a8013aaed0a	true	introspection.token.claim
7e71862e-d978-470c-8753-9a8013aaed0a	true	multivalued
7e71862e-d978-470c-8753-9a8013aaed0a	foo	user.attribute
7e71862e-d978-470c-8753-9a8013aaed0a	true	access.token.claim
7e71862e-d978-470c-8753-9a8013aaed0a	resource_access.${client_id}.roles	claim.name
7e71862e-d978-470c-8753-9a8013aaed0a	String	jsonType.label
805ab952-e941-4ad2-a752-88cce4fb88fa	true	introspection.token.claim
805ab952-e941-4ad2-a752-88cce4fb88fa	true	access.token.claim
a75ad0d9-d878-4335-b609-f41ce03cdac0	true	introspection.token.claim
a75ad0d9-d878-4335-b609-f41ce03cdac0	true	multivalued
a75ad0d9-d878-4335-b609-f41ce03cdac0	foo	user.attribute
a75ad0d9-d878-4335-b609-f41ce03cdac0	true	access.token.claim
a75ad0d9-d878-4335-b609-f41ce03cdac0	realm_access.roles	claim.name
a75ad0d9-d878-4335-b609-f41ce03cdac0	String	jsonType.label
bcc20792-3df2-4eb4-ac89-5a1e426192e4	true	introspection.token.claim
bcc20792-3df2-4eb4-ac89-5a1e426192e4	true	access.token.claim
4ff6e85c-a2ba-40f1-ac87-0d1946be684d	true	introspection.token.claim
4ff6e85c-a2ba-40f1-ac87-0d1946be684d	true	userinfo.token.claim
4ff6e85c-a2ba-40f1-ac87-0d1946be684d	username	user.attribute
4ff6e85c-a2ba-40f1-ac87-0d1946be684d	true	id.token.claim
4ff6e85c-a2ba-40f1-ac87-0d1946be684d	true	access.token.claim
4ff6e85c-a2ba-40f1-ac87-0d1946be684d	upn	claim.name
4ff6e85c-a2ba-40f1-ac87-0d1946be684d	String	jsonType.label
5d266e30-5a12-4516-b9ea-6064e74fb5d6	true	introspection.token.claim
5d266e30-5a12-4516-b9ea-6064e74fb5d6	true	multivalued
5d266e30-5a12-4516-b9ea-6064e74fb5d6	foo	user.attribute
5d266e30-5a12-4516-b9ea-6064e74fb5d6	true	id.token.claim
5d266e30-5a12-4516-b9ea-6064e74fb5d6	true	access.token.claim
5d266e30-5a12-4516-b9ea-6064e74fb5d6	groups	claim.name
5d266e30-5a12-4516-b9ea-6064e74fb5d6	String	jsonType.label
37459bba-d4c9-4ecf-8db3-8ae006aa861f	true	introspection.token.claim
37459bba-d4c9-4ecf-8db3-8ae006aa861f	true	id.token.claim
37459bba-d4c9-4ecf-8db3-8ae006aa861f	true	access.token.claim
5b30d857-76b4-4510-b0c5-c1486b49791e	false	single
5b30d857-76b4-4510-b0c5-c1486b49791e	Basic	attribute.nameformat
5b30d857-76b4-4510-b0c5-c1486b49791e	Role	attribute.name
0caf7d19-757e-4f62-b7cf-5585ef84c3d0	true	introspection.token.claim
0caf7d19-757e-4f62-b7cf-5585ef84c3d0	true	userinfo.token.claim
0caf7d19-757e-4f62-b7cf-5585ef84c3d0	firstName	user.attribute
0caf7d19-757e-4f62-b7cf-5585ef84c3d0	true	id.token.claim
0caf7d19-757e-4f62-b7cf-5585ef84c3d0	true	access.token.claim
0caf7d19-757e-4f62-b7cf-5585ef84c3d0	given_name	claim.name
0caf7d19-757e-4f62-b7cf-5585ef84c3d0	String	jsonType.label
3e235ea1-b445-4ae9-8e98-c08af0717177	true	introspection.token.claim
3e235ea1-b445-4ae9-8e98-c08af0717177	true	userinfo.token.claim
3e235ea1-b445-4ae9-8e98-c08af0717177	birthdate	user.attribute
3e235ea1-b445-4ae9-8e98-c08af0717177	true	id.token.claim
3e235ea1-b445-4ae9-8e98-c08af0717177	true	access.token.claim
3e235ea1-b445-4ae9-8e98-c08af0717177	birthdate	claim.name
3e235ea1-b445-4ae9-8e98-c08af0717177	String	jsonType.label
41ac20d0-0e76-4fa6-8ea2-c8380c14000c	true	introspection.token.claim
41ac20d0-0e76-4fa6-8ea2-c8380c14000c	true	userinfo.token.claim
41ac20d0-0e76-4fa6-8ea2-c8380c14000c	gender	user.attribute
41ac20d0-0e76-4fa6-8ea2-c8380c14000c	true	id.token.claim
41ac20d0-0e76-4fa6-8ea2-c8380c14000c	true	access.token.claim
41ac20d0-0e76-4fa6-8ea2-c8380c14000c	gender	claim.name
41ac20d0-0e76-4fa6-8ea2-c8380c14000c	String	jsonType.label
437c9929-91ab-4ef4-ab4f-8088ced1e10f	true	introspection.token.claim
437c9929-91ab-4ef4-ab4f-8088ced1e10f	true	userinfo.token.claim
437c9929-91ab-4ef4-ab4f-8088ced1e10f	profile	user.attribute
437c9929-91ab-4ef4-ab4f-8088ced1e10f	true	id.token.claim
437c9929-91ab-4ef4-ab4f-8088ced1e10f	true	access.token.claim
437c9929-91ab-4ef4-ab4f-8088ced1e10f	profile	claim.name
437c9929-91ab-4ef4-ab4f-8088ced1e10f	String	jsonType.label
46acc7b7-fa0c-4ef4-813b-b9fca3f218e9	true	introspection.token.claim
46acc7b7-fa0c-4ef4-813b-b9fca3f218e9	true	userinfo.token.claim
46acc7b7-fa0c-4ef4-813b-b9fca3f218e9	true	id.token.claim
46acc7b7-fa0c-4ef4-813b-b9fca3f218e9	true	access.token.claim
5317be81-272f-4a44-a666-b9548bb54430	true	introspection.token.claim
5317be81-272f-4a44-a666-b9548bb54430	true	userinfo.token.claim
5317be81-272f-4a44-a666-b9548bb54430	picture	user.attribute
5317be81-272f-4a44-a666-b9548bb54430	true	id.token.claim
5317be81-272f-4a44-a666-b9548bb54430	true	access.token.claim
5317be81-272f-4a44-a666-b9548bb54430	picture	claim.name
5317be81-272f-4a44-a666-b9548bb54430	String	jsonType.label
65ad87ae-3f03-4e90-8874-cf22b2cd2ee5	true	introspection.token.claim
65ad87ae-3f03-4e90-8874-cf22b2cd2ee5	true	userinfo.token.claim
65ad87ae-3f03-4e90-8874-cf22b2cd2ee5	username	user.attribute
65ad87ae-3f03-4e90-8874-cf22b2cd2ee5	true	id.token.claim
65ad87ae-3f03-4e90-8874-cf22b2cd2ee5	true	access.token.claim
65ad87ae-3f03-4e90-8874-cf22b2cd2ee5	preferred_username	claim.name
65ad87ae-3f03-4e90-8874-cf22b2cd2ee5	String	jsonType.label
8215fca5-4c9c-40de-867e-a3d2e9123785	true	introspection.token.claim
8215fca5-4c9c-40de-867e-a3d2e9123785	true	userinfo.token.claim
8215fca5-4c9c-40de-867e-a3d2e9123785	locale	user.attribute
8215fca5-4c9c-40de-867e-a3d2e9123785	true	id.token.claim
8215fca5-4c9c-40de-867e-a3d2e9123785	true	access.token.claim
8215fca5-4c9c-40de-867e-a3d2e9123785	locale	claim.name
8215fca5-4c9c-40de-867e-a3d2e9123785	String	jsonType.label
9809660f-1bb3-492e-b255-b749ce6d8268	true	introspection.token.claim
9809660f-1bb3-492e-b255-b749ce6d8268	true	userinfo.token.claim
9809660f-1bb3-492e-b255-b749ce6d8268	website	user.attribute
9809660f-1bb3-492e-b255-b749ce6d8268	true	id.token.claim
9809660f-1bb3-492e-b255-b749ce6d8268	true	access.token.claim
9809660f-1bb3-492e-b255-b749ce6d8268	website	claim.name
9809660f-1bb3-492e-b255-b749ce6d8268	String	jsonType.label
98dda73f-223f-43e7-9a80-068cfd45b99e	true	introspection.token.claim
98dda73f-223f-43e7-9a80-068cfd45b99e	true	userinfo.token.claim
98dda73f-223f-43e7-9a80-068cfd45b99e	lastName	user.attribute
98dda73f-223f-43e7-9a80-068cfd45b99e	true	id.token.claim
98dda73f-223f-43e7-9a80-068cfd45b99e	true	access.token.claim
98dda73f-223f-43e7-9a80-068cfd45b99e	family_name	claim.name
98dda73f-223f-43e7-9a80-068cfd45b99e	String	jsonType.label
c7745a47-f206-44e9-ba44-3b20f08cd54a	true	introspection.token.claim
c7745a47-f206-44e9-ba44-3b20f08cd54a	true	userinfo.token.claim
c7745a47-f206-44e9-ba44-3b20f08cd54a	middleName	user.attribute
c7745a47-f206-44e9-ba44-3b20f08cd54a	true	id.token.claim
c7745a47-f206-44e9-ba44-3b20f08cd54a	true	access.token.claim
c7745a47-f206-44e9-ba44-3b20f08cd54a	middle_name	claim.name
c7745a47-f206-44e9-ba44-3b20f08cd54a	String	jsonType.label
e70b1e50-7a41-446d-85fb-aa77c78d9b9b	true	introspection.token.claim
e70b1e50-7a41-446d-85fb-aa77c78d9b9b	true	userinfo.token.claim
e70b1e50-7a41-446d-85fb-aa77c78d9b9b	zoneinfo	user.attribute
e70b1e50-7a41-446d-85fb-aa77c78d9b9b	true	id.token.claim
e70b1e50-7a41-446d-85fb-aa77c78d9b9b	true	access.token.claim
e70b1e50-7a41-446d-85fb-aa77c78d9b9b	zoneinfo	claim.name
e70b1e50-7a41-446d-85fb-aa77c78d9b9b	String	jsonType.label
f7e67440-c64e-46a9-931c-c7b675e36142	true	introspection.token.claim
f7e67440-c64e-46a9-931c-c7b675e36142	true	userinfo.token.claim
f7e67440-c64e-46a9-931c-c7b675e36142	updatedAt	user.attribute
f7e67440-c64e-46a9-931c-c7b675e36142	true	id.token.claim
f7e67440-c64e-46a9-931c-c7b675e36142	true	access.token.claim
f7e67440-c64e-46a9-931c-c7b675e36142	updated_at	claim.name
f7e67440-c64e-46a9-931c-c7b675e36142	long	jsonType.label
f8181aa3-5e42-495c-a53b-58fe80654cf8	true	introspection.token.claim
f8181aa3-5e42-495c-a53b-58fe80654cf8	true	userinfo.token.claim
f8181aa3-5e42-495c-a53b-58fe80654cf8	nickname	user.attribute
f8181aa3-5e42-495c-a53b-58fe80654cf8	true	id.token.claim
f8181aa3-5e42-495c-a53b-58fe80654cf8	true	access.token.claim
f8181aa3-5e42-495c-a53b-58fe80654cf8	nickname	claim.name
f8181aa3-5e42-495c-a53b-58fe80654cf8	String	jsonType.label
a61095df-c1ba-44f9-9e17-faedb0244562	true	introspection.token.claim
a61095df-c1ba-44f9-9e17-faedb0244562	true	userinfo.token.claim
a61095df-c1ba-44f9-9e17-faedb0244562	emailVerified	user.attribute
a61095df-c1ba-44f9-9e17-faedb0244562	true	id.token.claim
a61095df-c1ba-44f9-9e17-faedb0244562	true	access.token.claim
a61095df-c1ba-44f9-9e17-faedb0244562	email_verified	claim.name
a61095df-c1ba-44f9-9e17-faedb0244562	boolean	jsonType.label
e1cc1e22-dc62-4b07-87f4-7d94e2d37b31	true	introspection.token.claim
e1cc1e22-dc62-4b07-87f4-7d94e2d37b31	true	userinfo.token.claim
e1cc1e22-dc62-4b07-87f4-7d94e2d37b31	email	user.attribute
e1cc1e22-dc62-4b07-87f4-7d94e2d37b31	true	id.token.claim
e1cc1e22-dc62-4b07-87f4-7d94e2d37b31	true	access.token.claim
e1cc1e22-dc62-4b07-87f4-7d94e2d37b31	email	claim.name
e1cc1e22-dc62-4b07-87f4-7d94e2d37b31	String	jsonType.label
636e4877-0037-4009-936a-4b7395795605	formatted	user.attribute.formatted
636e4877-0037-4009-936a-4b7395795605	country	user.attribute.country
636e4877-0037-4009-936a-4b7395795605	true	introspection.token.claim
636e4877-0037-4009-936a-4b7395795605	postal_code	user.attribute.postal_code
636e4877-0037-4009-936a-4b7395795605	true	userinfo.token.claim
636e4877-0037-4009-936a-4b7395795605	street	user.attribute.street
636e4877-0037-4009-936a-4b7395795605	true	id.token.claim
636e4877-0037-4009-936a-4b7395795605	region	user.attribute.region
636e4877-0037-4009-936a-4b7395795605	true	access.token.claim
636e4877-0037-4009-936a-4b7395795605	locality	user.attribute.locality
0e598a3d-ce6d-42e2-9c60-cffc071806de	true	introspection.token.claim
0e598a3d-ce6d-42e2-9c60-cffc071806de	true	userinfo.token.claim
0e598a3d-ce6d-42e2-9c60-cffc071806de	phoneNumberVerified	user.attribute
0e598a3d-ce6d-42e2-9c60-cffc071806de	true	id.token.claim
0e598a3d-ce6d-42e2-9c60-cffc071806de	true	access.token.claim
0e598a3d-ce6d-42e2-9c60-cffc071806de	phone_number_verified	claim.name
0e598a3d-ce6d-42e2-9c60-cffc071806de	boolean	jsonType.label
ee5434f1-e2f0-4679-9aee-6e77a003625e	true	introspection.token.claim
ee5434f1-e2f0-4679-9aee-6e77a003625e	true	userinfo.token.claim
ee5434f1-e2f0-4679-9aee-6e77a003625e	phoneNumber	user.attribute
ee5434f1-e2f0-4679-9aee-6e77a003625e	true	id.token.claim
ee5434f1-e2f0-4679-9aee-6e77a003625e	true	access.token.claim
ee5434f1-e2f0-4679-9aee-6e77a003625e	phone_number	claim.name
ee5434f1-e2f0-4679-9aee-6e77a003625e	String	jsonType.label
2ca814d3-80bd-4ab9-b862-92bc5843f2a1	true	introspection.token.claim
2ca814d3-80bd-4ab9-b862-92bc5843f2a1	true	access.token.claim
a327301c-e8e7-4d7b-954d-de699c050917	true	introspection.token.claim
a327301c-e8e7-4d7b-954d-de699c050917	true	multivalued
a327301c-e8e7-4d7b-954d-de699c050917	foo	user.attribute
a327301c-e8e7-4d7b-954d-de699c050917	true	access.token.claim
a327301c-e8e7-4d7b-954d-de699c050917	resource_access.${client_id}.roles	claim.name
a327301c-e8e7-4d7b-954d-de699c050917	String	jsonType.label
d4086b0a-dfef-4aa4-9976-7e4f5ec7de02	true	introspection.token.claim
d4086b0a-dfef-4aa4-9976-7e4f5ec7de02	true	multivalued
d4086b0a-dfef-4aa4-9976-7e4f5ec7de02	foo	user.attribute
d4086b0a-dfef-4aa4-9976-7e4f5ec7de02	true	access.token.claim
d4086b0a-dfef-4aa4-9976-7e4f5ec7de02	realm_access.roles	claim.name
d4086b0a-dfef-4aa4-9976-7e4f5ec7de02	String	jsonType.label
64221ac9-df8a-4557-855e-9ec31fe0b22d	true	introspection.token.claim
64221ac9-df8a-4557-855e-9ec31fe0b22d	true	access.token.claim
1acc84d9-2beb-40cc-a97f-c58b8bd76abe	true	introspection.token.claim
1acc84d9-2beb-40cc-a97f-c58b8bd76abe	true	userinfo.token.claim
1acc84d9-2beb-40cc-a97f-c58b8bd76abe	username	user.attribute
1acc84d9-2beb-40cc-a97f-c58b8bd76abe	true	id.token.claim
1acc84d9-2beb-40cc-a97f-c58b8bd76abe	true	access.token.claim
1acc84d9-2beb-40cc-a97f-c58b8bd76abe	upn	claim.name
1acc84d9-2beb-40cc-a97f-c58b8bd76abe	String	jsonType.label
8b7604d1-0602-4c4e-b9be-747becfb5795	true	introspection.token.claim
8b7604d1-0602-4c4e-b9be-747becfb5795	true	multivalued
8b7604d1-0602-4c4e-b9be-747becfb5795	foo	user.attribute
8b7604d1-0602-4c4e-b9be-747becfb5795	true	id.token.claim
8b7604d1-0602-4c4e-b9be-747becfb5795	true	access.token.claim
8b7604d1-0602-4c4e-b9be-747becfb5795	groups	claim.name
8b7604d1-0602-4c4e-b9be-747becfb5795	String	jsonType.label
20617bb4-bb67-4714-834a-6305ff105e06	true	introspection.token.claim
20617bb4-bb67-4714-834a-6305ff105e06	true	id.token.claim
20617bb4-bb67-4714-834a-6305ff105e06	true	access.token.claim
3971e64c-1e6c-4f3e-8908-59c02ef90a29	true	introspection.token.claim
3971e64c-1e6c-4f3e-8908-59c02ef90a29	true	userinfo.token.claim
3971e64c-1e6c-4f3e-8908-59c02ef90a29	locale	user.attribute
3971e64c-1e6c-4f3e-8908-59c02ef90a29	true	id.token.claim
3971e64c-1e6c-4f3e-8908-59c02ef90a29	true	access.token.claim
3971e64c-1e6c-4f3e-8908-59c02ef90a29	locale	claim.name
3971e64c-1e6c-4f3e-8908-59c02ef90a29	String	jsonType.label
\.


--
-- Data for Name: realm; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.realm (id, access_code_lifespan, user_action_lifespan, access_token_lifespan, account_theme, admin_theme, email_theme, enabled, events_enabled, events_expiration, login_theme, name, not_before, password_policy, registration_allowed, remember_me, reset_password_allowed, social, ssl_required, sso_idle_timeout, sso_max_lifespan, update_profile_on_soc_login, verify_email, master_admin_client, login_lifespan, internationalization_enabled, default_locale, reg_email_as_username, admin_events_enabled, admin_events_details_enabled, edit_username_allowed, otp_policy_counter, otp_policy_window, otp_policy_period, otp_policy_digits, otp_policy_alg, otp_policy_type, browser_flow, registration_flow, direct_grant_flow, reset_credentials_flow, client_auth_flow, offline_session_idle_timeout, revoke_refresh_token, access_token_life_implicit, login_with_email_allowed, duplicate_emails_allowed, docker_auth_flow, refresh_token_max_reuse, allow_user_managed_access, sso_max_lifespan_remember_me, sso_idle_timeout_remember_me, default_role) FROM stdin;
e18440d9-9a37-4182-b5a6-d24a52fbe8de	60	300	60	\N	\N	\N	t	f	0	\N	master	0	\N	f	f	f	f	EXTERNAL	1800	36000	f	f	9b952648-c8ca-47c1-bd66-8101ca3cf78a	1800	f	\N	f	f	f	f	0	1	30	6	HmacSHA1	totp	9bf036b3-6edd-4367-af91-7a034a212dfc	7aa76e0a-f608-4abc-b44b-faa8377353eb	05b1cce1-de38-4770-bf81-1f1fe75b4094	ed82d486-fb35-4568-b46c-411bb9337d09	f214df70-bf55-4add-aaf7-646b9939aec9	2592000	f	900	t	f	7328656d-c1de-4ff8-99df-7d73be1aa463	0	f	0	0	2ccf34b6-5260-46ac-9721-0bc72ae22fff
deffec2e-91ce-4521-869a-fabb8944dc44	60	300	300	\N	\N	\N	t	f	0	\N	default	0	\N	f	f	f	f	EXTERNAL	1800	36000	f	f	cbfd8c2d-001c-47d5-b7fa-c06d60c9348a	1800	f	\N	f	f	f	f	0	1	30	6	HmacSHA1	totp	d28e53b3-5ce0-4353-b4ca-9a8320b90da6	9efa3170-4d5c-492b-b7ba-3a123290610d	47fcc61e-1b30-455c-90e7-eba2c612f5ee	2d446316-15bc-49b4-a455-848a3b44992a	42db0288-44d9-40bb-a5a6-c0ea17737485	2592000	f	900	t	f	424f9338-b1eb-4618-9c38-c717a832c535	0	f	0	0	53d1d24b-be08-4619-8251-344248259fab
\.


--
-- Data for Name: realm_attribute; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.realm_attribute (name, realm_id, value) FROM stdin;
_browser_header.contentSecurityPolicyReportOnly	e18440d9-9a37-4182-b5a6-d24a52fbe8de	
_browser_header.xContentTypeOptions	e18440d9-9a37-4182-b5a6-d24a52fbe8de	nosniff
_browser_header.referrerPolicy	e18440d9-9a37-4182-b5a6-d24a52fbe8de	no-referrer
_browser_header.xRobotsTag	e18440d9-9a37-4182-b5a6-d24a52fbe8de	none
_browser_header.xFrameOptions	e18440d9-9a37-4182-b5a6-d24a52fbe8de	SAMEORIGIN
_browser_header.contentSecurityPolicy	e18440d9-9a37-4182-b5a6-d24a52fbe8de	frame-src 'self'; frame-ancestors 'self'; object-src 'none';
_browser_header.xXSSProtection	e18440d9-9a37-4182-b5a6-d24a52fbe8de	1; mode=block
_browser_header.strictTransportSecurity	e18440d9-9a37-4182-b5a6-d24a52fbe8de	max-age=31536000; includeSubDomains
bruteForceProtected	e18440d9-9a37-4182-b5a6-d24a52fbe8de	false
permanentLockout	e18440d9-9a37-4182-b5a6-d24a52fbe8de	false
maxFailureWaitSeconds	e18440d9-9a37-4182-b5a6-d24a52fbe8de	900
minimumQuickLoginWaitSeconds	e18440d9-9a37-4182-b5a6-d24a52fbe8de	60
waitIncrementSeconds	e18440d9-9a37-4182-b5a6-d24a52fbe8de	60
quickLoginCheckMilliSeconds	e18440d9-9a37-4182-b5a6-d24a52fbe8de	1000
maxDeltaTimeSeconds	e18440d9-9a37-4182-b5a6-d24a52fbe8de	43200
failureFactor	e18440d9-9a37-4182-b5a6-d24a52fbe8de	30
realmReusableOtpCode	e18440d9-9a37-4182-b5a6-d24a52fbe8de	false
displayName	e18440d9-9a37-4182-b5a6-d24a52fbe8de	Keycloak
displayNameHtml	e18440d9-9a37-4182-b5a6-d24a52fbe8de	<div class="kc-logo-text"><span>Keycloak</span></div>
defaultSignatureAlgorithm	e18440d9-9a37-4182-b5a6-d24a52fbe8de	RS256
offlineSessionMaxLifespanEnabled	e18440d9-9a37-4182-b5a6-d24a52fbe8de	false
offlineSessionMaxLifespan	e18440d9-9a37-4182-b5a6-d24a52fbe8de	5184000
_browser_header.contentSecurityPolicyReportOnly	deffec2e-91ce-4521-869a-fabb8944dc44	
_browser_header.xContentTypeOptions	deffec2e-91ce-4521-869a-fabb8944dc44	nosniff
_browser_header.referrerPolicy	deffec2e-91ce-4521-869a-fabb8944dc44	no-referrer
_browser_header.xRobotsTag	deffec2e-91ce-4521-869a-fabb8944dc44	none
_browser_header.xFrameOptions	deffec2e-91ce-4521-869a-fabb8944dc44	SAMEORIGIN
_browser_header.contentSecurityPolicy	deffec2e-91ce-4521-869a-fabb8944dc44	frame-src 'self'; frame-ancestors 'self'; object-src 'none';
_browser_header.xXSSProtection	deffec2e-91ce-4521-869a-fabb8944dc44	1; mode=block
_browser_header.strictTransportSecurity	deffec2e-91ce-4521-869a-fabb8944dc44	max-age=31536000; includeSubDomains
bruteForceProtected	deffec2e-91ce-4521-869a-fabb8944dc44	false
permanentLockout	deffec2e-91ce-4521-869a-fabb8944dc44	false
maxFailureWaitSeconds	deffec2e-91ce-4521-869a-fabb8944dc44	900
minimumQuickLoginWaitSeconds	deffec2e-91ce-4521-869a-fabb8944dc44	60
waitIncrementSeconds	deffec2e-91ce-4521-869a-fabb8944dc44	60
quickLoginCheckMilliSeconds	deffec2e-91ce-4521-869a-fabb8944dc44	1000
maxDeltaTimeSeconds	deffec2e-91ce-4521-869a-fabb8944dc44	43200
failureFactor	deffec2e-91ce-4521-869a-fabb8944dc44	30
realmReusableOtpCode	deffec2e-91ce-4521-869a-fabb8944dc44	false
defaultSignatureAlgorithm	deffec2e-91ce-4521-869a-fabb8944dc44	RS256
offlineSessionMaxLifespanEnabled	deffec2e-91ce-4521-869a-fabb8944dc44	false
offlineSessionMaxLifespan	deffec2e-91ce-4521-869a-fabb8944dc44	5184000
actionTokenGeneratedByAdminLifespan	deffec2e-91ce-4521-869a-fabb8944dc44	43200
actionTokenGeneratedByUserLifespan	deffec2e-91ce-4521-869a-fabb8944dc44	300
oauth2DeviceCodeLifespan	deffec2e-91ce-4521-869a-fabb8944dc44	600
oauth2DevicePollingInterval	deffec2e-91ce-4521-869a-fabb8944dc44	5
webAuthnPolicyRpEntityName	deffec2e-91ce-4521-869a-fabb8944dc44	keycloak
webAuthnPolicySignatureAlgorithms	deffec2e-91ce-4521-869a-fabb8944dc44	ES256
webAuthnPolicyRpId	deffec2e-91ce-4521-869a-fabb8944dc44	
webAuthnPolicyAttestationConveyancePreference	deffec2e-91ce-4521-869a-fabb8944dc44	not specified
webAuthnPolicyAuthenticatorAttachment	deffec2e-91ce-4521-869a-fabb8944dc44	not specified
webAuthnPolicyRequireResidentKey	deffec2e-91ce-4521-869a-fabb8944dc44	not specified
webAuthnPolicyUserVerificationRequirement	deffec2e-91ce-4521-869a-fabb8944dc44	not specified
webAuthnPolicyCreateTimeout	deffec2e-91ce-4521-869a-fabb8944dc44	0
webAuthnPolicyAvoidSameAuthenticatorRegister	deffec2e-91ce-4521-869a-fabb8944dc44	false
webAuthnPolicyRpEntityNamePasswordless	deffec2e-91ce-4521-869a-fabb8944dc44	keycloak
webAuthnPolicySignatureAlgorithmsPasswordless	deffec2e-91ce-4521-869a-fabb8944dc44	ES256
webAuthnPolicyRpIdPasswordless	deffec2e-91ce-4521-869a-fabb8944dc44	
webAuthnPolicyAttestationConveyancePreferencePasswordless	deffec2e-91ce-4521-869a-fabb8944dc44	not specified
webAuthnPolicyAuthenticatorAttachmentPasswordless	deffec2e-91ce-4521-869a-fabb8944dc44	not specified
webAuthnPolicyRequireResidentKeyPasswordless	deffec2e-91ce-4521-869a-fabb8944dc44	not specified
webAuthnPolicyUserVerificationRequirementPasswordless	deffec2e-91ce-4521-869a-fabb8944dc44	not specified
webAuthnPolicyCreateTimeoutPasswordless	deffec2e-91ce-4521-869a-fabb8944dc44	0
webAuthnPolicyAvoidSameAuthenticatorRegisterPasswordless	deffec2e-91ce-4521-869a-fabb8944dc44	false
cibaBackchannelTokenDeliveryMode	deffec2e-91ce-4521-869a-fabb8944dc44	poll
cibaExpiresIn	deffec2e-91ce-4521-869a-fabb8944dc44	120
cibaInterval	deffec2e-91ce-4521-869a-fabb8944dc44	5
cibaAuthRequestedUserHint	deffec2e-91ce-4521-869a-fabb8944dc44	login_hint
parRequestUriLifespan	deffec2e-91ce-4521-869a-fabb8944dc44	60
\.


--
-- Data for Name: realm_default_groups; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.realm_default_groups (realm_id, group_id) FROM stdin;
\.


--
-- Data for Name: realm_enabled_event_types; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.realm_enabled_event_types (realm_id, value) FROM stdin;
\.


--
-- Data for Name: realm_events_listeners; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.realm_events_listeners (realm_id, value) FROM stdin;
e18440d9-9a37-4182-b5a6-d24a52fbe8de	jboss-logging
deffec2e-91ce-4521-869a-fabb8944dc44	jboss-logging
\.


--
-- Data for Name: realm_localizations; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.realm_localizations (realm_id, locale, texts) FROM stdin;
\.


--
-- Data for Name: realm_required_credential; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.realm_required_credential (type, form_label, input, secret, realm_id) FROM stdin;
password	password	t	t	e18440d9-9a37-4182-b5a6-d24a52fbe8de
password	password	t	t	deffec2e-91ce-4521-869a-fabb8944dc44
\.


--
-- Data for Name: realm_smtp_config; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.realm_smtp_config (realm_id, value, name) FROM stdin;
\.


--
-- Data for Name: realm_supported_locales; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.realm_supported_locales (realm_id, value) FROM stdin;
\.


--
-- Data for Name: redirect_uris; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.redirect_uris (client_id, value) FROM stdin;
4cbb8291-d081-41ed-9cf2-cf6039ecdda1	/realms/master/account/*
34f1651f-bcea-4cba-bb21-25ed92ce4940	/realms/master/account/*
a36d7658-791f-4656-ae44-f61719937235	/admin/master/console/*
54a72e08-63fb-43e3-8687-158d85067249	/realms/default/account/*
c2ddf74e-6ed3-4b56-8625-0c42a31dc8c2	/realms/default/account/*
c8dbae89-1dda-433d-9df7-c6d284177f13	/admin/default/console/*
\.


--
-- Data for Name: required_action_config; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.required_action_config (required_action_id, value, name) FROM stdin;
\.


--
-- Data for Name: required_action_provider; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.required_action_provider (id, alias, name, realm_id, enabled, default_action, provider_id, priority) FROM stdin;
e67c9645-a80b-4078-bc9c-0d10dd51ace8	VERIFY_EMAIL	Verify Email	e18440d9-9a37-4182-b5a6-d24a52fbe8de	t	f	VERIFY_EMAIL	50
ab44fbc6-c8cd-4e55-9a3e-db7cdaa3754c	UPDATE_PROFILE	Update Profile	e18440d9-9a37-4182-b5a6-d24a52fbe8de	t	f	UPDATE_PROFILE	40
222fb3fb-34af-41ed-8035-20496fd2b39d	CONFIGURE_TOTP	Configure OTP	e18440d9-9a37-4182-b5a6-d24a52fbe8de	t	f	CONFIGURE_TOTP	10
eea59273-2af6-4c6d-8742-cc9410f2444a	UPDATE_PASSWORD	Update Password	e18440d9-9a37-4182-b5a6-d24a52fbe8de	t	f	UPDATE_PASSWORD	30
fe82e015-0ffc-4c98-9afc-b72ea991962a	TERMS_AND_CONDITIONS	Terms and Conditions	e18440d9-9a37-4182-b5a6-d24a52fbe8de	f	f	TERMS_AND_CONDITIONS	20
8da6a6c1-dd8c-4cd4-9097-fafc30d9142c	delete_account	Delete Account	e18440d9-9a37-4182-b5a6-d24a52fbe8de	f	f	delete_account	60
810fa0f1-a904-4763-ac89-1799d84e4a0a	update_user_locale	Update User Locale	e18440d9-9a37-4182-b5a6-d24a52fbe8de	t	f	update_user_locale	1000
52dea2e0-2730-4e70-8c95-ffb2e3a0ec67	webauthn-register	Webauthn Register	e18440d9-9a37-4182-b5a6-d24a52fbe8de	t	f	webauthn-register	70
091e8434-d043-410b-87cf-dcc90baec6b3	webauthn-register-passwordless	Webauthn Register Passwordless	e18440d9-9a37-4182-b5a6-d24a52fbe8de	t	f	webauthn-register-passwordless	80
eb0dcfb3-2f73-4c98-bf94-e17d7712161a	VERIFY_EMAIL	Verify Email	deffec2e-91ce-4521-869a-fabb8944dc44	t	f	VERIFY_EMAIL	50
d9668b6b-1f3f-4d3c-a4b1-d02ee564258d	UPDATE_PROFILE	Update Profile	deffec2e-91ce-4521-869a-fabb8944dc44	t	f	UPDATE_PROFILE	40
0dee8a17-54b6-450f-a445-a5f4bd3943d5	CONFIGURE_TOTP	Configure OTP	deffec2e-91ce-4521-869a-fabb8944dc44	t	f	CONFIGURE_TOTP	10
067beb13-7756-4f78-9b6e-25cf651982c9	UPDATE_PASSWORD	Update Password	deffec2e-91ce-4521-869a-fabb8944dc44	t	f	UPDATE_PASSWORD	30
79f0b813-1f9e-4195-bce5-ca383083c593	TERMS_AND_CONDITIONS	Terms and Conditions	deffec2e-91ce-4521-869a-fabb8944dc44	f	f	TERMS_AND_CONDITIONS	20
adc69b4c-bdfb-45f1-b03c-b8744148dd22	delete_account	Delete Account	deffec2e-91ce-4521-869a-fabb8944dc44	f	f	delete_account	60
1ef382b9-883c-416d-8ede-dddfdbfe53be	update_user_locale	Update User Locale	deffec2e-91ce-4521-869a-fabb8944dc44	t	f	update_user_locale	1000
5030d8e6-ad0d-45fc-99fa-4dbd312358a8	webauthn-register	Webauthn Register	deffec2e-91ce-4521-869a-fabb8944dc44	t	f	webauthn-register	70
9cd32abd-ec8d-4a8f-96f8-a8da255b2087	webauthn-register-passwordless	Webauthn Register Passwordless	deffec2e-91ce-4521-869a-fabb8944dc44	t	f	webauthn-register-passwordless	80
\.


--
-- Data for Name: resource_attribute; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.resource_attribute (id, name, value, resource_id) FROM stdin;
\.


--
-- Data for Name: resource_policy; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.resource_policy (resource_id, policy_id) FROM stdin;
\.


--
-- Data for Name: resource_scope; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.resource_scope (resource_id, scope_id) FROM stdin;
\.


--
-- Data for Name: resource_server; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.resource_server (id, allow_rs_remote_mgmt, policy_enforce_mode, decision_strategy) FROM stdin;
\.


--
-- Data for Name: resource_server_perm_ticket; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.resource_server_perm_ticket (id, owner, requester, created_timestamp, granted_timestamp, resource_id, scope_id, resource_server_id, policy_id) FROM stdin;
\.


--
-- Data for Name: resource_server_policy; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.resource_server_policy (id, name, description, type, decision_strategy, logic, resource_server_id, owner) FROM stdin;
\.


--
-- Data for Name: resource_server_resource; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.resource_server_resource (id, name, type, icon_uri, owner, resource_server_id, owner_managed_access, display_name) FROM stdin;
\.


--
-- Data for Name: resource_server_scope; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.resource_server_scope (id, name, icon_uri, resource_server_id, display_name) FROM stdin;
\.


--
-- Data for Name: resource_uris; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.resource_uris (resource_id, value) FROM stdin;
\.


--
-- Data for Name: role_attribute; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.role_attribute (id, role_id, name, value) FROM stdin;
\.


--
-- Data for Name: scope_mapping; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.scope_mapping (client_id, role_id) FROM stdin;
34f1651f-bcea-4cba-bb21-25ed92ce4940	278430ae-a38e-4866-ae62-2f15c9ab6dc3
34f1651f-bcea-4cba-bb21-25ed92ce4940	fa8e5678-5b56-4a28-87f1-f378099a00c2
c2ddf74e-6ed3-4b56-8625-0c42a31dc8c2	0c0f01f9-e10a-4cc7-bfd9-1d3f28782180
c2ddf74e-6ed3-4b56-8625-0c42a31dc8c2	b443590c-6f71-4160-93d5-963dd078b4bc
\.


--
-- Data for Name: scope_policy; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.scope_policy (scope_id, policy_id) FROM stdin;
\.


--
-- Data for Name: user_attribute; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_attribute (name, value, user_id, id) FROM stdin;
LDAP_ID	pone	17979245-5571-4ed6-8b6d-72b5093bad21	c52d15f7-abdc-410f-a1aa-961006aabcf6
LDAP_ENTRY_DN	cn=Phaidruser One,ou=people,dc=example,dc=org	17979245-5571-4ed6-8b6d-72b5093bad21	5bdea286-0677-4b05-b541-54f883422006
LDAP_ID	ptwo	279974b6-e4a5-422a-a47c-39acc99f092c	17f3e545-104c-491d-8d52-8df4b928c124
LDAP_ENTRY_DN	cn=Phaidruser Two,ou=people,dc=example,dc=org	279974b6-e4a5-422a-a47c-39acc99f092c	5e4f413b-03f9-4cf2-80a2-010d83d0c647
LDAP_ID	barchiver	dfee2371-39ab-4dcb-a5c1-bff4161d96f2	2d4339b7-b712-4cc9-b56a-d999ffb6ce4b
LDAP_ENTRY_DN	cn=Bob Archiver,ou=people,dc=example,dc=org	dfee2371-39ab-4dcb-a5c1-bff4161d96f2	087b3d05-13da-44bd-b995-3b0c2df1403d
createTimestamp	20240223085902Z	17979245-5571-4ed6-8b6d-72b5093bad21	aa28612f-0deb-46d6-a8d3-c88bfbc01327
modifyTimestamp	20240223085902Z	17979245-5571-4ed6-8b6d-72b5093bad21	03b813c3-8351-4b97-988e-0cf80db15836
createTimestamp	20240223085902Z	279974b6-e4a5-422a-a47c-39acc99f092c	060af3b9-5316-4998-b113-e4996ffd566d
modifyTimestamp	20240223085902Z	279974b6-e4a5-422a-a47c-39acc99f092c	35b117f9-bdcd-4a16-ab44-73a00dbbc33e
createTimestamp	20240223085902Z	dfee2371-39ab-4dcb-a5c1-bff4161d96f2	ae144197-08dd-4ae2-8120-235203e783c3
modifyTimestamp	20240223085902Z	dfee2371-39ab-4dcb-a5c1-bff4161d96f2	c0809cdb-f233-4277-ad09-52b0f77aa4a0
\.


--
-- Data for Name: user_consent; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_consent (id, client_id, user_id, created_date, last_updated_date, client_storage_provider, external_client_id) FROM stdin;
\.


--
-- Data for Name: user_consent_client_scope; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_consent_client_scope (user_consent_id, scope_id) FROM stdin;
\.


--
-- Data for Name: user_entity; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_entity (id, email, email_constraint, email_verified, enabled, federation_link, first_name, last_name, realm_id, username, created_timestamp, service_account_client_link, not_before) FROM stdin;
aa3e0315-52b2-4fc2-88f1-07e02682f580	\N	c4599eba-9822-410b-a8ba-bfe2f965a92f	f	t	\N	\N	\N	e18440d9-9a37-4182-b5a6-d24a52fbe8de	keycloak	1708678773601	\N	0
17979245-5571-4ed6-8b6d-72b5093bad21	\N	aa6e061b-25bf-47c1-8c57-fbc93364918b	f	t	421f624a-f8fa-4a9e-9853-98d471e7f1da	Phaidruser	One	deffec2e-91ce-4521-869a-fabb8944dc44	pone	1708686154123	\N	0
279974b6-e4a5-422a-a47c-39acc99f092c	\N	6980536e-0284-4bfd-85c2-73c50bca467c	f	t	421f624a-f8fa-4a9e-9853-98d471e7f1da	Phaidruser	Two	deffec2e-91ce-4521-869a-fabb8944dc44	ptwo	1708686154126	\N	0
dfee2371-39ab-4dcb-a5c1-bff4161d96f2	\N	8a5fc39c-6dcf-412f-9364-f1d3e378408a	f	t	421f624a-f8fa-4a9e-9853-98d471e7f1da	Bob	Archiver	deffec2e-91ce-4521-869a-fabb8944dc44	barchiver	1708686154129	\N	0
\.


--
-- Data for Name: user_federation_config; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_federation_config (user_federation_provider_id, value, name) FROM stdin;
\.


--
-- Data for Name: user_federation_mapper; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_federation_mapper (id, name, federation_provider_id, federation_mapper_type, realm_id) FROM stdin;
\.


--
-- Data for Name: user_federation_mapper_config; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_federation_mapper_config (user_federation_mapper_id, value, name) FROM stdin;
\.


--
-- Data for Name: user_federation_provider; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_federation_provider (id, changed_sync_period, display_name, full_sync_period, last_sync, priority, provider_name, realm_id) FROM stdin;
\.


--
-- Data for Name: user_group_membership; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_group_membership (group_id, user_id) FROM stdin;
\.


--
-- Data for Name: user_required_action; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_required_action (user_id, required_action) FROM stdin;
\.


--
-- Data for Name: user_role_mapping; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_role_mapping (role_id, user_id) FROM stdin;
2ccf34b6-5260-46ac-9721-0bc72ae22fff	aa3e0315-52b2-4fc2-88f1-07e02682f580
b11e6758-c4c3-4830-a537-dca51a5c65ad	aa3e0315-52b2-4fc2-88f1-07e02682f580
99c44041-ab13-4da3-bbe8-6472b77cd69f	aa3e0315-52b2-4fc2-88f1-07e02682f580
8f766919-e328-4abc-bd9b-dad7d646ffb8	aa3e0315-52b2-4fc2-88f1-07e02682f580
0553ef1b-2199-49a3-8f6c-e17fd35e9091	aa3e0315-52b2-4fc2-88f1-07e02682f580
7b56de6c-9030-452f-9e79-ec642e71b387	aa3e0315-52b2-4fc2-88f1-07e02682f580
0e3f4912-92f1-459e-a091-ae227d0a9c1e	aa3e0315-52b2-4fc2-88f1-07e02682f580
0ee3d458-d424-47bb-a859-fad809a37bca	aa3e0315-52b2-4fc2-88f1-07e02682f580
4d5f8969-27c8-431f-9db9-a7faad11d8df	aa3e0315-52b2-4fc2-88f1-07e02682f580
fcd4d616-98a7-4c86-b257-9fc3b3d07bc9	aa3e0315-52b2-4fc2-88f1-07e02682f580
653cde7a-6f0f-472d-8b9e-c03905cba101	aa3e0315-52b2-4fc2-88f1-07e02682f580
e41bfb1d-0313-4571-a941-bebaf435592e	aa3e0315-52b2-4fc2-88f1-07e02682f580
4d242743-9695-44ee-9a16-d62806ec50ce	aa3e0315-52b2-4fc2-88f1-07e02682f580
c3beaa1f-1460-4958-afeb-6a422d2e1f5b	aa3e0315-52b2-4fc2-88f1-07e02682f580
f06578ac-d771-482f-95ad-fa91bfe52310	aa3e0315-52b2-4fc2-88f1-07e02682f580
8f7cf384-47a1-49ff-b315-38f7f1e2e2d4	aa3e0315-52b2-4fc2-88f1-07e02682f580
2cc2232d-2a4f-4616-853d-f8066c731fd2	aa3e0315-52b2-4fc2-88f1-07e02682f580
9aadb555-9811-491a-8088-e46ddf70c512	aa3e0315-52b2-4fc2-88f1-07e02682f580
0795878b-9c43-4235-a834-295058c72d24	aa3e0315-52b2-4fc2-88f1-07e02682f580
53d1d24b-be08-4619-8251-344248259fab	17979245-5571-4ed6-8b6d-72b5093bad21
53d1d24b-be08-4619-8251-344248259fab	279974b6-e4a5-422a-a47c-39acc99f092c
53d1d24b-be08-4619-8251-344248259fab	dfee2371-39ab-4dcb-a5c1-bff4161d96f2
\.


--
-- Data for Name: user_session; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_session (id, auth_method, ip_address, last_session_refresh, login_username, realm_id, remember_me, started, user_id, user_session_state, broker_session_id, broker_user_id) FROM stdin;
\.


--
-- Data for Name: user_session_note; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.user_session_note (user_session, name, value) FROM stdin;
\.


--
-- Data for Name: username_login_failure; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.username_login_failure (realm_id, username, failed_login_not_before, last_failure, last_ip_failure, num_failures) FROM stdin;
\.


--
-- Data for Name: web_origins; Type: TABLE DATA; Schema: public; Owner: keycloak
--

COPY public.web_origins (client_id, value) FROM stdin;
a36d7658-791f-4656-ae44-f61719937235	+
c8dbae89-1dda-433d-9df7-c6d284177f13	+
\.


--
-- Name: username_login_failure CONSTRAINT_17-2; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.username_login_failure
    ADD CONSTRAINT "CONSTRAINT_17-2" PRIMARY KEY (realm_id, username);


--
-- Name: keycloak_role UK_J3RWUVD56ONTGSUHOGM184WW2-2; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.keycloak_role
    ADD CONSTRAINT "UK_J3RWUVD56ONTGSUHOGM184WW2-2" UNIQUE (name, client_realm_constraint);


--
-- Name: client_auth_flow_bindings c_cli_flow_bind; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_auth_flow_bindings
    ADD CONSTRAINT c_cli_flow_bind PRIMARY KEY (client_id, binding_name);


--
-- Name: client_scope_client c_cli_scope_bind; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_scope_client
    ADD CONSTRAINT c_cli_scope_bind PRIMARY KEY (client_id, scope_id);


--
-- Name: client_initial_access cnstr_client_init_acc_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_initial_access
    ADD CONSTRAINT cnstr_client_init_acc_pk PRIMARY KEY (id);


--
-- Name: realm_default_groups con_group_id_def_groups; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_default_groups
    ADD CONSTRAINT con_group_id_def_groups UNIQUE (group_id);


--
-- Name: broker_link constr_broker_link_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.broker_link
    ADD CONSTRAINT constr_broker_link_pk PRIMARY KEY (identity_provider, user_id);


--
-- Name: client_user_session_note constr_cl_usr_ses_note; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_user_session_note
    ADD CONSTRAINT constr_cl_usr_ses_note PRIMARY KEY (client_session, name);


--
-- Name: component_config constr_component_config_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.component_config
    ADD CONSTRAINT constr_component_config_pk PRIMARY KEY (id);


--
-- Name: component constr_component_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.component
    ADD CONSTRAINT constr_component_pk PRIMARY KEY (id);


--
-- Name: fed_user_required_action constr_fed_required_action; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.fed_user_required_action
    ADD CONSTRAINT constr_fed_required_action PRIMARY KEY (required_action, user_id);


--
-- Name: fed_user_attribute constr_fed_user_attr_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.fed_user_attribute
    ADD CONSTRAINT constr_fed_user_attr_pk PRIMARY KEY (id);


--
-- Name: fed_user_consent constr_fed_user_consent_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.fed_user_consent
    ADD CONSTRAINT constr_fed_user_consent_pk PRIMARY KEY (id);


--
-- Name: fed_user_credential constr_fed_user_cred_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.fed_user_credential
    ADD CONSTRAINT constr_fed_user_cred_pk PRIMARY KEY (id);


--
-- Name: fed_user_group_membership constr_fed_user_group; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.fed_user_group_membership
    ADD CONSTRAINT constr_fed_user_group PRIMARY KEY (group_id, user_id);


--
-- Name: fed_user_role_mapping constr_fed_user_role; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.fed_user_role_mapping
    ADD CONSTRAINT constr_fed_user_role PRIMARY KEY (role_id, user_id);


--
-- Name: federated_user constr_federated_user; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.federated_user
    ADD CONSTRAINT constr_federated_user PRIMARY KEY (id);


--
-- Name: realm_default_groups constr_realm_default_groups; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_default_groups
    ADD CONSTRAINT constr_realm_default_groups PRIMARY KEY (realm_id, group_id);


--
-- Name: realm_enabled_event_types constr_realm_enabl_event_types; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_enabled_event_types
    ADD CONSTRAINT constr_realm_enabl_event_types PRIMARY KEY (realm_id, value);


--
-- Name: realm_events_listeners constr_realm_events_listeners; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_events_listeners
    ADD CONSTRAINT constr_realm_events_listeners PRIMARY KEY (realm_id, value);


--
-- Name: realm_supported_locales constr_realm_supported_locales; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_supported_locales
    ADD CONSTRAINT constr_realm_supported_locales PRIMARY KEY (realm_id, value);


--
-- Name: identity_provider constraint_2b; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.identity_provider
    ADD CONSTRAINT constraint_2b PRIMARY KEY (internal_id);


--
-- Name: client_attributes constraint_3c; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_attributes
    ADD CONSTRAINT constraint_3c PRIMARY KEY (client_id, name);


--
-- Name: event_entity constraint_4; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.event_entity
    ADD CONSTRAINT constraint_4 PRIMARY KEY (id);


--
-- Name: federated_identity constraint_40; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.federated_identity
    ADD CONSTRAINT constraint_40 PRIMARY KEY (identity_provider, user_id);


--
-- Name: realm constraint_4a; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm
    ADD CONSTRAINT constraint_4a PRIMARY KEY (id);


--
-- Name: client_session_role constraint_5; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_session_role
    ADD CONSTRAINT constraint_5 PRIMARY KEY (client_session, role_id);


--
-- Name: user_session constraint_57; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_session
    ADD CONSTRAINT constraint_57 PRIMARY KEY (id);


--
-- Name: user_federation_provider constraint_5c; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_federation_provider
    ADD CONSTRAINT constraint_5c PRIMARY KEY (id);


--
-- Name: client_session_note constraint_5e; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_session_note
    ADD CONSTRAINT constraint_5e PRIMARY KEY (client_session, name);


--
-- Name: client constraint_7; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT constraint_7 PRIMARY KEY (id);


--
-- Name: client_session constraint_8; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_session
    ADD CONSTRAINT constraint_8 PRIMARY KEY (id);


--
-- Name: scope_mapping constraint_81; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.scope_mapping
    ADD CONSTRAINT constraint_81 PRIMARY KEY (client_id, role_id);


--
-- Name: client_node_registrations constraint_84; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_node_registrations
    ADD CONSTRAINT constraint_84 PRIMARY KEY (client_id, name);


--
-- Name: realm_attribute constraint_9; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_attribute
    ADD CONSTRAINT constraint_9 PRIMARY KEY (name, realm_id);


--
-- Name: realm_required_credential constraint_92; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_required_credential
    ADD CONSTRAINT constraint_92 PRIMARY KEY (realm_id, type);


--
-- Name: keycloak_role constraint_a; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.keycloak_role
    ADD CONSTRAINT constraint_a PRIMARY KEY (id);


--
-- Name: admin_event_entity constraint_admin_event_entity; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.admin_event_entity
    ADD CONSTRAINT constraint_admin_event_entity PRIMARY KEY (id);


--
-- Name: authenticator_config_entry constraint_auth_cfg_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.authenticator_config_entry
    ADD CONSTRAINT constraint_auth_cfg_pk PRIMARY KEY (authenticator_id, name);


--
-- Name: authentication_execution constraint_auth_exec_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.authentication_execution
    ADD CONSTRAINT constraint_auth_exec_pk PRIMARY KEY (id);


--
-- Name: authentication_flow constraint_auth_flow_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.authentication_flow
    ADD CONSTRAINT constraint_auth_flow_pk PRIMARY KEY (id);


--
-- Name: authenticator_config constraint_auth_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.authenticator_config
    ADD CONSTRAINT constraint_auth_pk PRIMARY KEY (id);


--
-- Name: client_session_auth_status constraint_auth_status_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_session_auth_status
    ADD CONSTRAINT constraint_auth_status_pk PRIMARY KEY (client_session, authenticator);


--
-- Name: user_role_mapping constraint_c; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_role_mapping
    ADD CONSTRAINT constraint_c PRIMARY KEY (role_id, user_id);


--
-- Name: composite_role constraint_composite_role; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.composite_role
    ADD CONSTRAINT constraint_composite_role PRIMARY KEY (composite, child_role);


--
-- Name: client_session_prot_mapper constraint_cs_pmp_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_session_prot_mapper
    ADD CONSTRAINT constraint_cs_pmp_pk PRIMARY KEY (client_session, protocol_mapper_id);


--
-- Name: identity_provider_config constraint_d; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.identity_provider_config
    ADD CONSTRAINT constraint_d PRIMARY KEY (identity_provider_id, name);


--
-- Name: policy_config constraint_dpc; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.policy_config
    ADD CONSTRAINT constraint_dpc PRIMARY KEY (policy_id, name);


--
-- Name: realm_smtp_config constraint_e; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_smtp_config
    ADD CONSTRAINT constraint_e PRIMARY KEY (realm_id, name);


--
-- Name: credential constraint_f; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.credential
    ADD CONSTRAINT constraint_f PRIMARY KEY (id);


--
-- Name: user_federation_config constraint_f9; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_federation_config
    ADD CONSTRAINT constraint_f9 PRIMARY KEY (user_federation_provider_id, name);


--
-- Name: resource_server_perm_ticket constraint_fapmt; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT constraint_fapmt PRIMARY KEY (id);


--
-- Name: resource_server_resource constraint_farsr; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_resource
    ADD CONSTRAINT constraint_farsr PRIMARY KEY (id);


--
-- Name: resource_server_policy constraint_farsrp; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_policy
    ADD CONSTRAINT constraint_farsrp PRIMARY KEY (id);


--
-- Name: associated_policy constraint_farsrpap; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.associated_policy
    ADD CONSTRAINT constraint_farsrpap PRIMARY KEY (policy_id, associated_policy_id);


--
-- Name: resource_policy constraint_farsrpp; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_policy
    ADD CONSTRAINT constraint_farsrpp PRIMARY KEY (resource_id, policy_id);


--
-- Name: resource_server_scope constraint_farsrs; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_scope
    ADD CONSTRAINT constraint_farsrs PRIMARY KEY (id);


--
-- Name: resource_scope constraint_farsrsp; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_scope
    ADD CONSTRAINT constraint_farsrsp PRIMARY KEY (resource_id, scope_id);


--
-- Name: scope_policy constraint_farsrsps; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.scope_policy
    ADD CONSTRAINT constraint_farsrsps PRIMARY KEY (scope_id, policy_id);


--
-- Name: user_entity constraint_fb; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_entity
    ADD CONSTRAINT constraint_fb PRIMARY KEY (id);


--
-- Name: user_federation_mapper_config constraint_fedmapper_cfg_pm; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_federation_mapper_config
    ADD CONSTRAINT constraint_fedmapper_cfg_pm PRIMARY KEY (user_federation_mapper_id, name);


--
-- Name: user_federation_mapper constraint_fedmapperpm; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_federation_mapper
    ADD CONSTRAINT constraint_fedmapperpm PRIMARY KEY (id);


--
-- Name: fed_user_consent_cl_scope constraint_fgrntcsnt_clsc_pm; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.fed_user_consent_cl_scope
    ADD CONSTRAINT constraint_fgrntcsnt_clsc_pm PRIMARY KEY (user_consent_id, scope_id);


--
-- Name: user_consent_client_scope constraint_grntcsnt_clsc_pm; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_consent_client_scope
    ADD CONSTRAINT constraint_grntcsnt_clsc_pm PRIMARY KEY (user_consent_id, scope_id);


--
-- Name: user_consent constraint_grntcsnt_pm; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_consent
    ADD CONSTRAINT constraint_grntcsnt_pm PRIMARY KEY (id);


--
-- Name: keycloak_group constraint_group; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.keycloak_group
    ADD CONSTRAINT constraint_group PRIMARY KEY (id);


--
-- Name: group_attribute constraint_group_attribute_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.group_attribute
    ADD CONSTRAINT constraint_group_attribute_pk PRIMARY KEY (id);


--
-- Name: group_role_mapping constraint_group_role; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.group_role_mapping
    ADD CONSTRAINT constraint_group_role PRIMARY KEY (role_id, group_id);


--
-- Name: identity_provider_mapper constraint_idpm; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.identity_provider_mapper
    ADD CONSTRAINT constraint_idpm PRIMARY KEY (id);


--
-- Name: idp_mapper_config constraint_idpmconfig; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.idp_mapper_config
    ADD CONSTRAINT constraint_idpmconfig PRIMARY KEY (idp_mapper_id, name);


--
-- Name: migration_model constraint_migmod; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.migration_model
    ADD CONSTRAINT constraint_migmod PRIMARY KEY (id);


--
-- Name: offline_client_session constraint_offl_cl_ses_pk3; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.offline_client_session
    ADD CONSTRAINT constraint_offl_cl_ses_pk3 PRIMARY KEY (user_session_id, client_id, client_storage_provider, external_client_id, offline_flag);


--
-- Name: offline_user_session constraint_offl_us_ses_pk2; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.offline_user_session
    ADD CONSTRAINT constraint_offl_us_ses_pk2 PRIMARY KEY (user_session_id, offline_flag);


--
-- Name: protocol_mapper constraint_pcm; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.protocol_mapper
    ADD CONSTRAINT constraint_pcm PRIMARY KEY (id);


--
-- Name: protocol_mapper_config constraint_pmconfig; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.protocol_mapper_config
    ADD CONSTRAINT constraint_pmconfig PRIMARY KEY (protocol_mapper_id, name);


--
-- Name: redirect_uris constraint_redirect_uris; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.redirect_uris
    ADD CONSTRAINT constraint_redirect_uris PRIMARY KEY (client_id, value);


--
-- Name: required_action_config constraint_req_act_cfg_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.required_action_config
    ADD CONSTRAINT constraint_req_act_cfg_pk PRIMARY KEY (required_action_id, name);


--
-- Name: required_action_provider constraint_req_act_prv_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.required_action_provider
    ADD CONSTRAINT constraint_req_act_prv_pk PRIMARY KEY (id);


--
-- Name: user_required_action constraint_required_action; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_required_action
    ADD CONSTRAINT constraint_required_action PRIMARY KEY (required_action, user_id);


--
-- Name: resource_uris constraint_resour_uris_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_uris
    ADD CONSTRAINT constraint_resour_uris_pk PRIMARY KEY (resource_id, value);


--
-- Name: role_attribute constraint_role_attribute_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.role_attribute
    ADD CONSTRAINT constraint_role_attribute_pk PRIMARY KEY (id);


--
-- Name: user_attribute constraint_user_attribute_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_attribute
    ADD CONSTRAINT constraint_user_attribute_pk PRIMARY KEY (id);


--
-- Name: user_group_membership constraint_user_group; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_group_membership
    ADD CONSTRAINT constraint_user_group PRIMARY KEY (group_id, user_id);


--
-- Name: user_session_note constraint_usn_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_session_note
    ADD CONSTRAINT constraint_usn_pk PRIMARY KEY (user_session, name);


--
-- Name: web_origins constraint_web_origins; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.web_origins
    ADD CONSTRAINT constraint_web_origins PRIMARY KEY (client_id, value);


--
-- Name: databasechangeloglock databasechangeloglock_pkey; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.databasechangeloglock
    ADD CONSTRAINT databasechangeloglock_pkey PRIMARY KEY (id);


--
-- Name: client_scope_attributes pk_cl_tmpl_attr; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_scope_attributes
    ADD CONSTRAINT pk_cl_tmpl_attr PRIMARY KEY (scope_id, name);


--
-- Name: client_scope pk_cli_template; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_scope
    ADD CONSTRAINT pk_cli_template PRIMARY KEY (id);


--
-- Name: resource_server pk_resource_server; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server
    ADD CONSTRAINT pk_resource_server PRIMARY KEY (id);


--
-- Name: client_scope_role_mapping pk_template_scope; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_scope_role_mapping
    ADD CONSTRAINT pk_template_scope PRIMARY KEY (scope_id, role_id);


--
-- Name: default_client_scope r_def_cli_scope_bind; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.default_client_scope
    ADD CONSTRAINT r_def_cli_scope_bind PRIMARY KEY (realm_id, scope_id);


--
-- Name: realm_localizations realm_localizations_pkey; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_localizations
    ADD CONSTRAINT realm_localizations_pkey PRIMARY KEY (realm_id, locale);


--
-- Name: resource_attribute res_attr_pk; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_attribute
    ADD CONSTRAINT res_attr_pk PRIMARY KEY (id);


--
-- Name: keycloak_group sibling_names; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.keycloak_group
    ADD CONSTRAINT sibling_names UNIQUE (realm_id, parent_group, name);


--
-- Name: identity_provider uk_2daelwnibji49avxsrtuf6xj33; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.identity_provider
    ADD CONSTRAINT uk_2daelwnibji49avxsrtuf6xj33 UNIQUE (provider_alias, realm_id);


--
-- Name: client uk_b71cjlbenv945rb6gcon438at; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT uk_b71cjlbenv945rb6gcon438at UNIQUE (realm_id, client_id);


--
-- Name: client_scope uk_cli_scope; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_scope
    ADD CONSTRAINT uk_cli_scope UNIQUE (realm_id, name);


--
-- Name: user_entity uk_dykn684sl8up1crfei6eckhd7; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_entity
    ADD CONSTRAINT uk_dykn684sl8up1crfei6eckhd7 UNIQUE (realm_id, email_constraint);


--
-- Name: resource_server_resource uk_frsr6t700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_resource
    ADD CONSTRAINT uk_frsr6t700s9v50bu18ws5ha6 UNIQUE (name, owner, resource_server_id);


--
-- Name: resource_server_perm_ticket uk_frsr6t700s9v50bu18ws5pmt; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT uk_frsr6t700s9v50bu18ws5pmt UNIQUE (owner, requester, resource_server_id, resource_id, scope_id);


--
-- Name: resource_server_policy uk_frsrpt700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_policy
    ADD CONSTRAINT uk_frsrpt700s9v50bu18ws5ha6 UNIQUE (name, resource_server_id);


--
-- Name: resource_server_scope uk_frsrst700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_scope
    ADD CONSTRAINT uk_frsrst700s9v50bu18ws5ha6 UNIQUE (name, resource_server_id);


--
-- Name: user_consent uk_jkuwuvd56ontgsuhogm8uewrt; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_consent
    ADD CONSTRAINT uk_jkuwuvd56ontgsuhogm8uewrt UNIQUE (client_id, client_storage_provider, external_client_id, user_id);


--
-- Name: realm uk_orvsdmla56612eaefiq6wl5oi; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm
    ADD CONSTRAINT uk_orvsdmla56612eaefiq6wl5oi UNIQUE (name);


--
-- Name: user_entity uk_ru8tt6t700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_entity
    ADD CONSTRAINT uk_ru8tt6t700s9v50bu18ws5ha6 UNIQUE (realm_id, username);


--
-- Name: idx_admin_event_time; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_admin_event_time ON public.admin_event_entity USING btree (realm_id, admin_event_time);


--
-- Name: idx_assoc_pol_assoc_pol_id; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_assoc_pol_assoc_pol_id ON public.associated_policy USING btree (associated_policy_id);


--
-- Name: idx_auth_config_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_auth_config_realm ON public.authenticator_config USING btree (realm_id);


--
-- Name: idx_auth_exec_flow; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_auth_exec_flow ON public.authentication_execution USING btree (flow_id);


--
-- Name: idx_auth_exec_realm_flow; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_auth_exec_realm_flow ON public.authentication_execution USING btree (realm_id, flow_id);


--
-- Name: idx_auth_flow_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_auth_flow_realm ON public.authentication_flow USING btree (realm_id);


--
-- Name: idx_cl_clscope; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_cl_clscope ON public.client_scope_client USING btree (scope_id);


--
-- Name: idx_client_id; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_client_id ON public.client USING btree (client_id);


--
-- Name: idx_client_init_acc_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_client_init_acc_realm ON public.client_initial_access USING btree (realm_id);


--
-- Name: idx_client_session_session; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_client_session_session ON public.client_session USING btree (session_id);


--
-- Name: idx_clscope_attrs; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_clscope_attrs ON public.client_scope_attributes USING btree (scope_id);


--
-- Name: idx_clscope_cl; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_clscope_cl ON public.client_scope_client USING btree (client_id);


--
-- Name: idx_clscope_protmap; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_clscope_protmap ON public.protocol_mapper USING btree (client_scope_id);


--
-- Name: idx_clscope_role; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_clscope_role ON public.client_scope_role_mapping USING btree (scope_id);


--
-- Name: idx_compo_config_compo; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_compo_config_compo ON public.component_config USING btree (component_id);


--
-- Name: idx_component_provider_type; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_component_provider_type ON public.component USING btree (provider_type);


--
-- Name: idx_component_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_component_realm ON public.component USING btree (realm_id);


--
-- Name: idx_composite; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_composite ON public.composite_role USING btree (composite);


--
-- Name: idx_composite_child; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_composite_child ON public.composite_role USING btree (child_role);


--
-- Name: idx_defcls_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_defcls_realm ON public.default_client_scope USING btree (realm_id);


--
-- Name: idx_defcls_scope; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_defcls_scope ON public.default_client_scope USING btree (scope_id);


--
-- Name: idx_event_time; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_event_time ON public.event_entity USING btree (realm_id, event_time);


--
-- Name: idx_fedidentity_feduser; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fedidentity_feduser ON public.federated_identity USING btree (federated_user_id);


--
-- Name: idx_fedidentity_user; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fedidentity_user ON public.federated_identity USING btree (user_id);


--
-- Name: idx_fu_attribute; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_attribute ON public.fed_user_attribute USING btree (user_id, realm_id, name);


--
-- Name: idx_fu_cnsnt_ext; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_cnsnt_ext ON public.fed_user_consent USING btree (user_id, client_storage_provider, external_client_id);


--
-- Name: idx_fu_consent; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_consent ON public.fed_user_consent USING btree (user_id, client_id);


--
-- Name: idx_fu_consent_ru; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_consent_ru ON public.fed_user_consent USING btree (realm_id, user_id);


--
-- Name: idx_fu_credential; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_credential ON public.fed_user_credential USING btree (user_id, type);


--
-- Name: idx_fu_credential_ru; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_credential_ru ON public.fed_user_credential USING btree (realm_id, user_id);


--
-- Name: idx_fu_group_membership; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_group_membership ON public.fed_user_group_membership USING btree (user_id, group_id);


--
-- Name: idx_fu_group_membership_ru; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_group_membership_ru ON public.fed_user_group_membership USING btree (realm_id, user_id);


--
-- Name: idx_fu_required_action; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_required_action ON public.fed_user_required_action USING btree (user_id, required_action);


--
-- Name: idx_fu_required_action_ru; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_required_action_ru ON public.fed_user_required_action USING btree (realm_id, user_id);


--
-- Name: idx_fu_role_mapping; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_role_mapping ON public.fed_user_role_mapping USING btree (user_id, role_id);


--
-- Name: idx_fu_role_mapping_ru; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_fu_role_mapping_ru ON public.fed_user_role_mapping USING btree (realm_id, user_id);


--
-- Name: idx_group_att_by_name_value; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_group_att_by_name_value ON public.group_attribute USING btree (name, ((value)::character varying(250)));


--
-- Name: idx_group_attr_group; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_group_attr_group ON public.group_attribute USING btree (group_id);


--
-- Name: idx_group_role_mapp_group; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_group_role_mapp_group ON public.group_role_mapping USING btree (group_id);


--
-- Name: idx_id_prov_mapp_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_id_prov_mapp_realm ON public.identity_provider_mapper USING btree (realm_id);


--
-- Name: idx_ident_prov_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_ident_prov_realm ON public.identity_provider USING btree (realm_id);


--
-- Name: idx_keycloak_role_client; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_keycloak_role_client ON public.keycloak_role USING btree (client);


--
-- Name: idx_keycloak_role_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_keycloak_role_realm ON public.keycloak_role USING btree (realm);


--
-- Name: idx_offline_css_preload; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_offline_css_preload ON public.offline_client_session USING btree (client_id, offline_flag);


--
-- Name: idx_offline_uss_by_user; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_offline_uss_by_user ON public.offline_user_session USING btree (user_id, realm_id, offline_flag);


--
-- Name: idx_offline_uss_by_usersess; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_offline_uss_by_usersess ON public.offline_user_session USING btree (realm_id, offline_flag, user_session_id);


--
-- Name: idx_offline_uss_createdon; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_offline_uss_createdon ON public.offline_user_session USING btree (created_on);


--
-- Name: idx_offline_uss_preload; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_offline_uss_preload ON public.offline_user_session USING btree (offline_flag, created_on, user_session_id);


--
-- Name: idx_protocol_mapper_client; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_protocol_mapper_client ON public.protocol_mapper USING btree (client_id);


--
-- Name: idx_realm_attr_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_realm_attr_realm ON public.realm_attribute USING btree (realm_id);


--
-- Name: idx_realm_clscope; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_realm_clscope ON public.client_scope USING btree (realm_id);


--
-- Name: idx_realm_def_grp_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_realm_def_grp_realm ON public.realm_default_groups USING btree (realm_id);


--
-- Name: idx_realm_evt_list_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_realm_evt_list_realm ON public.realm_events_listeners USING btree (realm_id);


--
-- Name: idx_realm_evt_types_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_realm_evt_types_realm ON public.realm_enabled_event_types USING btree (realm_id);


--
-- Name: idx_realm_master_adm_cli; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_realm_master_adm_cli ON public.realm USING btree (master_admin_client);


--
-- Name: idx_realm_supp_local_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_realm_supp_local_realm ON public.realm_supported_locales USING btree (realm_id);


--
-- Name: idx_redir_uri_client; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_redir_uri_client ON public.redirect_uris USING btree (client_id);


--
-- Name: idx_req_act_prov_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_req_act_prov_realm ON public.required_action_provider USING btree (realm_id);


--
-- Name: idx_res_policy_policy; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_res_policy_policy ON public.resource_policy USING btree (policy_id);


--
-- Name: idx_res_scope_scope; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_res_scope_scope ON public.resource_scope USING btree (scope_id);


--
-- Name: idx_res_serv_pol_res_serv; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_res_serv_pol_res_serv ON public.resource_server_policy USING btree (resource_server_id);


--
-- Name: idx_res_srv_res_res_srv; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_res_srv_res_res_srv ON public.resource_server_resource USING btree (resource_server_id);


--
-- Name: idx_res_srv_scope_res_srv; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_res_srv_scope_res_srv ON public.resource_server_scope USING btree (resource_server_id);


--
-- Name: idx_role_attribute; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_role_attribute ON public.role_attribute USING btree (role_id);


--
-- Name: idx_role_clscope; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_role_clscope ON public.client_scope_role_mapping USING btree (role_id);


--
-- Name: idx_scope_mapping_role; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_scope_mapping_role ON public.scope_mapping USING btree (role_id);


--
-- Name: idx_scope_policy_policy; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_scope_policy_policy ON public.scope_policy USING btree (policy_id);


--
-- Name: idx_update_time; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_update_time ON public.migration_model USING btree (update_time);


--
-- Name: idx_us_sess_id_on_cl_sess; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_us_sess_id_on_cl_sess ON public.offline_client_session USING btree (user_session_id);


--
-- Name: idx_usconsent_clscope; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_usconsent_clscope ON public.user_consent_client_scope USING btree (user_consent_id);


--
-- Name: idx_user_attribute; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_user_attribute ON public.user_attribute USING btree (user_id);


--
-- Name: idx_user_attribute_name; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_user_attribute_name ON public.user_attribute USING btree (name, value);


--
-- Name: idx_user_consent; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_user_consent ON public.user_consent USING btree (user_id);


--
-- Name: idx_user_credential; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_user_credential ON public.credential USING btree (user_id);


--
-- Name: idx_user_email; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_user_email ON public.user_entity USING btree (email);


--
-- Name: idx_user_group_mapping; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_user_group_mapping ON public.user_group_membership USING btree (user_id);


--
-- Name: idx_user_reqactions; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_user_reqactions ON public.user_required_action USING btree (user_id);


--
-- Name: idx_user_role_mapping; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_user_role_mapping ON public.user_role_mapping USING btree (user_id);


--
-- Name: idx_user_service_account; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_user_service_account ON public.user_entity USING btree (realm_id, service_account_client_link);


--
-- Name: idx_usr_fed_map_fed_prv; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_usr_fed_map_fed_prv ON public.user_federation_mapper USING btree (federation_provider_id);


--
-- Name: idx_usr_fed_map_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_usr_fed_map_realm ON public.user_federation_mapper USING btree (realm_id);


--
-- Name: idx_usr_fed_prv_realm; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_usr_fed_prv_realm ON public.user_federation_provider USING btree (realm_id);


--
-- Name: idx_web_orig_client; Type: INDEX; Schema: public; Owner: keycloak
--

CREATE INDEX idx_web_orig_client ON public.web_origins USING btree (client_id);


--
-- Name: client_session_auth_status auth_status_constraint; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_session_auth_status
    ADD CONSTRAINT auth_status_constraint FOREIGN KEY (client_session) REFERENCES public.client_session(id);


--
-- Name: identity_provider fk2b4ebc52ae5c3b34; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.identity_provider
    ADD CONSTRAINT fk2b4ebc52ae5c3b34 FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: client_attributes fk3c47c64beacca966; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_attributes
    ADD CONSTRAINT fk3c47c64beacca966 FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: federated_identity fk404288b92ef007a6; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.federated_identity
    ADD CONSTRAINT fk404288b92ef007a6 FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: client_node_registrations fk4129723ba992f594; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_node_registrations
    ADD CONSTRAINT fk4129723ba992f594 FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: client_session_note fk5edfb00ff51c2736; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_session_note
    ADD CONSTRAINT fk5edfb00ff51c2736 FOREIGN KEY (client_session) REFERENCES public.client_session(id);


--
-- Name: user_session_note fk5edfb00ff51d3472; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_session_note
    ADD CONSTRAINT fk5edfb00ff51d3472 FOREIGN KEY (user_session) REFERENCES public.user_session(id);


--
-- Name: client_session_role fk_11b7sgqw18i532811v7o2dv76; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_session_role
    ADD CONSTRAINT fk_11b7sgqw18i532811v7o2dv76 FOREIGN KEY (client_session) REFERENCES public.client_session(id);


--
-- Name: redirect_uris fk_1burs8pb4ouj97h5wuppahv9f; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.redirect_uris
    ADD CONSTRAINT fk_1burs8pb4ouj97h5wuppahv9f FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: user_federation_provider fk_1fj32f6ptolw2qy60cd8n01e8; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_federation_provider
    ADD CONSTRAINT fk_1fj32f6ptolw2qy60cd8n01e8 FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: client_session_prot_mapper fk_33a8sgqw18i532811v7o2dk89; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_session_prot_mapper
    ADD CONSTRAINT fk_33a8sgqw18i532811v7o2dk89 FOREIGN KEY (client_session) REFERENCES public.client_session(id);


--
-- Name: realm_required_credential fk_5hg65lybevavkqfki3kponh9v; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_required_credential
    ADD CONSTRAINT fk_5hg65lybevavkqfki3kponh9v FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: resource_attribute fk_5hrm2vlf9ql5fu022kqepovbr; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_attribute
    ADD CONSTRAINT fk_5hrm2vlf9ql5fu022kqepovbr FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: user_attribute fk_5hrm2vlf9ql5fu043kqepovbr; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_attribute
    ADD CONSTRAINT fk_5hrm2vlf9ql5fu043kqepovbr FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: user_required_action fk_6qj3w1jw9cvafhe19bwsiuvmd; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_required_action
    ADD CONSTRAINT fk_6qj3w1jw9cvafhe19bwsiuvmd FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: keycloak_role fk_6vyqfe4cn4wlq8r6kt5vdsj5c; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.keycloak_role
    ADD CONSTRAINT fk_6vyqfe4cn4wlq8r6kt5vdsj5c FOREIGN KEY (realm) REFERENCES public.realm(id);


--
-- Name: realm_smtp_config fk_70ej8xdxgxd0b9hh6180irr0o; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_smtp_config
    ADD CONSTRAINT fk_70ej8xdxgxd0b9hh6180irr0o FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: realm_attribute fk_8shxd6l3e9atqukacxgpffptw; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_attribute
    ADD CONSTRAINT fk_8shxd6l3e9atqukacxgpffptw FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: composite_role fk_a63wvekftu8jo1pnj81e7mce2; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.composite_role
    ADD CONSTRAINT fk_a63wvekftu8jo1pnj81e7mce2 FOREIGN KEY (composite) REFERENCES public.keycloak_role(id);


--
-- Name: authentication_execution fk_auth_exec_flow; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.authentication_execution
    ADD CONSTRAINT fk_auth_exec_flow FOREIGN KEY (flow_id) REFERENCES public.authentication_flow(id);


--
-- Name: authentication_execution fk_auth_exec_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.authentication_execution
    ADD CONSTRAINT fk_auth_exec_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: authentication_flow fk_auth_flow_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.authentication_flow
    ADD CONSTRAINT fk_auth_flow_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: authenticator_config fk_auth_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.authenticator_config
    ADD CONSTRAINT fk_auth_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: client_session fk_b4ao2vcvat6ukau74wbwtfqo1; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_session
    ADD CONSTRAINT fk_b4ao2vcvat6ukau74wbwtfqo1 FOREIGN KEY (session_id) REFERENCES public.user_session(id);


--
-- Name: user_role_mapping fk_c4fqv34p1mbylloxang7b1q3l; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_role_mapping
    ADD CONSTRAINT fk_c4fqv34p1mbylloxang7b1q3l FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: client_scope_attributes fk_cl_scope_attr_scope; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_scope_attributes
    ADD CONSTRAINT fk_cl_scope_attr_scope FOREIGN KEY (scope_id) REFERENCES public.client_scope(id);


--
-- Name: client_scope_role_mapping fk_cl_scope_rm_scope; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_scope_role_mapping
    ADD CONSTRAINT fk_cl_scope_rm_scope FOREIGN KEY (scope_id) REFERENCES public.client_scope(id);


--
-- Name: client_user_session_note fk_cl_usr_ses_note; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_user_session_note
    ADD CONSTRAINT fk_cl_usr_ses_note FOREIGN KEY (client_session) REFERENCES public.client_session(id);


--
-- Name: protocol_mapper fk_cli_scope_mapper; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.protocol_mapper
    ADD CONSTRAINT fk_cli_scope_mapper FOREIGN KEY (client_scope_id) REFERENCES public.client_scope(id);


--
-- Name: client_initial_access fk_client_init_acc_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.client_initial_access
    ADD CONSTRAINT fk_client_init_acc_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: component_config fk_component_config; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.component_config
    ADD CONSTRAINT fk_component_config FOREIGN KEY (component_id) REFERENCES public.component(id);


--
-- Name: component fk_component_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.component
    ADD CONSTRAINT fk_component_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: realm_default_groups fk_def_groups_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_default_groups
    ADD CONSTRAINT fk_def_groups_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: user_federation_mapper_config fk_fedmapper_cfg; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_federation_mapper_config
    ADD CONSTRAINT fk_fedmapper_cfg FOREIGN KEY (user_federation_mapper_id) REFERENCES public.user_federation_mapper(id);


--
-- Name: user_federation_mapper fk_fedmapperpm_fedprv; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_federation_mapper
    ADD CONSTRAINT fk_fedmapperpm_fedprv FOREIGN KEY (federation_provider_id) REFERENCES public.user_federation_provider(id);


--
-- Name: user_federation_mapper fk_fedmapperpm_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_federation_mapper
    ADD CONSTRAINT fk_fedmapperpm_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: associated_policy fk_frsr5s213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.associated_policy
    ADD CONSTRAINT fk_frsr5s213xcx4wnkog82ssrfy FOREIGN KEY (associated_policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: scope_policy fk_frsrasp13xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.scope_policy
    ADD CONSTRAINT fk_frsrasp13xcx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: resource_server_perm_ticket fk_frsrho213xcx4wnkog82sspmt; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrho213xcx4wnkog82sspmt FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- Name: resource_server_resource fk_frsrho213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_resource
    ADD CONSTRAINT fk_frsrho213xcx4wnkog82ssrfy FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- Name: resource_server_perm_ticket fk_frsrho213xcx4wnkog83sspmt; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrho213xcx4wnkog83sspmt FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: resource_server_perm_ticket fk_frsrho213xcx4wnkog84sspmt; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrho213xcx4wnkog84sspmt FOREIGN KEY (scope_id) REFERENCES public.resource_server_scope(id);


--
-- Name: associated_policy fk_frsrpas14xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.associated_policy
    ADD CONSTRAINT fk_frsrpas14xcx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: scope_policy fk_frsrpass3xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.scope_policy
    ADD CONSTRAINT fk_frsrpass3xcx4wnkog82ssrfy FOREIGN KEY (scope_id) REFERENCES public.resource_server_scope(id);


--
-- Name: resource_server_perm_ticket fk_frsrpo2128cx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrpo2128cx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: resource_server_policy fk_frsrpo213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_policy
    ADD CONSTRAINT fk_frsrpo213xcx4wnkog82ssrfy FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- Name: resource_scope fk_frsrpos13xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_scope
    ADD CONSTRAINT fk_frsrpos13xcx4wnkog82ssrfy FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: resource_policy fk_frsrpos53xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_policy
    ADD CONSTRAINT fk_frsrpos53xcx4wnkog82ssrfy FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: resource_policy fk_frsrpp213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_policy
    ADD CONSTRAINT fk_frsrpp213xcx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: resource_scope fk_frsrps213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_scope
    ADD CONSTRAINT fk_frsrps213xcx4wnkog82ssrfy FOREIGN KEY (scope_id) REFERENCES public.resource_server_scope(id);


--
-- Name: resource_server_scope fk_frsrso213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_server_scope
    ADD CONSTRAINT fk_frsrso213xcx4wnkog82ssrfy FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- Name: composite_role fk_gr7thllb9lu8q4vqa4524jjy8; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.composite_role
    ADD CONSTRAINT fk_gr7thllb9lu8q4vqa4524jjy8 FOREIGN KEY (child_role) REFERENCES public.keycloak_role(id);


--
-- Name: user_consent_client_scope fk_grntcsnt_clsc_usc; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_consent_client_scope
    ADD CONSTRAINT fk_grntcsnt_clsc_usc FOREIGN KEY (user_consent_id) REFERENCES public.user_consent(id);


--
-- Name: user_consent fk_grntcsnt_user; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_consent
    ADD CONSTRAINT fk_grntcsnt_user FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: group_attribute fk_group_attribute_group; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.group_attribute
    ADD CONSTRAINT fk_group_attribute_group FOREIGN KEY (group_id) REFERENCES public.keycloak_group(id);


--
-- Name: group_role_mapping fk_group_role_group; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.group_role_mapping
    ADD CONSTRAINT fk_group_role_group FOREIGN KEY (group_id) REFERENCES public.keycloak_group(id);


--
-- Name: realm_enabled_event_types fk_h846o4h0w8epx5nwedrf5y69j; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_enabled_event_types
    ADD CONSTRAINT fk_h846o4h0w8epx5nwedrf5y69j FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: realm_events_listeners fk_h846o4h0w8epx5nxev9f5y69j; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_events_listeners
    ADD CONSTRAINT fk_h846o4h0w8epx5nxev9f5y69j FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: identity_provider_mapper fk_idpm_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.identity_provider_mapper
    ADD CONSTRAINT fk_idpm_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: idp_mapper_config fk_idpmconfig; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.idp_mapper_config
    ADD CONSTRAINT fk_idpmconfig FOREIGN KEY (idp_mapper_id) REFERENCES public.identity_provider_mapper(id);


--
-- Name: web_origins fk_lojpho213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.web_origins
    ADD CONSTRAINT fk_lojpho213xcx4wnkog82ssrfy FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: scope_mapping fk_ouse064plmlr732lxjcn1q5f1; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.scope_mapping
    ADD CONSTRAINT fk_ouse064plmlr732lxjcn1q5f1 FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: protocol_mapper fk_pcm_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.protocol_mapper
    ADD CONSTRAINT fk_pcm_realm FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: credential fk_pfyr0glasqyl0dei3kl69r6v0; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.credential
    ADD CONSTRAINT fk_pfyr0glasqyl0dei3kl69r6v0 FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: protocol_mapper_config fk_pmconfig; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.protocol_mapper_config
    ADD CONSTRAINT fk_pmconfig FOREIGN KEY (protocol_mapper_id) REFERENCES public.protocol_mapper(id);


--
-- Name: default_client_scope fk_r_def_cli_scope_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.default_client_scope
    ADD CONSTRAINT fk_r_def_cli_scope_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: required_action_provider fk_req_act_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.required_action_provider
    ADD CONSTRAINT fk_req_act_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: resource_uris fk_resource_server_uris; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.resource_uris
    ADD CONSTRAINT fk_resource_server_uris FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: role_attribute fk_role_attribute_id; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.role_attribute
    ADD CONSTRAINT fk_role_attribute_id FOREIGN KEY (role_id) REFERENCES public.keycloak_role(id);


--
-- Name: realm_supported_locales fk_supported_locales_realm; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.realm_supported_locales
    ADD CONSTRAINT fk_supported_locales_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: user_federation_config fk_t13hpu1j94r2ebpekr39x5eu5; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_federation_config
    ADD CONSTRAINT fk_t13hpu1j94r2ebpekr39x5eu5 FOREIGN KEY (user_federation_provider_id) REFERENCES public.user_federation_provider(id);


--
-- Name: user_group_membership fk_user_group_user; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.user_group_membership
    ADD CONSTRAINT fk_user_group_user FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: policy_config fkdc34197cf864c4e43; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.policy_config
    ADD CONSTRAINT fkdc34197cf864c4e43 FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: identity_provider_config fkdc4897cf864c4e43; Type: FK CONSTRAINT; Schema: public; Owner: keycloak
--

ALTER TABLE ONLY public.identity_provider_config
    ADD CONSTRAINT fkdc4897cf864c4e43 FOREIGN KEY (identity_provider_id) REFERENCES public.identity_provider(internal_id);


--
-- PostgreSQL database dump complete
--

